package com.tuling;

/**
 * @author Fox
 */
public class AgentTest {
    
    public static void main(String[] args) {

        System.out.println("hello world");


        // UserService   insert

    }
}
