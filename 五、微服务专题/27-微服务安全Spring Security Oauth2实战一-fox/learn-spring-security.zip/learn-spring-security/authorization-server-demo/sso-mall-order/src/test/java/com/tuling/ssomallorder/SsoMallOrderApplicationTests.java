package com.tuling.ssomallorder;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SsoMallOrderApplicationTests {

    @Test
    void contextLoads() {
    }

}
