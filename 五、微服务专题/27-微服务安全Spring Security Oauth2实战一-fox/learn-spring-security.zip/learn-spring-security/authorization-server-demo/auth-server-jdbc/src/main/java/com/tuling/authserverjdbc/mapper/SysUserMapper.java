package com.tuling.authserverjdbc.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.tuling.authserverjdbc.model.SysUserEntity;
import org.apache.ibatis.annotations.Mapper;


@Mapper
public interface SysUserMapper extends BaseMapper<SysUserEntity> {

}
