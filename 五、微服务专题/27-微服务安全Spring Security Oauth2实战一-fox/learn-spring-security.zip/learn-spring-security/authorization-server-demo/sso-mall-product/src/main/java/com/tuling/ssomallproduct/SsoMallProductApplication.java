package com.tuling.ssomallproduct;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SsoMallProductApplication {

    public static void main(String[] args) {
        SpringApplication.run(SsoMallProductApplication.class, args);
    }

}
