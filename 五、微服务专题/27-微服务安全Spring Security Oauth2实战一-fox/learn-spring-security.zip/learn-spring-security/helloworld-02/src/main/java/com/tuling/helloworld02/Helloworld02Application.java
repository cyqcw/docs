package com.tuling.helloworld02;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Helloworld02Application {

    public static void main(String[] args) {
        SpringApplication.run(Helloworld02Application.class, args);
    }

}
