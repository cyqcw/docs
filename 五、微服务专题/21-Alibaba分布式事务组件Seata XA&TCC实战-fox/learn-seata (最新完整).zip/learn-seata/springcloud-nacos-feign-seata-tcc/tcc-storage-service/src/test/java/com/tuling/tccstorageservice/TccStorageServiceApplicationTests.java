package com.tuling.tccstorageservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TccStorageServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
