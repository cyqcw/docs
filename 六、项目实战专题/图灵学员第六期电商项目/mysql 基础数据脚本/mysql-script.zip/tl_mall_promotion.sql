/*
 Navicat Premium Data Transfer

 Source Server         : 192.168.65.71
 Source Server Type    : MySQL
 Source Server Version : 80029 (8.0.29)
 Source Host           : 192.168.65.71:3306
 Source Schema         : tl_mall_promotion

 Target Server Type    : MySQL
 Target Server Version : 80029 (8.0.29)
 File Encoding         : 65001

 Date: 31/10/2023 13:56:00
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for sms_coupon
-- ----------------------------
DROP TABLE IF EXISTS `sms_coupon`;
CREATE TABLE `sms_coupon` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `type` int DEFAULT NULL COMMENT '优惠卷类型；0->全场赠券；1->会员赠券；2->购物赠券；3->注册赠券',
  `name` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `platform` int DEFAULT NULL COMMENT '使用平台：0->全部；1->移动；2->PC',
  `count` int DEFAULT NULL COMMENT '数量',
  `amount` decimal(10,2) DEFAULT NULL COMMENT '金额',
  `per_limit` int DEFAULT NULL COMMENT '每人限领张数',
  `min_point` decimal(10,2) DEFAULT NULL COMMENT '使用门槛；0表示无门槛',
  `start_time` datetime DEFAULT NULL,
  `end_time` datetime DEFAULT NULL,
  `use_type` int DEFAULT NULL COMMENT '使用类型：0->全场通用；1->指定分类；2->指定商品',
  `note` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '备注',
  `publish_count` int DEFAULT NULL COMMENT '发行数量',
  `use_count` int DEFAULT NULL COMMENT '已使用数量',
  `receive_count` int DEFAULT NULL COMMENT '领取数量',
  `enable_time` datetime DEFAULT NULL COMMENT '可以领取的日期',
  `code` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '优惠码',
  `member_level` int DEFAULT NULL COMMENT '可领取的会员类型：0->无限时',
  `gmt_create` datetime(6) DEFAULT CURRENT_TIMESTAMP(6),
  `gmt_modified` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb3 ROW_FORMAT=DYNAMIC COMMENT='优惠卷表';

-- ----------------------------
-- Records of sms_coupon
-- ----------------------------
BEGIN;
INSERT INTO `sms_coupon` (`id`, `type`, `name`, `platform`, `count`, `amount`, `per_limit`, `min_point`, `start_time`, `end_time`, `use_type`, `note`, `publish_count`, `use_count`, `receive_count`, `enable_time`, `code`, `member_level`, `gmt_create`, `gmt_modified`) VALUES (4, 0, '手机品类专用券', 0, 92, 300.00, 1, 2000.00, '2018-08-27 16:40:47', '2018-09-15 16:40:47', 0, '手机分类专用优惠券', 100, 0, 8, '2018-08-27 16:40:47', NULL, NULL, NULL, NULL);
INSERT INTO `sms_coupon` (`id`, `type`, `name`, `platform`, `count`, `amount`, `per_limit`, `min_point`, `start_time`, `end_time`, `use_type`, `note`, `publish_count`, `use_count`, `receive_count`, `enable_time`, `code`, `member_level`, `gmt_create`, `gmt_modified`) VALUES (7, 0, 'T恤分类专用优惠券', 0, 93, 50.00, 1, 500.00, '2018-08-27 16:40:47', '2018-08-15 16:40:47', 0, '满500减50', 100, 0, 7, '2018-08-27 16:40:47', NULL, NULL, NULL, NULL);
INSERT INTO `sms_coupon` (`id`, `type`, `name`, `platform`, `count`, `amount`, `per_limit`, `min_point`, `start_time`, `end_time`, `use_type`, `note`, `publish_count`, `use_count`, `receive_count`, `enable_time`, `code`, `member_level`, `gmt_create`, `gmt_modified`) VALUES (11, 0, '全品类通用券', 0, 1000, 50.00, 1, 1000.00, '2018-11-08 00:00:00', '2018-11-10 00:00:00', 0, NULL, 1000, 0, 0, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `sms_coupon` (`id`, `type`, `name`, `platform`, `count`, `amount`, `per_limit`, `min_point`, `start_time`, `end_time`, `use_type`, `note`, `publish_count`, `use_count`, `receive_count`, `enable_time`, `code`, `member_level`, `gmt_create`, `gmt_modified`) VALUES (12, 0, '移动端全品类通用券', 1, 97, 10.00, 1, 100.00, '2022-11-10 10:00:00', '2024-11-13 10:00:00', 0, NULL, 100, 0, 4, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `sms_coupon` (`id`, `type`, `name`, `platform`, `count`, `amount`, `per_limit`, `min_point`, `start_time`, `end_time`, `use_type`, `note`, `publish_count`, `use_count`, `receive_count`, `enable_time`, `code`, `member_level`, `gmt_create`, `gmt_modified`) VALUES (22, 0, '华为手机专用', 0, 999, 999.00, 1, 2000.00, '2020-03-24 16:00:00', '2020-12-30 16:00:00', 0, NULL, 1000, 0, 1, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `sms_coupon` (`id`, `type`, `name`, `platform`, `count`, `amount`, `per_limit`, `min_point`, `start_time`, `end_time`, `use_type`, `note`, `publish_count`, `use_count`, `receive_count`, `enable_time`, `code`, `member_level`, `gmt_create`, `gmt_modified`) VALUES (23, 0, '华为手机专用', 0, 999, 999.00, 1, 2000.00, '2020-03-24 16:00:00', '2020-12-30 16:00:00', 0, NULL, 1000, 0, NULL, NULL, NULL, NULL, NULL, NULL);
COMMIT;

-- ----------------------------
-- Table structure for sms_coupon_history
-- ----------------------------
DROP TABLE IF EXISTS `sms_coupon_history`;
CREATE TABLE `sms_coupon_history` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `coupon_id` bigint DEFAULT NULL,
  `member_id` bigint DEFAULT NULL,
  `coupon_code` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `member_nickname` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '领取人昵称',
  `get_type` int DEFAULT NULL COMMENT '获取类型：0->后台赠送；1->主动获取',
  `create_time` datetime DEFAULT NULL,
  `use_status` int DEFAULT NULL COMMENT '使用状态：0->未使用；1->已使用；2->已过期',
  `use_time` datetime DEFAULT NULL COMMENT '使用时间',
  `order_id` bigint DEFAULT NULL COMMENT '订单编号',
  `order_sn` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '订单号码',
  `gmt_create` datetime(6) DEFAULT CURRENT_TIMESTAMP(6),
  `gmt_modified` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `idx_member_id` (`member_id`) USING BTREE,
  KEY `idx_coupon_id` (`coupon_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb3 ROW_FORMAT=DYNAMIC COMMENT='优惠券使用、领取历史表';

-- ----------------------------
-- Records of sms_coupon_history
-- ----------------------------
BEGIN;
INSERT INTO `sms_coupon_history` (`id`, `coupon_id`, `member_id`, `coupon_code`, `member_nickname`, `get_type`, `create_time`, `use_status`, `use_time`, `order_id`, `order_sn`, `gmt_create`, `gmt_modified`) VALUES (12, 2, 4, '0340981248320004', 'zhensan', 1, '2018-11-12 14:16:50', 0, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `sms_coupon_history` (`id`, `coupon_id`, `member_id`, `coupon_code`, `member_nickname`, `get_type`, `create_time`, `use_status`, `use_time`, `order_id`, `order_sn`, `gmt_create`, `gmt_modified`) VALUES (13, 3, 4, '0342977234360004', 'zhensan', 1, '2018-11-12 14:17:10', 0, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `sms_coupon_history` (`id`, `coupon_id`, `member_id`, `coupon_code`, `member_nickname`, `get_type`, `create_time`, `use_status`, `use_time`, `order_id`, `order_sn`, `gmt_create`, `gmt_modified`) VALUES (14, 4, 4, '0343342928830004', 'zhensan', 1, '2018-11-12 14:17:13', 0, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `sms_coupon_history` (`id`, `coupon_id`, `member_id`, `coupon_code`, `member_nickname`, `get_type`, `create_time`, `use_status`, `use_time`, `order_id`, `order_sn`, `gmt_create`, `gmt_modified`) VALUES (15, 2, 5, '0351883832180005', 'lisi', 1, '2018-11-12 14:18:39', 0, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `sms_coupon_history` (`id`, `coupon_id`, `member_id`, `coupon_code`, `member_nickname`, `get_type`, `create_time`, `use_status`, `use_time`, `order_id`, `order_sn`, `gmt_create`, `gmt_modified`) VALUES (16, 3, 5, '0352201672680005', 'lisi', 1, '2018-11-12 14:18:42', 0, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `sms_coupon_history` (`id`, `coupon_id`, `member_id`, `coupon_code`, `member_nickname`, `get_type`, `create_time`, `use_status`, `use_time`, `order_id`, `order_sn`, `gmt_create`, `gmt_modified`) VALUES (17, 4, 5, '0352505810180005', 'lisi', 1, '2018-11-12 14:18:45', 0, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `sms_coupon_history` (`id`, `coupon_id`, `member_id`, `coupon_code`, `member_nickname`, `get_type`, `create_time`, `use_status`, `use_time`, `order_id`, `order_sn`, `gmt_create`, `gmt_modified`) VALUES (18, 2, 6, '0356114588380006', 'wangwu', 1, '2018-11-12 14:19:21', 0, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `sms_coupon_history` (`id`, `coupon_id`, `member_id`, `coupon_code`, `member_nickname`, `get_type`, `create_time`, `use_status`, `use_time`, `order_id`, `order_sn`, `gmt_create`, `gmt_modified`) VALUES (19, 3, 6, '0356382856920006', 'wangwu', 1, '2018-11-12 14:19:24', 0, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `sms_coupon_history` (`id`, `coupon_id`, `member_id`, `coupon_code`, `member_nickname`, `get_type`, `create_time`, `use_status`, `use_time`, `order_id`, `order_sn`, `gmt_create`, `gmt_modified`) VALUES (20, 4, 6, '0356656798470006', 'wangwu', 1, '2018-11-12 14:19:27', 0, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `sms_coupon_history` (`id`, `coupon_id`, `member_id`, `coupon_code`, `member_nickname`, `get_type`, `create_time`, `use_status`, `use_time`, `order_id`, `order_sn`, `gmt_create`, `gmt_modified`) VALUES (21, 2, 3, '0363644984620003', 'windy', 1, '2018-11-12 14:20:36', 0, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `sms_coupon_history` (`id`, `coupon_id`, `member_id`, `coupon_code`, `member_nickname`, `get_type`, `create_time`, `use_status`, `use_time`, `order_id`, `order_sn`, `gmt_create`, `gmt_modified`) VALUES (22, 3, 3, '0363932820300003', 'windy', 1, '2018-11-12 14:20:39', 0, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `sms_coupon_history` (`id`, `coupon_id`, `member_id`, `coupon_code`, `member_nickname`, `get_type`, `create_time`, `use_status`, `use_time`, `order_id`, `order_sn`, `gmt_create`, `gmt_modified`) VALUES (23, 4, 3, '0364238275840003', 'windy', 1, '2018-11-12 14:20:42', 0, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `sms_coupon_history` (`id`, `coupon_id`, `member_id`, `coupon_code`, `member_nickname`, `get_type`, `create_time`, `use_status`, `use_time`, `order_id`, `order_sn`, `gmt_create`, `gmt_modified`) VALUES (24, 2, 7, '0385034833070007', 'lion', 1, '2018-11-12 14:24:10', 0, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `sms_coupon_history` (`id`, `coupon_id`, `member_id`, `coupon_code`, `member_nickname`, `get_type`, `create_time`, `use_status`, `use_time`, `order_id`, `order_sn`, `gmt_create`, `gmt_modified`) VALUES (25, 3, 7, '0385350208650007', 'lion', 1, '2018-11-12 14:24:13', 0, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `sms_coupon_history` (`id`, `coupon_id`, `member_id`, `coupon_code`, `member_nickname`, `get_type`, `create_time`, `use_status`, `use_time`, `order_id`, `order_sn`, `gmt_create`, `gmt_modified`) VALUES (26, 4, 7, '0385632733900007', 'lion', 1, '2018-11-12 14:24:16', 0, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `sms_coupon_history` (`id`, `coupon_id`, `member_id`, `coupon_code`, `member_nickname`, `get_type`, `create_time`, `use_status`, `use_time`, `order_id`, `order_sn`, `gmt_create`, `gmt_modified`) VALUES (27, 2, 8, '0388779132990008', 'shari', 1, '2018-11-12 14:24:48', 0, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `sms_coupon_history` (`id`, `coupon_id`, `member_id`, `coupon_code`, `member_nickname`, `get_type`, `create_time`, `use_status`, `use_time`, `order_id`, `order_sn`, `gmt_create`, `gmt_modified`) VALUES (28, 3, 8, '0388943658810008', 'shari', 1, '2018-11-12 14:24:49', 0, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `sms_coupon_history` (`id`, `coupon_id`, `member_id`, `coupon_code`, `member_nickname`, `get_type`, `create_time`, `use_status`, `use_time`, `order_id`, `order_sn`, `gmt_create`, `gmt_modified`) VALUES (29, 4, 8, '0389069398320008', 'shari', 1, '2018-11-12 14:24:51', 0, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `sms_coupon_history` (`id`, `coupon_id`, `member_id`, `coupon_code`, `member_nickname`, `get_type`, `create_time`, `use_status`, `use_time`, `order_id`, `order_sn`, `gmt_create`, `gmt_modified`) VALUES (30, 2, 9, '0390753935250009', 'aewen', 1, '2018-11-12 14:25:08', 0, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `sms_coupon_history` (`id`, `coupon_id`, `member_id`, `coupon_code`, `member_nickname`, `get_type`, `create_time`, `use_status`, `use_time`, `order_id`, `order_sn`, `gmt_create`, `gmt_modified`) VALUES (31, 3, 9, '0390882954470009', 'aewen', 1, '2018-11-12 14:25:09', 0, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `sms_coupon_history` (`id`, `coupon_id`, `member_id`, `coupon_code`, `member_nickname`, `get_type`, `create_time`, `use_status`, `use_time`, `order_id`, `order_sn`, `gmt_create`, `gmt_modified`) VALUES (32, 4, 9, '0391025542810009', 'aewen', 1, '2018-11-12 14:25:10', 0, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `sms_coupon_history` (`id`, `coupon_id`, `member_id`, `coupon_code`, `member_nickname`, `get_type`, `create_time`, `use_status`, `use_time`, `order_id`, `order_sn`, `gmt_create`, `gmt_modified`) VALUES (38, 12, 462245, '3418991835492245', 'roy', 1, '2023-05-08 08:23:10', 1, '2023-05-23 05:32:40', 18500145, '18500145', '2023-05-08 16:23:10.182547', NULL);
INSERT INTO `sms_coupon_history` (`id`, `coupon_id`, `member_id`, `coupon_code`, `member_nickname`, `get_type`, `create_time`, `use_status`, `use_time`, `order_id`, `order_sn`, `gmt_create`, `gmt_modified`) VALUES (39, 12, 1, '1123723946090001', 'test', 1, '2023-05-16 04:27:17', 1, '2023-05-23 05:32:40', 18500145, '18500145', '2023-05-16 12:27:17.244918', NULL);
INSERT INTO `sms_coupon_history` (`id`, `coupon_id`, `member_id`, `coupon_code`, `member_nickname`, `get_type`, `create_time`, `use_status`, `use_time`, `order_id`, `order_sn`, `gmt_create`, `gmt_modified`) VALUES (40, 12, 462245, '3167059211612245', 'roy', 1, '2023-05-23 08:47:51', 0, NULL, NULL, NULL, '2023-05-23 16:47:50.596853', NULL);
COMMIT;

-- ----------------------------
-- Table structure for sms_coupon_product_category_relation
-- ----------------------------
DROP TABLE IF EXISTS `sms_coupon_product_category_relation`;
CREATE TABLE `sms_coupon_product_category_relation` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `coupon_id` bigint DEFAULT NULL,
  `product_category_id` bigint DEFAULT NULL,
  `product_category_name` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '产品分类名称',
  `parent_category_name` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '父分类名称',
  `gmt_create` datetime(6) DEFAULT CURRENT_TIMESTAMP(6),
  `gmt_modified` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 ROW_FORMAT=DYNAMIC COMMENT='优惠券和产品分类关系表';

-- ----------------------------
-- Records of sms_coupon_product_category_relation
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for sms_coupon_product_relation
-- ----------------------------
DROP TABLE IF EXISTS `sms_coupon_product_relation`;
CREATE TABLE `sms_coupon_product_relation` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `coupon_id` bigint DEFAULT NULL,
  `product_id` bigint DEFAULT NULL,
  `product_name` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品名称',
  `product_sn` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品编码',
  `gmt_create` datetime(6) DEFAULT CURRENT_TIMESTAMP(6),
  `gmt_modified` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb3 ROW_FORMAT=DYNAMIC COMMENT='优惠券和产品的关系表';

-- ----------------------------
-- Records of sms_coupon_product_relation
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for sms_flash_promotion
-- ----------------------------
DROP TABLE IF EXISTS `sms_flash_promotion`;
CREATE TABLE `sms_flash_promotion` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `title` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '活动名称',
  `start_date` date DEFAULT NULL COMMENT '开始日期',
  `end_date` date DEFAULT NULL COMMENT '结束日期',
  `status` int DEFAULT NULL COMMENT '上下线状态,1上线、0下线',
  `create_time` datetime DEFAULT NULL COMMENT '秒杀时间段名称',
  `gmt_create` datetime(6) DEFAULT CURRENT_TIMESTAMP(6),
  `gmt_modified` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb3 ROW_FORMAT=DYNAMIC COMMENT='限时购表';

-- ----------------------------
-- Records of sms_flash_promotion
-- ----------------------------
BEGIN;
INSERT INTO `sms_flash_promotion` (`id`, `title`, `start_date`, `end_date`, `status`, `create_time`, `gmt_create`, `gmt_modified`) VALUES (3, '秒杀专场', '2020-02-15', '2027-06-23', 1, '2018-11-16 11:11:31', NULL, NULL);
INSERT INTO `sms_flash_promotion` (`id`, `title`, `start_date`, `end_date`, `status`, `create_time`, `gmt_create`, `gmt_modified`) VALUES (7, '春季家电家具疯狂秒杀6', '2021-11-04', '2021-11-25', 0, '2018-11-16 11:12:35', NULL, NULL);
COMMIT;

-- ----------------------------
-- Table structure for sms_flash_promotion_log
-- ----------------------------
DROP TABLE IF EXISTS `sms_flash_promotion_log`;
CREATE TABLE `sms_flash_promotion_log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `member_id` int DEFAULT NULL,
  `product_id` bigint DEFAULT NULL,
  `member_phone` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_name` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `subscribe_time` datetime DEFAULT NULL COMMENT '会员订阅时间',
  `send_time` datetime DEFAULT NULL,
  `gmt_create` datetime(6) DEFAULT CURRENT_TIMESTAMP(6),
  `gmt_modified` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 ROW_FORMAT=DYNAMIC COMMENT='限时购通知记录';

-- ----------------------------
-- Records of sms_flash_promotion_log
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for sms_flash_promotion_product_relation
-- ----------------------------
DROP TABLE IF EXISTS `sms_flash_promotion_product_relation`;
CREATE TABLE `sms_flash_promotion_product_relation` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '编号',
  `flash_promotion_id` bigint DEFAULT NULL COMMENT '秒杀活动ID->关联sms_flash_promotion表',
  `flash_promotion_session_id` bigint DEFAULT NULL COMMENT '当前日期活动场次编号',
  `product_id` bigint DEFAULT NULL COMMENT '产品ID',
  `flash_promotion_price` decimal(10,2) DEFAULT NULL COMMENT '限时购价格',
  `flash_promotion_count` int DEFAULT NULL COMMENT '限时购数量',
  `flash_promotion_limit` int DEFAULT NULL COMMENT '每人限购数量',
  `sort` int DEFAULT NULL COMMENT '排序',
  `gmt_create` datetime(6) DEFAULT CURRENT_TIMESTAMP(6),
  `gmt_modified` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `idx-product-id` (`product_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=1544584813415948290 DEFAULT CHARSET=utf8mb3 ROW_FORMAT=DYNAMIC COMMENT='商品限时购与商品关系表';

-- ----------------------------
-- Records of sms_flash_promotion_product_relation
-- ----------------------------
BEGIN;
INSERT INTO `sms_flash_promotion_product_relation` (`id`, `flash_promotion_id`, `flash_promotion_session_id`, `product_id`, `flash_promotion_price`, `flash_promotion_count`, `flash_promotion_limit`, `sort`, `gmt_create`, `gmt_modified`) VALUES (26, 3, 2, 32, 60.00, 4, 1, NULL, NULL, NULL);
INSERT INTO `sms_flash_promotion_product_relation` (`id`, `flash_promotion_id`, `flash_promotion_session_id`, `product_id`, `flash_promotion_price`, `flash_promotion_count`, `flash_promotion_limit`, `sort`, `gmt_create`, `gmt_modified`) VALUES (40, 3, 5, 29, 4999.00, 99864894, 1, 100, NULL, NULL);
INSERT INTO `sms_flash_promotion_product_relation` (`id`, `flash_promotion_id`, `flash_promotion_session_id`, `product_id`, `flash_promotion_price`, `flash_promotion_count`, `flash_promotion_limit`, `sort`, `gmt_create`, `gmt_modified`) VALUES (41, 3, 1, 42, 499.00, 100, 1, 2, NULL, NULL);
INSERT INTO `sms_flash_promotion_product_relation` (`id`, `flash_promotion_id`, `flash_promotion_session_id`, `product_id`, `flash_promotion_price`, `flash_promotion_count`, `flash_promotion_limit`, `sort`, `gmt_create`, `gmt_modified`) VALUES (42, 3, 3, 26, 3700.00, 123, 1, NULL, NULL, NULL);
INSERT INTO `sms_flash_promotion_product_relation` (`id`, `flash_promotion_id`, `flash_promotion_session_id`, `product_id`, `flash_promotion_price`, `flash_promotion_count`, `flash_promotion_limit`, `sort`, `gmt_create`, `gmt_modified`) VALUES (43, 3, 4, 26, 3699.00, 9900087, 11, 1, NULL, NULL);
INSERT INTO `sms_flash_promotion_product_relation` (`id`, `flash_promotion_id`, `flash_promotion_session_id`, `product_id`, `flash_promotion_price`, `flash_promotion_count`, `flash_promotion_limit`, `sort`, `gmt_create`, `gmt_modified`) VALUES (45, 3, 1, 27, 2699.00, 100, 1, 99, '2022-07-06 15:31:31.264611', NULL);
COMMIT;

-- ----------------------------
-- Table structure for sms_flash_promotion_session
-- ----------------------------
DROP TABLE IF EXISTS `sms_flash_promotion_session`;
CREATE TABLE `sms_flash_promotion_session` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '编号',
  `name` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '场次名称',
  `start_time` time DEFAULT NULL COMMENT '每日开始时间',
  `end_time` time DEFAULT NULL COMMENT '每日结束时间',
  `status` int DEFAULT NULL COMMENT '启用状态：0->不启用；1->启用',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `gmt_create` datetime(6) DEFAULT CURRENT_TIMESTAMP(6),
  `gmt_modified` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb3 ROW_FORMAT=DYNAMIC COMMENT='限时购场次表';

-- ----------------------------
-- Records of sms_flash_promotion_session
-- ----------------------------
BEGIN;
INSERT INTO `sms_flash_promotion_session` (`id`, `name`, `start_time`, `end_time`, `status`, `create_time`, `gmt_create`, `gmt_modified`) VALUES (1, '16:00场', '08:00:00', '10:00:33', 1, '2018-11-16 13:22:17', NULL, NULL);
INSERT INTO `sms_flash_promotion_session` (`id`, `name`, `start_time`, `end_time`, `status`, `create_time`, `gmt_create`, `gmt_modified`) VALUES (2, '18:00场', '10:00:00', '12:00:00', 1, '2018-11-16 13:22:34', NULL, NULL);
INSERT INTO `sms_flash_promotion_session` (`id`, `name`, `start_time`, `end_time`, `status`, `create_time`, `gmt_create`, `gmt_modified`) VALUES (3, '20:00场', '12:00:00', '14:00:00', 1, '2018-11-16 13:22:37', NULL, NULL);
INSERT INTO `sms_flash_promotion_session` (`id`, `name`, `start_time`, `end_time`, `status`, `create_time`, `gmt_create`, `gmt_modified`) VALUES (4, '10:00场', '02:00:00', '04:00:00', 1, '2018-11-16 13:22:41', NULL, NULL);
INSERT INTO `sms_flash_promotion_session` (`id`, `name`, `start_time`, `end_time`, `status`, `create_time`, `gmt_create`, `gmt_modified`) VALUES (5, '13:00场', '05:00:00', '07:00:00', 1, '2018-11-16 13:22:45', NULL, NULL);
INSERT INTO `sms_flash_promotion_session` (`id`, `name`, `start_time`, `end_time`, `status`, `create_time`, `gmt_create`, `gmt_modified`) VALUES (6, '18:00', '18:00:00', '20:00:00', 0, '2018-11-16 13:21:34', NULL, NULL);
INSERT INTO `sms_flash_promotion_session` (`id`, `name`, `start_time`, `end_time`, `status`, `create_time`, `gmt_create`, `gmt_modified`) VALUES (7, '20:00', '20:00:33', '21:00:33', 0, '2018-11-16 13:22:55', NULL, NULL);
COMMIT;

-- ----------------------------
-- Table structure for sms_home_advertise
-- ----------------------------
DROP TABLE IF EXISTS `sms_home_advertise`;
CREATE TABLE `sms_home_advertise` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `type` int DEFAULT NULL COMMENT '轮播位置：0->PC首页轮播；1->app首页轮播',
  `pic` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `start_time` datetime DEFAULT NULL,
  `end_time` datetime DEFAULT NULL,
  `status` int DEFAULT NULL COMMENT '上下线状态：0->下线；1->上线',
  `click_count` int DEFAULT NULL COMMENT '点击数',
  `order_count` int DEFAULT NULL COMMENT '下单数',
  `url` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '链接地址',
  `note` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '备注',
  `sort` int DEFAULT '0' COMMENT '排序',
  `gmt_create` datetime(6) DEFAULT CURRENT_TIMESTAMP(6),
  `gmt_modified` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb3 ROW_FORMAT=DYNAMIC COMMENT='首页轮播广告表';

-- ----------------------------
-- Records of sms_home_advertise
-- ----------------------------
BEGIN;
INSERT INTO `sms_home_advertise` (`id`, `name`, `type`, `pic`, `start_time`, `end_time`, `status`, `click_count`, `order_count`, `url`, `note`, `sort`, `gmt_create`, `gmt_modified`) VALUES (2, '夏季大热促销', 1, 'http://macro-oss.oss-cn-shenzhen.aliyuncs.com/mall/images/20180615/xiaomi.jpg', '2018-11-01 14:01:37', '2023-11-15 14:01:37', 0, 0, 0, NULL, '夏季大热促销', 0, NULL, NULL);
INSERT INTO `sms_home_advertise` (`id`, `name`, `type`, `pic`, `start_time`, `end_time`, `status`, `click_count`, `order_count`, `url`, `note`, `sort`, `gmt_create`, `gmt_modified`) VALUES (3, '夏季大热促销1', 1, 'http://macro-oss.oss-cn-shenzhen.aliyuncs.com/mall/images/20180607/5ac1bf58Ndefaac16.jpg', '2018-11-13 14:01:37', '2023-11-13 14:01:37', 0, 0, 0, NULL, '夏季大热促销1', 0, NULL, NULL);
INSERT INTO `sms_home_advertise` (`id`, `name`, `type`, `pic`, `start_time`, `end_time`, `status`, `click_count`, `order_count`, `url`, `note`, `sort`, `gmt_create`, `gmt_modified`) VALUES (4, '夏季大热促销2', 1, 'http://macro-oss.oss-cn-shenzhen.aliyuncs.com/mall/images/20180615/5a9d248cN071f4959.jpg', '2018-11-13 14:01:37', '2023-11-13 14:01:37', 1, 0, 0, NULL, '夏季大热促销2', 0, NULL, NULL);
INSERT INTO `sms_home_advertise` (`id`, `name`, `type`, `pic`, `start_time`, `end_time`, `status`, `click_count`, `order_count`, `url`, `note`, `sort`, `gmt_create`, `gmt_modified`) VALUES (9, '电影推荐广告', 1, 'http://macro-oss.oss-cn-shenzhen.aliyuncs.com/mall/images/20181113/movie_ad.jpg', '2018-11-01 00:00:00', '2023-12-01 00:00:00', 1, 0, 0, 'www.baidu.com', '电影推荐广告', 100, NULL, NULL);
INSERT INTO `sms_home_advertise` (`id`, `name`, `type`, `pic`, `start_time`, `end_time`, `status`, `click_count`, `order_count`, `url`, `note`, `sort`, `gmt_create`, `gmt_modified`) VALUES (10, '汽车促销广告', 1, 'http://macro-oss.oss-cn-shenzhen.aliyuncs.com/mall/images/20181113/car_ad.jpg', '2018-11-13 00:00:00', '2023-11-24 00:00:00', 1, 0, 0, 'xxx', NULL, 99, NULL, NULL);
INSERT INTO `sms_home_advertise` (`id`, `name`, `type`, `pic`, `start_time`, `end_time`, `status`, `click_count`, `order_count`, `url`, `note`, `sort`, `gmt_create`, `gmt_modified`) VALUES (11, '汽车推荐广告', 1, 'http://tuling-mall.oss-cn-shenzhen.aliyuncs.com/tulingmall/images/20200318/201907121110574365537.jpg', '2018-11-13 00:00:00', '2023-12-30 00:00:00', 1, 0, 0, '39', NULL, 98, NULL, NULL);
COMMIT;

-- ----------------------------
-- Table structure for sms_home_brand
-- ----------------------------
DROP TABLE IF EXISTS `sms_home_brand`;
CREATE TABLE `sms_home_brand` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `brand_id` bigint DEFAULT NULL COMMENT '品牌ID[关联pms_brand品牌推荐]',
  `brand_name` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '品牌名称',
  `recommend_status` int DEFAULT NULL COMMENT '推荐状态:1推荐，0取消推荐',
  `sort` int DEFAULT NULL COMMENT '排序序号',
  `gmt_create` datetime(6) DEFAULT CURRENT_TIMESTAMP(6),
  `gmt_modified` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8mb3 ROW_FORMAT=DYNAMIC COMMENT='首页推荐品牌表';

-- ----------------------------
-- Records of sms_home_brand
-- ----------------------------
BEGIN;
INSERT INTO `sms_home_brand` (`id`, `brand_id`, `brand_name`, `recommend_status`, `sort`, `gmt_create`, `gmt_modified`) VALUES (1, 1, '万和', 1, 200, NULL, NULL);
INSERT INTO `sms_home_brand` (`id`, `brand_id`, `brand_name`, `recommend_status`, `sort`, `gmt_create`, `gmt_modified`) VALUES (2, 2, '三星', 1, 0, NULL, NULL);
INSERT INTO `sms_home_brand` (`id`, `brand_id`, `brand_name`, `recommend_status`, `sort`, `gmt_create`, `gmt_modified`) VALUES (6, 6, '小米', 1, 300, NULL, NULL);
INSERT INTO `sms_home_brand` (`id`, `brand_id`, `brand_name`, `recommend_status`, `sort`, `gmt_create`, `gmt_modified`) VALUES (8, 5, '方太', 1, 100, NULL, NULL);
INSERT INTO `sms_home_brand` (`id`, `brand_id`, `brand_name`, `recommend_status`, `sort`, `gmt_create`, `gmt_modified`) VALUES (32, 50, '海澜之家', 1, 0, NULL, NULL);
INSERT INTO `sms_home_brand` (`id`, `brand_id`, `brand_name`, `recommend_status`, `sort`, `gmt_create`, `gmt_modified`) VALUES (33, 51, '苹果', 1, 0, NULL, NULL);
INSERT INTO `sms_home_brand` (`id`, `brand_id`, `brand_name`, `recommend_status`, `sort`, `gmt_create`, `gmt_modified`) VALUES (35, 3, '华为', 1, 0, NULL, NULL);
INSERT INTO `sms_home_brand` (`id`, `brand_id`, `brand_name`, `recommend_status`, `sort`, `gmt_create`, `gmt_modified`) VALUES (36, 4, '格力', 0, 0, NULL, NULL);
INSERT INTO `sms_home_brand` (`id`, `brand_id`, `brand_name`, `recommend_status`, `sort`, `gmt_create`, `gmt_modified`) VALUES (37, 5, '方太', 1, 0, NULL, NULL);
INSERT INTO `sms_home_brand` (`id`, `brand_id`, `brand_name`, `recommend_status`, `sort`, `gmt_create`, `gmt_modified`) VALUES (38, 1, '万和', 1, 0, NULL, NULL);
INSERT INTO `sms_home_brand` (`id`, `brand_id`, `brand_name`, `recommend_status`, `sort`, `gmt_create`, `gmt_modified`) VALUES (39, 21, 'OPPO', 1, 1, NULL, NULL);
COMMIT;

-- ----------------------------
-- Table structure for sms_home_new_product
-- ----------------------------
DROP TABLE IF EXISTS `sms_home_new_product`;
CREATE TABLE `sms_home_new_product` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `product_id` bigint DEFAULT NULL,
  `product_name` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `recommend_status` int DEFAULT NULL,
  `sort` int DEFAULT NULL,
  `gmt_create` datetime(6) DEFAULT CURRENT_TIMESTAMP(6),
  `gmt_modified` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb3 ROW_FORMAT=DYNAMIC COMMENT='新鲜好物表';

-- ----------------------------
-- Records of sms_home_new_product
-- ----------------------------
BEGIN;
INSERT INTO `sms_home_new_product` (`id`, `product_id`, `product_name`, `recommend_status`, `sort`, `gmt_create`, `gmt_modified`) VALUES (2, 27, '小米8 全面屏游戏智能手机 6GB+64GB 黑色 全网通4G 双卡双待', 1, 200, NULL, NULL);
INSERT INTO `sms_home_new_product` (`id`, `product_id`, `product_name`, `recommend_status`, `sort`, `gmt_create`, `gmt_modified`) VALUES (8, 26, '华为 HUAWEI P20 ', 1, 0, NULL, NULL);
INSERT INTO `sms_home_new_product` (`id`, `product_id`, `product_name`, `recommend_status`, `sort`, `gmt_create`, `gmt_modified`) VALUES (15, 42, '朵唯（DOOV）D11Pro 6GB+64GB 冰海兰 智能手机 4G全网通 老人学生双卡双待手机', 1, 300, NULL, NULL);
INSERT INTO `sms_home_new_product` (`id`, `product_id`, `product_name`, `recommend_status`, `sort`, `gmt_create`, `gmt_modified`) VALUES (16, 29, 'Apple iPhone 8 Plus 64GB 红色特别版 移动联通电信4G手机', 1, 0, NULL, NULL);
COMMIT;

-- ----------------------------
-- Table structure for sms_home_recommend_product
-- ----------------------------
DROP TABLE IF EXISTS `sms_home_recommend_product`;
CREATE TABLE `sms_home_recommend_product` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `product_id` bigint DEFAULT NULL,
  `product_name` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `recommend_status` int DEFAULT NULL,
  `sort` int DEFAULT NULL,
  `gmt_create` datetime(6) DEFAULT CURRENT_TIMESTAMP(6),
  `gmt_modified` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb3 ROW_FORMAT=DYNAMIC COMMENT='人气推荐商品表';

-- ----------------------------
-- Records of sms_home_recommend_product
-- ----------------------------
BEGIN;
INSERT INTO `sms_home_recommend_product` (`id`, `product_id`, `product_name`, `recommend_status`, `sort`, `gmt_create`, `gmt_modified`) VALUES (3, 26, '华为 HUAWEI P20 ', 1, 0, NULL, NULL);
INSERT INTO `sms_home_recommend_product` (`id`, `product_id`, `product_name`, `recommend_status`, `sort`, `gmt_create`, `gmt_modified`) VALUES (4, 27, '小米8 全面屏游戏智能手机 6GB+64GB 黑色 全网通4G 双卡双待', 1, 0, NULL, NULL);
INSERT INTO `sms_home_recommend_product` (`id`, `product_id`, `product_name`, `recommend_status`, `sort`, `gmt_create`, `gmt_modified`) VALUES (5, 28, '小米 红米5A 全网通版 3GB+32GB 香槟金 移动联通电信4G手机 双卡双待', 1, 0, NULL, NULL);
INSERT INTO `sms_home_recommend_product` (`id`, `product_id`, `product_name`, `recommend_status`, `sort`, `gmt_create`, `gmt_modified`) VALUES (6, 29, 'Apple iPhone 8 Plus 64GB 红色特别版 移动联通电信4G手机', 1, 0, NULL, NULL);
INSERT INTO `sms_home_recommend_product` (`id`, `product_id`, `product_name`, `recommend_status`, `sort`, `gmt_create`, `gmt_modified`) VALUES (7, 30, 'HLA海澜之家简约动物印花短袖T恤', 0, 100, NULL, NULL);
COMMIT;

-- ----------------------------
-- Table structure for sms_home_recommend_subject
-- ----------------------------
DROP TABLE IF EXISTS `sms_home_recommend_subject`;
CREATE TABLE `sms_home_recommend_subject` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `subject_id` bigint DEFAULT NULL,
  `subject_name` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `recommend_status` int DEFAULT NULL,
  `sort` int DEFAULT NULL,
  `gmt_create` datetime(6) DEFAULT CURRENT_TIMESTAMP(6),
  `gmt_modified` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb3 ROW_FORMAT=DYNAMIC COMMENT='首页推荐专题表';

-- ----------------------------
-- Records of sms_home_recommend_subject
-- ----------------------------
BEGIN;
INSERT INTO `sms_home_recommend_subject` (`id`, `subject_id`, `subject_name`, `recommend_status`, `sort`, `gmt_create`, `gmt_modified`) VALUES (14, 1, 'polo衬衫的也时尚', 1, 0, NULL, NULL);
INSERT INTO `sms_home_recommend_subject` (`id`, `subject_id`, `subject_name`, `recommend_status`, `sort`, `gmt_create`, `gmt_modified`) VALUES (15, 2, '大牌手机低价秒', 1, 0, NULL, NULL);
INSERT INTO `sms_home_recommend_subject` (`id`, `subject_id`, `subject_name`, `recommend_status`, `sort`, `gmt_create`, `gmt_modified`) VALUES (16, 3, '晓龙845新品上市', 1, 0, NULL, NULL);
INSERT INTO `sms_home_recommend_subject` (`id`, `subject_id`, `subject_name`, `recommend_status`, `sort`, `gmt_create`, `gmt_modified`) VALUES (17, 4, '夏天应该穿什么', 1, 0, NULL, NULL);
INSERT INTO `sms_home_recommend_subject` (`id`, `subject_id`, `subject_name`, `recommend_status`, `sort`, `gmt_create`, `gmt_modified`) VALUES (18, 5, '夏季精选', 1, 100, NULL, NULL);
INSERT INTO `sms_home_recommend_subject` (`id`, `subject_id`, `subject_name`, `recommend_status`, `sort`, `gmt_create`, `gmt_modified`) VALUES (19, 6, '品牌手机降价', 1, 0, NULL, NULL);
COMMIT;

SET FOREIGN_KEY_CHECKS = 1;
