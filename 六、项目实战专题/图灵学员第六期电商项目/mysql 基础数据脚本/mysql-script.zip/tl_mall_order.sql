/*
 Navicat Premium Data Transfer

 Source Server         : 192.168.65.223
 Source Server Type    : MySQL
 Source Server Version : 80029 (8.0.29)
 Source Host           : 192.168.65.223:3306
 Source Schema         : tl_mall_order

 Target Server Type    : MySQL
 Target Server Version : 80029 (8.0.29)
 File Encoding         : 65001

 Date: 31/10/2023 13:56:52
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for local_transaction_log
-- ----------------------------
DROP TABLE IF EXISTS `local_transaction_log`;
CREATE TABLE `local_transaction_log` (
  `tx_no` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `create_time` datetime DEFAULT NULL,
  PRIMARY KEY (`tx_no`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of local_transaction_log
-- ----------------------------
BEGIN;
INSERT INTO `local_transaction_log` (`tx_no`, `create_time`) VALUES ('089d953f-e9e7-4867-89a8-de031587e377', '2023-05-28 15:06:46');
INSERT INTO `local_transaction_log` (`tx_no`, `create_time`) VALUES ('08c487e8-a734-4b57-98b1-cd4dfd28789b', '2022-11-09 16:18:22');
INSERT INTO `local_transaction_log` (`tx_no`, `create_time`) VALUES ('0bd737f3-ca6e-4738-a8b7-02ee8470ba5d', '2022-11-03 17:35:05');
INSERT INTO `local_transaction_log` (`tx_no`, `create_time`) VALUES ('0cdaee3b-c028-453b-9591-1318672e6c67', '2022-11-03 17:29:30');
INSERT INTO `local_transaction_log` (`tx_no`, `create_time`) VALUES ('11700001', '2022-11-09 15:31:28');
INSERT INTO `local_transaction_log` (`tx_no`, `create_time`) VALUES ('11700101', '2022-11-09 15:33:28');
INSERT INTO `local_transaction_log` (`tx_no`, `create_time`) VALUES ('11700201', '2022-11-09 15:34:30');
INSERT INTO `local_transaction_log` (`tx_no`, `create_time`) VALUES ('11700301', '2022-11-09 15:37:50');
INSERT INTO `local_transaction_log` (`tx_no`, `create_time`) VALUES ('11700401', '2022-11-09 15:38:59');
INSERT INTO `local_transaction_log` (`tx_no`, `create_time`) VALUES ('11700501', '2022-11-09 15:42:09');
INSERT INTO `local_transaction_log` (`tx_no`, `create_time`) VALUES ('11700601', '2022-11-09 15:43:15');
INSERT INTO `local_transaction_log` (`tx_no`, `create_time`) VALUES ('11700701', '2022-11-09 15:44:41');
INSERT INTO `local_transaction_log` (`tx_no`, `create_time`) VALUES ('11700801', '2022-11-09 15:45:21');
INSERT INTO `local_transaction_log` (`tx_no`, `create_time`) VALUES ('11700901', '2022-11-09 15:47:24');
INSERT INTO `local_transaction_log` (`tx_no`, `create_time`) VALUES ('11701001', '2022-11-10 09:14:06');
INSERT INTO `local_transaction_log` (`tx_no`, `create_time`) VALUES ('11900001', '2022-11-10 09:17:12');
INSERT INTO `local_transaction_log` (`tx_no`, `create_time`) VALUES ('11900101', '2022-11-10 09:20:27');
INSERT INTO `local_transaction_log` (`tx_no`, `create_time`) VALUES ('11e5bcb1-fce2-4f76-8820-04ab718ef46a', '2022-11-09 16:13:44');
INSERT INTO `local_transaction_log` (`tx_no`, `create_time`) VALUES ('1732d9d9-b58c-4927-a17d-94f49074e522', '2022-11-09 16:09:35');
INSERT INTO `local_transaction_log` (`tx_no`, `create_time`) VALUES ('181005cd-2574-4420-ab5b-1e719ebc64eb', '2022-11-10 11:23:50');
INSERT INTO `local_transaction_log` (`tx_no`, `create_time`) VALUES ('1f75dd74-052b-4221-81c7-70d38bb8150a', '2022-11-09 16:15:23');
INSERT INTO `local_transaction_log` (`tx_no`, `create_time`) VALUES ('21affc9e-cde6-4bb5-aa3f-dab4edb3f889', '2022-11-09 16:00:34');
INSERT INTO `local_transaction_log` (`tx_no`, `create_time`) VALUES ('2c2d5b83-803c-4731-9f0a-3ebcd5d8874e', '2022-11-09 15:28:46');
INSERT INTO `local_transaction_log` (`tx_no`, `create_time`) VALUES ('2d8d29eb-ba62-424f-97fb-42f8641e2b70', '2023-05-28 15:02:29');
INSERT INTO `local_transaction_log` (`tx_no`, `create_time`) VALUES ('2f4146fd-6cec-4d14-a88a-d1d7c45100be', '2023-05-28 14:57:36');
INSERT INTO `local_transaction_log` (`tx_no`, `create_time`) VALUES ('320624df-86de-45f3-bd46-e742113c09b1', '2022-11-09 16:12:36');
INSERT INTO `local_transaction_log` (`tx_no`, `create_time`) VALUES ('3e9d81e9-dbbd-4675-9900-98cc096a1d88', '2022-11-09 16:05:02');
INSERT INTO `local_transaction_log` (`tx_no`, `create_time`) VALUES ('3f472c30-aaad-4865-97aa-b8d82878be8a', '2022-11-09 16:22:24');
INSERT INTO `local_transaction_log` (`tx_no`, `create_time`) VALUES ('403e229d-e585-48b5-b0c2-9950d5495893', '2022-11-03 17:53:57');
INSERT INTO `local_transaction_log` (`tx_no`, `create_time`) VALUES ('4239dd37-ace6-4127-acfd-79bddc3ba77c', '2023-05-28 15:03:54');
INSERT INTO `local_transaction_log` (`tx_no`, `create_time`) VALUES ('446cc6d0-960f-47e1-b542-f0f15bc14309', '2022-10-21 21:37:33');
INSERT INTO `local_transaction_log` (`tx_no`, `create_time`) VALUES ('465cb9af-62d5-4061-bb01-5ebb3ff38f0f', '2022-11-09 15:51:15');
INSERT INTO `local_transaction_log` (`tx_no`, `create_time`) VALUES ('4693f498-1441-4e2b-a9b1-c3b76d27ec1a', '2022-11-04 22:13:34');
INSERT INTO `local_transaction_log` (`tx_no`, `create_time`) VALUES ('4a2ac23a-401a-462a-a011-ce9d3cfdc66c', '2022-10-21 21:46:59');
INSERT INTO `local_transaction_log` (`tx_no`, `create_time`) VALUES ('4a7662b3-8b5b-4dea-8c1a-4789a2aa49cf', '2022-11-10 11:23:53');
INSERT INTO `local_transaction_log` (`tx_no`, `create_time`) VALUES ('5046b706-9337-43bc-a2a0-82aef7f92bc2', '2022-11-09 15:28:43');
INSERT INTO `local_transaction_log` (`tx_no`, `create_time`) VALUES ('51cae584-f31f-47fb-a2cc-8a7318dbf427', '2022-11-03 17:35:21');
INSERT INTO `local_transaction_log` (`tx_no`, `create_time`) VALUES ('5f4cb979-680e-4fd7-be13-59b136966016', '2022-11-10 09:29:05');
INSERT INTO `local_transaction_log` (`tx_no`, `create_time`) VALUES ('60efdb6d-0e4e-43c9-9fc1-19c360f392d1', '2022-11-04 21:52:32');
INSERT INTO `local_transaction_log` (`tx_no`, `create_time`) VALUES ('64eba44d-2972-4302-a3fc-3b070532768b', '2022-11-09 15:59:20');
INSERT INTO `local_transaction_log` (`tx_no`, `create_time`) VALUES ('665b4f45-06c8-4424-a0f6-76b05ef50885', '2022-11-03 17:38:40');
INSERT INTO `local_transaction_log` (`tx_no`, `create_time`) VALUES ('6683f818-5f9a-43b8-a393-fd51e8baf995', '2023-05-28 15:07:03');
INSERT INTO `local_transaction_log` (`tx_no`, `create_time`) VALUES ('6ad48764-22cf-4bd0-a423-b4ceaa013f42', '2022-11-09 15:57:42');
INSERT INTO `local_transaction_log` (`tx_no`, `create_time`) VALUES ('6bc4d3f2-10bd-4c0a-851f-8aaad3498e00', '2022-11-09 15:50:59');
INSERT INTO `local_transaction_log` (`tx_no`, `create_time`) VALUES ('6ee72e6f-0eba-4861-8a62-2e30c94ac424', '2022-11-04 17:04:29');
INSERT INTO `local_transaction_log` (`tx_no`, `create_time`) VALUES ('74098ff7-c0bd-4937-bfcd-8506b14cb381', '2022-11-09 15:27:44');
INSERT INTO `local_transaction_log` (`tx_no`, `create_time`) VALUES ('8530bb55-9e52-4a2b-aca0-0201601a8d8d', '2022-11-09 15:59:42');
INSERT INTO `local_transaction_log` (`tx_no`, `create_time`) VALUES ('854f114f-513a-4337-856e-face02448303', '2022-11-09 15:51:49');
INSERT INTO `local_transaction_log` (`tx_no`, `create_time`) VALUES ('85e2e88c-435f-4b17-9ae2-5cf55b1f5655', '2023-05-28 14:58:51');
INSERT INTO `local_transaction_log` (`tx_no`, `create_time`) VALUES ('867c6fea-b3e3-45b4-a061-7b7c2a23e6f9', '2022-11-10 09:27:26');
INSERT INTO `local_transaction_log` (`tx_no`, `create_time`) VALUES ('97843d34-3f0d-48f8-a34f-1838d606e748', '2022-11-09 15:52:42');
INSERT INTO `local_transaction_log` (`tx_no`, `create_time`) VALUES ('97decb9a-7048-446b-810f-72cecff99190', '2023-05-28 15:04:10');
INSERT INTO `local_transaction_log` (`tx_no`, `create_time`) VALUES ('984358e0-fb28-4cf0-a9e1-ebc238b453ba', '2022-10-21 21:31:45');
INSERT INTO `local_transaction_log` (`tx_no`, `create_time`) VALUES ('9bc4dd9e-d997-470f-ba8b-135e34d4d755', '2022-11-10 09:29:33');
INSERT INTO `local_transaction_log` (`tx_no`, `create_time`) VALUES ('a138b564-428e-4658-a15b-056aa8f0a4be', '2022-11-10 09:28:48');
INSERT INTO `local_transaction_log` (`tx_no`, `create_time`) VALUES ('a80f6e69-5209-41a9-a12d-4a1a9769902b', '2022-10-21 21:34:33');
INSERT INTO `local_transaction_log` (`tx_no`, `create_time`) VALUES ('ac0d7ea2-a680-4996-a86d-a00f92111593', '2022-11-09 16:01:54');
INSERT INTO `local_transaction_log` (`tx_no`, `create_time`) VALUES ('ad827ed0-eb00-453a-b099-92d6b474f6a2', '2022-11-09 15:59:34');
INSERT INTO `local_transaction_log` (`tx_no`, `create_time`) VALUES ('b6599e8c-761e-4e15-bcd5-8ebc00162425', '2022-11-09 16:13:18');
INSERT INTO `local_transaction_log` (`tx_no`, `create_time`) VALUES ('ba0a3e14-be6d-46f6-9875-8cc21f51581d', '2022-11-09 16:17:16');
INSERT INTO `local_transaction_log` (`tx_no`, `create_time`) VALUES ('be93a206-2619-4999-b826-5c09b372e1f9', '2023-05-28 15:05:52');
INSERT INTO `local_transaction_log` (`tx_no`, `create_time`) VALUES ('c5e03d4b-eb64-4e1c-a991-b524fa33dace', '2022-11-04 21:45:21');
INSERT INTO `local_transaction_log` (`tx_no`, `create_time`) VALUES ('c8a28a74-60f5-471d-836b-03f970d27f85', '2022-11-04 21:49:15');
INSERT INTO `local_transaction_log` (`tx_no`, `create_time`) VALUES ('cc40c7dd-7bd9-4477-93f5-104929ec61c8', '2022-11-09 16:05:17');
INSERT INTO `local_transaction_log` (`tx_no`, `create_time`) VALUES ('cf2aabc3-7aad-4615-a0bc-afdddf6d4f67', '2022-11-09 16:02:39');
INSERT INTO `local_transaction_log` (`tx_no`, `create_time`) VALUES ('d11d71c6-e7f6-4f20-a937-c93042801806', '2023-05-28 15:07:20');
INSERT INTO `local_transaction_log` (`tx_no`, `create_time`) VALUES ('d25bb7d2-ad0f-4307-8a45-843f4ffa6415', '2022-11-10 09:29:18');
INSERT INTO `local_transaction_log` (`tx_no`, `create_time`) VALUES ('d7a97e50-c2a4-4d94-8147-a3236ca5c8dd', '2022-11-03 17:30:30');
INSERT INTO `local_transaction_log` (`tx_no`, `create_time`) VALUES ('d8219907-8e10-4bd9-a9b3-49fd3b859500', '2022-11-04 21:44:02');
INSERT INTO `local_transaction_log` (`tx_no`, `create_time`) VALUES ('de5a5dc0-462c-45d5-a6aa-6a3ac9ac6f21', '2022-11-09 16:06:54');
INSERT INTO `local_transaction_log` (`tx_no`, `create_time`) VALUES ('dfef74d3-72d5-4453-be37-8b6df6c21f15', '2022-11-09 15:25:11');
INSERT INTO `local_transaction_log` (`tx_no`, `create_time`) VALUES ('e93920e6-0f2d-4090-b262-9a4923c81390', '2022-11-09 16:18:49');
INSERT INTO `local_transaction_log` (`tx_no`, `create_time`) VALUES ('ea3125f1-de5f-40a1-a818-3b448c64bd9e', '2022-11-09 16:00:16');
INSERT INTO `local_transaction_log` (`tx_no`, `create_time`) VALUES ('f91276f3-c48b-4ca0-92aa-915c2226e5f8', '2022-11-09 16:13:02');
INSERT INTO `local_transaction_log` (`tx_no`, `create_time`) VALUES ('fb304df1-32a9-4f98-ba5b-8b67582f10cb', '2022-11-09 16:04:28');
INSERT INTO `local_transaction_log` (`tx_no`, `create_time`) VALUES ('ff5924b1-a24b-421d-96e4-9c91d47b4a0a', '2022-11-09 15:53:33');
COMMIT;

-- ----------------------------
-- Table structure for local_transaction_log_copy1
-- ----------------------------
DROP TABLE IF EXISTS `local_transaction_log_copy1`;
CREATE TABLE `local_transaction_log_copy1` (
  `tx_no` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `create_time` datetime DEFAULT NULL,
  PRIMARY KEY (`tx_no`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of local_transaction_log_copy1
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for oms_company_address
-- ----------------------------
DROP TABLE IF EXISTS `oms_company_address`;
CREATE TABLE `oms_company_address` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `address_name` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '地址名称',
  `send_status` int DEFAULT NULL COMMENT '默认发货地址：0->否；1->是',
  `receive_status` int DEFAULT NULL COMMENT '是否默认收货地址：0->否；1->是',
  `name` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '收发货人姓名',
  `phone` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '收货人电话',
  `province` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '省/直辖市',
  `city` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '市',
  `region` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '区',
  `detail_address` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '详细地址',
  `gmt_create` datetime(6) DEFAULT CURRENT_TIMESTAMP(6),
  `gmt_modified` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3 ROW_FORMAT=DYNAMIC COMMENT='公司收发货地址表';

-- ----------------------------
-- Records of oms_company_address
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for oms_order_0
-- ----------------------------
DROP TABLE IF EXISTS `oms_order_0`;
CREATE TABLE `oms_order_0` (
  `id` bigint NOT NULL DEFAULT '0' COMMENT '订单id',
  `member_id` bigint NOT NULL,
  `coupon_id` bigint DEFAULT NULL,
  `order_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '订单编号',
  `create_time` datetime DEFAULT NULL COMMENT '提交时间',
  `member_username` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '用户帐号',
  `total_amount` decimal(10,2) DEFAULT NULL COMMENT '订单总金额',
  `pay_amount` decimal(10,2) DEFAULT NULL COMMENT '应付金额（实际支付金额）',
  `freight_amount` decimal(10,2) DEFAULT NULL COMMENT '运费金额',
  `promotion_amount` decimal(10,2) DEFAULT NULL COMMENT '促销优化金额（促销价、满减、阶梯价）',
  `integration_amount` decimal(10,2) DEFAULT NULL COMMENT '积分抵扣金额',
  `coupon_amount` decimal(10,2) DEFAULT NULL COMMENT '优惠券抵扣金额',
  `discount_amount` decimal(10,2) DEFAULT NULL COMMENT '管理员后台调整订单使用的折扣金额',
  `pay_type` int DEFAULT NULL COMMENT '支付方式：0->未支付；1->支付宝；2->微信',
  `source_type` int DEFAULT NULL COMMENT '订单来源：0->PC订单；1->app订单',
  `status` int DEFAULT NULL COMMENT '订单状态：0->待付款；1->待发货；2->已发货；3->已完成；4->已关闭；5->无效订单',
  `order_type` int DEFAULT NULL COMMENT '订单类型：0->正常订单；1->秒杀订单',
  `delivery_company` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '物流公司(配送方式)',
  `delivery_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '物流单号',
  `auto_confirm_day` int DEFAULT NULL COMMENT '自动确认时间（天）',
  `integration` int DEFAULT NULL COMMENT '可以获得的积分',
  `growth` int DEFAULT NULL COMMENT '可以活动的成长值',
  `promotion_info` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '活动信息',
  `bill_type` int DEFAULT NULL COMMENT '发票类型：0->不开发票；1->电子发票；2->纸质发票',
  `bill_header` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '发票抬头',
  `bill_content` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '发票内容',
  `bill_receiver_phone` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '收票人电话',
  `bill_receiver_email` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '收票人邮箱',
  `receiver_name` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci NOT NULL COMMENT '收货人姓名',
  `receiver_phone` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci NOT NULL COMMENT '收货人电话',
  `receiver_post_code` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '收货人邮编',
  `receiver_province` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '省份/直辖市',
  `receiver_city` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '城市',
  `receiver_region` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '区',
  `receiver_detail_address` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '详细地址',
  `note` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '订单备注',
  `confirm_status` int DEFAULT NULL COMMENT '确认收货状态：0->未确认；1->已确认',
  `delete_status` int NOT NULL DEFAULT '0' COMMENT '删除状态：0->未删除；1->已删除',
  `use_integration` int DEFAULT NULL COMMENT '下单时使用的积分',
  `payment_time` datetime DEFAULT NULL COMMENT '支付时间',
  `delivery_time` datetime DEFAULT NULL COMMENT '发货时间',
  `receive_time` datetime DEFAULT NULL COMMENT '确认收货时间',
  `comment_time` datetime DEFAULT NULL COMMENT '评价时间',
  `modify_time` datetime DEFAULT NULL COMMENT '修改时间',
  `qrcode` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '支付二维码地址',
  `gmt_create` datetime(6) DEFAULT CURRENT_TIMESTAMP(6),
  `gmt_modified` datetime(6) DEFAULT NULL,
  `version` int DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ordersn` (`order_sn`),
  KEY `idx_member_id` (`member_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of oms_order_0
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for oms_order_1
-- ----------------------------
DROP TABLE IF EXISTS `oms_order_1`;
CREATE TABLE `oms_order_1` (
  `id` bigint NOT NULL DEFAULT '0' COMMENT '订单id',
  `member_id` bigint NOT NULL,
  `coupon_id` bigint DEFAULT NULL,
  `order_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '订单编号',
  `create_time` datetime DEFAULT NULL COMMENT '提交时间',
  `member_username` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '用户帐号',
  `total_amount` decimal(10,2) DEFAULT NULL COMMENT '订单总金额',
  `pay_amount` decimal(10,2) DEFAULT NULL COMMENT '应付金额（实际支付金额）',
  `freight_amount` decimal(10,2) DEFAULT NULL COMMENT '运费金额',
  `promotion_amount` decimal(10,2) DEFAULT NULL COMMENT '促销优化金额（促销价、满减、阶梯价）',
  `integration_amount` decimal(10,2) DEFAULT NULL COMMENT '积分抵扣金额',
  `coupon_amount` decimal(10,2) DEFAULT NULL COMMENT '优惠券抵扣金额',
  `discount_amount` decimal(10,2) DEFAULT NULL COMMENT '管理员后台调整订单使用的折扣金额',
  `pay_type` int DEFAULT NULL COMMENT '支付方式：0->未支付；1->支付宝；2->微信',
  `source_type` int DEFAULT NULL COMMENT '订单来源：0->PC订单；1->app订单',
  `status` int DEFAULT NULL COMMENT '订单状态：0->待付款；1->待发货；2->已发货；3->已完成；4->已关闭；5->无效订单',
  `order_type` int DEFAULT NULL COMMENT '订单类型：0->正常订单；1->秒杀订单',
  `delivery_company` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '物流公司(配送方式)',
  `delivery_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '物流单号',
  `auto_confirm_day` int DEFAULT NULL COMMENT '自动确认时间（天）',
  `integration` int DEFAULT NULL COMMENT '可以获得的积分',
  `growth` int DEFAULT NULL COMMENT '可以活动的成长值',
  `promotion_info` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '活动信息',
  `bill_type` int DEFAULT NULL COMMENT '发票类型：0->不开发票；1->电子发票；2->纸质发票',
  `bill_header` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '发票抬头',
  `bill_content` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '发票内容',
  `bill_receiver_phone` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '收票人电话',
  `bill_receiver_email` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '收票人邮箱',
  `receiver_name` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci NOT NULL COMMENT '收货人姓名',
  `receiver_phone` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci NOT NULL COMMENT '收货人电话',
  `receiver_post_code` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '收货人邮编',
  `receiver_province` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '省份/直辖市',
  `receiver_city` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '城市',
  `receiver_region` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '区',
  `receiver_detail_address` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '详细地址',
  `note` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '订单备注',
  `confirm_status` int DEFAULT NULL COMMENT '确认收货状态：0->未确认；1->已确认',
  `delete_status` int NOT NULL DEFAULT '0' COMMENT '删除状态：0->未删除；1->已删除',
  `use_integration` int DEFAULT NULL COMMENT '下单时使用的积分',
  `payment_time` datetime DEFAULT NULL COMMENT '支付时间',
  `delivery_time` datetime DEFAULT NULL COMMENT '发货时间',
  `receive_time` datetime DEFAULT NULL COMMENT '确认收货时间',
  `comment_time` datetime DEFAULT NULL COMMENT '评价时间',
  `modify_time` datetime DEFAULT NULL COMMENT '修改时间',
  `qrcode` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '支付二维码地址',
  `gmt_create` datetime(6) DEFAULT CURRENT_TIMESTAMP(6),
  `gmt_modified` datetime(6) DEFAULT NULL,
  `version` int DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ordersn` (`order_sn`),
  KEY `idx_member_id` (`member_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of oms_order_1
-- ----------------------------
BEGIN;
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (10100101, 1, 2, '10100101', '2022-10-11 07:32:48', NULL, 6066.00, 6066.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, 'Fox', '15612345678', '100001', '北京', '天津', '天津', 'xxxxxxx', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (10101201, 1, NULL, '10101201', '2022-10-11 08:30:55', NULL, 3788.00, 3788.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 1, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, 'Fox', '15612345678', '100001', '北京', '天津', '天津', 'xxxxxxx', NULL, 0, 0, NULL, '2022-10-11 09:18:37', NULL, NULL, NULL, NULL, '/static/qrcode/alipay/qr-10101201.png', NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (10508301, 1, NULL, '10508301', '2022-10-18 05:30:13', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 1, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, '2022-11-03 09:53:56', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (10700801, 1, NULL, '10700801', '2022-10-18 06:22:07', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 1, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, '2022-11-03 09:38:28', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (10700901, 1, NULL, '10700901', '2022-10-18 06:22:54', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 1, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, '2022-11-03 09:35:20', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (10701201, 1, NULL, '10701201', '2022-10-18 06:51:34', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 1, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, '2022-11-03 09:30:29', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (10702001, 1, NULL, '10702001', '2022-10-18 07:15:43', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 1, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, '2022-11-03 09:29:29', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (10702201, 1, NULL, '10702201', '2022-10-18 07:19:07', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 1, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, '2022-11-03 09:27:43', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (10702301, 1, NULL, '10702301', '2022-10-18 07:20:06', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 1, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, '2022-10-21 13:46:58', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (10900201, 1, NULL, '10900201', '2022-11-02 10:44:23', NULL, 1807.00, 1807.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 4, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, 'Fox', '15612345678', '100001', '北京', '天津', '天津', 'xxxxxxx', NULL, 0, 0, NULL, '2022-11-02 10:56:07', NULL, NULL, NULL, NULL, '/static/qrcode/alipay/qr-10900201.png', NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (10900301, 1, NULL, '10900301', '2022-11-02 13:11:16', NULL, 4398.00, 4398.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 4, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, 'Fox', '15612345678', '100001', '北京', '天津', '天津', 'xxxxxxx', NULL, 0, 0, NULL, '2022-11-02 13:17:13', NULL, NULL, NULL, NULL, '/static/qrcode/alipay/qr-10900301.png', NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (10900401, 1, NULL, '10900401', '2022-11-02 13:17:58', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 4, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, 'Fox', '15612345678', '100001', '北京', '天津', '天津', 'xxxxxxx', NULL, 0, 0, NULL, '2022-11-02 13:23:13', NULL, NULL, NULL, NULL, '/static/qrcode/alipay/qr-10900401.png', NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (11100001, 1, NULL, '11100001', '2022-11-03 08:50:04', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 1, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, '2022-11-03 09:23:15', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (11300301, 1, NULL, '11300301', '2022-11-04 08:56:52', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 1, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, '2022-11-04 09:04:30', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (11500101, 1, NULL, '11500101', '2022-11-04 13:03:22', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 1, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, '2022-11-04 13:45:22', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (11500301, 1, NULL, '11500301', '2022-11-04 13:48:33', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 1, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, '2022-11-04 14:13:35', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (11700001, 1, NULL, '11700001', '2022-11-09 07:24:12', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 1, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, '2022-11-09 07:31:28', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (11700101, 1, NULL, '11700101', '2022-11-09 07:33:07', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 1, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, '2022-11-09 07:33:29', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (11700201, 1, NULL, '11700201', '2022-11-09 07:34:01', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 1, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, '2022-11-09 07:34:30', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (11700301, 1, NULL, '11700301', '2022-11-09 07:37:16', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 1, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, '2022-11-09 07:37:47', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (11700401, 1, NULL, '11700401', '2022-11-09 07:38:22', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 1, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, '2022-11-09 07:38:55', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (11700501, 1, NULL, '11700501', '2022-11-09 07:41:44', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 1, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, '2022-11-09 07:42:05', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (11700601, 1, NULL, '11700601', '2022-11-09 07:43:02', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 1, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, '2022-11-09 07:43:16', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (11700701, 1, NULL, '11700701', '2022-11-09 07:44:24', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 1, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, '2022-11-09 07:44:38', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (11700801, 1, NULL, '11700801', '2022-11-09 07:45:04', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 1, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, '2022-11-09 07:45:18', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (11700901, 1, NULL, '11700901', '2022-11-09 07:47:05', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 1, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, '2022-11-09 07:51:12', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (11701001, 1, NULL, '11701001', '2022-11-09 07:51:32', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 1, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, '2022-11-10 01:14:06', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (11900001, 1, NULL, '11900001', '2022-11-10 01:16:50', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 1, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, '2022-11-10 01:17:12', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (11900101, 1, NULL, '11900101', '2022-11-10 01:19:53', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 1, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, '2022-11-10 01:20:27', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (11900201, 1, NULL, '11900201', '2022-11-10 01:27:14', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 1, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, '2023-05-28 06:57:36', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (12500101, 1, NULL, '12500101', '2022-11-15 02:55:46', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (12500201, 1, NULL, '12500201', '2022-11-15 02:58:48', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (12500301, 1, NULL, '12500301', '2022-11-15 02:59:28', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (12500401, 1, NULL, '12500401', '2022-11-15 03:01:01', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (12500501, 1, NULL, '12500501', '2022-11-15 03:01:06', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (12500601, 1, NULL, '12500601', '2022-11-15 03:01:11', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (12500701, 1, NULL, '12500701', '2022-11-15 03:04:42', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (12700001, 1, NULL, '12700001', '2022-11-15 03:14:52', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (12700201, 1, NULL, '12700201', '2022-11-15 03:18:49', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (12700401, 1, NULL, '12700401', '2022-11-15 03:23:34', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (12700501, 1, NULL, '12700501', '2022-11-15 03:25:17', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (12700601, 1, NULL, '12700601', '2022-11-15 03:26:27', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (12700701, 1, NULL, '12700701', '2022-11-15 03:30:58', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (12701001, 1, NULL, '12701001', '2022-11-15 08:43:06', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (12701101, 1, NULL, '12701101', '2022-11-15 08:43:53', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (12701401, 1, NULL, '12701401', '2022-11-15 08:45:24', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (12701501, 1, NULL, '12701501', '2022-11-15 09:00:00', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (12701601, 1, NULL, '12701601', '2022-11-15 09:00:28', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (12701801, 1, NULL, '12701801', '2022-11-15 09:37:30', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (12701901, 1, NULL, '12701901', '2022-11-15 09:38:03', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (12702001, 1, NULL, '12702001', '2022-11-15 09:38:33', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (12702101, 1, NULL, '12702101', '2022-11-15 09:47:55', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (12702201, 1, NULL, '12702201', '2022-11-15 10:05:00', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (12702301, 1, NULL, '12702301', '2022-11-15 10:06:59', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (16901801, 1, NULL, '16901801', '2022-11-16 05:39:38', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (16902301, 1, NULL, '16902301', '2022-11-16 05:39:42', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (16902601, 1, NULL, '16902601', '2022-11-16 05:39:46', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (16903001, 1, NULL, '16903001', '2022-11-16 05:41:37', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (16903201, 1, NULL, '16903201', '2022-11-16 05:41:48', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (16903301, 1, NULL, '16903301', '2022-11-16 05:42:30', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (16903601, 1, NULL, '16903601', '2022-11-16 05:42:37', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (16904401, 1, NULL, '16904401', '2022-11-16 05:43:05', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (16904501, 1, NULL, '16904501', '2022-11-16 05:46:20', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '默认地址', '199xxxxxx', '-1', '默认省份', '默认city', '默认region', '默认详情地址', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (16904601, 1, NULL, '16904601', '2022-11-16 05:46:44', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '默认地址', '199xxxxxx', '-1', '默认省份', '默认city', '默认region', '默认详情地址', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (16904701, 1, NULL, '16904701', '2022-11-16 05:46:48', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '默认地址', '199xxxxxx', '-1', '默认省份', '默认city', '默认region', '默认详情地址', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (16904801, 1, NULL, '16904801', '2022-11-16 05:47:12', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '默认地址', '199xxxxxx', '-1', '默认省份', '默认city', '默认region', '默认详情地址', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (16905001, 1, NULL, '16905001', '2022-11-16 05:47:30', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '默认地址', '199xxxxxx', '-1', '默认省份', '默认city', '默认region', '默认详情地址', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (16905101, 1, NULL, '16905101', '2022-11-16 05:47:44', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '默认地址', '199xxxxxx', '-1', '默认省份', '默认city', '默认region', '默认详情地址', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (16905701, 1, NULL, '16905701', '2022-11-16 05:47:50', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '默认地址', '199xxxxxx', '-1', '默认省份', '默认city', '默认region', '默认详情地址', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (16906101, 1, NULL, '16906101', '2022-11-16 05:48:23', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '默认地址', '199xxxxxx', '-1', '默认省份', '默认city', '默认region', '默认详情地址', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (16906701, 1, NULL, '16906701', '2022-11-16 05:48:29', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '默认地址', '199xxxxxx', '-1', '默认省份', '默认city', '默认region', '默认详情地址', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (16906901, 1, NULL, '16906901', '2022-11-16 05:48:32', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '默认地址', '199xxxxxx', '-1', '默认省份', '默认city', '默认region', '默认详情地址', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (16907201, 1, NULL, '16907201', '2022-11-16 05:48:40', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '默认地址', '199xxxxxx', '-1', '默认省份', '默认city', '默认region', '默认详情地址', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (16907601, 1, NULL, '16907601', '2022-11-16 05:49:30', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '默认地址', '199xxxxxx', '-1', '默认省份', '默认city', '默认region', '默认详情地址', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (16907901, 1, NULL, '16907901', '2022-11-16 05:49:36', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '默认地址', '199xxxxxx', '-1', '默认省份', '默认city', '默认region', '默认详情地址', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (16908801, 1, NULL, '16908801', '2022-11-16 05:49:44', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '默认地址', '199xxxxxx', '-1', '默认省份', '默认city', '默认region', '默认详情地址', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (16909401, 1, NULL, '16909401', '2022-11-16 05:49:49', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '默认地址', '199xxxxxx', '-1', '默认省份', '默认city', '默认region', '默认详情地址', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (16909601, 1, NULL, '16909601', '2022-11-16 06:09:27', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '默认地址', '199xxxxxx', '-1', '默认省份', '默认city', '默认region', '默认详情地址', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (16909701, 1, NULL, '16909701', '2022-11-16 06:09:35', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '默认地址', '199xxxxxx', '-1', '默认省份', '默认city', '默认region', '默认详情地址', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (16909801, 1, NULL, '16909801', '2022-11-16 06:10:14', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '默认地址', '199xxxxxx', '-1', '默认省份', '默认city', '默认region', '默认详情地址', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (16909901, 1, NULL, '16909901', '2022-11-16 06:10:19', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '默认地址', '199xxxxxx', '-1', '默认省份', '默认city', '默认region', '默认详情地址', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (16910001, 1, NULL, '16910001', '2022-11-16 06:10:20', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '默认地址', '199xxxxxx', '-1', '默认省份', '默认city', '默认region', '默认详情地址', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (16910101, 1, NULL, '16910101', '2022-11-16 06:11:17', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '默认地址', '199xxxxxx', '-1', '默认省份', '默认city', '默认region', '默认详情地址', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (16910201, 1, NULL, '16910201', '2022-11-16 06:11:37', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '默认地址', '199xxxxxx', '-1', '默认省份', '默认city', '默认region', '默认详情地址', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (17100101, 1, NULL, '17100101', '2022-11-16 06:54:21', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (17300001, 1, NULL, '17300001', '2022-11-16 14:09:50', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (17300101, 1, NULL, '17300101', '2022-11-16 14:10:37', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '默认地址', '199xxxxxx', '-1', '默认省份', '默认city', '默认region', '默认详情地址', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (18900001, 1, NULL, '18900001', '2023-05-28 05:46:53', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (18900101, 1, NULL, '18900101', '2023-05-28 05:48:20', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (18900301, 1, NULL, '18900301', '2023-05-28 05:53:44', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (18900401, 1, NULL, '18900401', '2023-05-28 05:54:11', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (18900501, 1, NULL, '18900501', '2023-05-28 06:01:04', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (18900601, 1, NULL, '18900601', '2023-05-28 06:03:26', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (18900701, 1, NULL, '18900701', '2023-05-28 06:04:27', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (18901301, 1, NULL, '18901301', '2023-05-28 06:14:24', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 1, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, '2023-05-28 07:07:03', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (19100001, 1, NULL, '19100001', '2023-05-28 06:22:42', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 1, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, '2023-05-28 07:07:21', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (19101101, 1, NULL, '19101101', '2023-05-28 06:32:24', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 1, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, '2023-05-28 07:04:11', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (19101201, 1, NULL, '19101201', '2023-05-28 06:33:08', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 1, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, '2023-05-28 07:03:55', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (19101301, 1, NULL, '19101301', '2023-05-28 06:34:36', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 1, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, '2023-05-28 06:58:52', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (19101701, 1, NULL, '19101701', '2023-05-28 06:42:02', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 1, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, '2023-05-28 07:06:46', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (19300001, 1, NULL, '19300001', '2023-05-29 06:16:11', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (19500001, 1, NULL, '19500001', '2023-05-29 06:40:07', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (19700201, 1, NULL, '19700201', '2023-05-29 08:05:39', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 1, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, '2023-05-29 08:25:32', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (19900001, 1, NULL, '19900001', '2023-05-31 02:54:16', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (19900101, 1, NULL, '19900101', '2023-05-31 02:54:28', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (19900201, 1, NULL, '19900201', '2023-05-31 02:54:35', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (19900301, 1, NULL, '19900301', '2023-05-31 02:54:44', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (19900401, 1, NULL, '19900401', '2023-05-31 02:57:16', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (19900501, 1, NULL, '19900501', '2023-05-31 02:57:22', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (19900601, 1, NULL, '19900601', '2023-05-31 02:57:28', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (19900701, 1, NULL, '19900701', '2023-05-31 02:57:42', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (19900801, 1, NULL, '19900801', '2023-05-31 03:13:29', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (19900901, 1, NULL, '19900901', '2023-05-31 03:21:09', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (19901001, 1, NULL, '19901001', '2023-05-31 03:21:57', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (19901101, 1, NULL, '19901101', '2023-05-31 03:22:16', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (19901201, 1, NULL, '19901201', '2023-05-31 03:22:20', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (19901301, 1, NULL, '19901301', '2023-05-31 03:27:55', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (19901401, 1, NULL, '19901401', '2023-05-31 03:27:56', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (19901501, 1, NULL, '19901501', '2023-05-31 03:27:59', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (19903301, 1, NULL, '19903301', '2023-05-31 03:28:33', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (19903401, 1, NULL, '19903401', '2023-05-31 03:28:49', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (19903501, 1, NULL, '19903501', '2023-05-31 03:29:33', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (19903601, 1, NULL, '19903601', '2023-05-31 03:29:34', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (19903701, 1, NULL, '19903701', '2023-05-31 03:29:35', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (19903801, 1, NULL, '19903801', '2023-05-31 03:29:37', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (19905501, 1, NULL, '19905501', '2023-05-31 03:30:05', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (19905601, 1, NULL, '19905601', '2023-05-31 03:30:09', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (19906701, 1, NULL, '19906701', '2023-05-31 03:32:42', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (19906801, 1, NULL, '19906801', '2023-05-31 03:32:44', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (19906901, 1, NULL, '19906901', '2023-05-31 03:32:42', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (19907001, 1, NULL, '19907001', '2023-05-31 03:32:43', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (19907101, 1, NULL, '19907101', '2023-05-31 03:32:45', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (19907201, 1, NULL, '19907201', '2023-05-31 03:32:46', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (19907301, 1, NULL, '19907301', '2023-05-31 03:32:46', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (19907401, 1, NULL, '19907401', '2023-05-31 03:32:47', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (19907501, 1, NULL, '19907501', '2023-05-31 03:32:48', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (19907601, 1, NULL, '19907601', '2023-05-31 03:32:49', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (19907701, 1, NULL, '19907701', '2023-05-31 03:32:50', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (19907801, 1, NULL, '19907801', '2023-05-31 03:32:51', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (19907901, 1, NULL, '19907901', '2023-05-31 03:32:53', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (19908001, 1, NULL, '19908001', '2023-05-31 03:32:53', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (19908101, 1, NULL, '19908101', '2023-05-31 03:32:52', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (19909901, 1, NULL, '19909901', '2023-05-31 03:32:56', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (19910201, 1, NULL, '19910201', '2023-05-31 03:32:58', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (19912801, 1, NULL, '19912801', '2023-05-31 03:34:57', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '默认地址', '199xxxxxx', '-1', '默认省份', '默认city', '默认region', '默认详情地址', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (19912901, 1, NULL, '19912901', '2023-05-31 03:47:05', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '默认地址', '199xxxxxx', '-1', '默认省份', '默认city', '默认region', '默认详情地址', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (20500101, 1, NULL, '20500101', '2023-06-20 11:13:32', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '默认地址', '199xxxxxx', '-1', '默认省份', '默认city', '默认region', '默认详情地址', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_1` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (20500201, 1, NULL, '20500201', '2023-06-20 11:15:08', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
COMMIT;

-- ----------------------------
-- Table structure for oms_order_10
-- ----------------------------
DROP TABLE IF EXISTS `oms_order_10`;
CREATE TABLE `oms_order_10` (
  `id` bigint NOT NULL DEFAULT '0' COMMENT '订单id',
  `member_id` bigint NOT NULL,
  `coupon_id` bigint DEFAULT NULL,
  `order_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '订单编号',
  `create_time` datetime DEFAULT NULL COMMENT '提交时间',
  `member_username` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '用户帐号',
  `total_amount` decimal(10,2) DEFAULT NULL COMMENT '订单总金额',
  `pay_amount` decimal(10,2) DEFAULT NULL COMMENT '应付金额（实际支付金额）',
  `freight_amount` decimal(10,2) DEFAULT NULL COMMENT '运费金额',
  `promotion_amount` decimal(10,2) DEFAULT NULL COMMENT '促销优化金额（促销价、满减、阶梯价）',
  `integration_amount` decimal(10,2) DEFAULT NULL COMMENT '积分抵扣金额',
  `coupon_amount` decimal(10,2) DEFAULT NULL COMMENT '优惠券抵扣金额',
  `discount_amount` decimal(10,2) DEFAULT NULL COMMENT '管理员后台调整订单使用的折扣金额',
  `pay_type` int DEFAULT NULL COMMENT '支付方式：0->未支付；1->支付宝；2->微信',
  `source_type` int DEFAULT NULL COMMENT '订单来源：0->PC订单；1->app订单',
  `status` int DEFAULT NULL COMMENT '订单状态：0->待付款；1->待发货；2->已发货；3->已完成；4->已关闭；5->无效订单',
  `order_type` int DEFAULT NULL COMMENT '订单类型：0->正常订单；1->秒杀订单',
  `delivery_company` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '物流公司(配送方式)',
  `delivery_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '物流单号',
  `auto_confirm_day` int DEFAULT NULL COMMENT '自动确认时间（天）',
  `integration` int DEFAULT NULL COMMENT '可以获得的积分',
  `growth` int DEFAULT NULL COMMENT '可以活动的成长值',
  `promotion_info` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '活动信息',
  `bill_type` int DEFAULT NULL COMMENT '发票类型：0->不开发票；1->电子发票；2->纸质发票',
  `bill_header` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '发票抬头',
  `bill_content` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '发票内容',
  `bill_receiver_phone` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '收票人电话',
  `bill_receiver_email` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '收票人邮箱',
  `receiver_name` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci NOT NULL COMMENT '收货人姓名',
  `receiver_phone` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci NOT NULL COMMENT '收货人电话',
  `receiver_post_code` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '收货人邮编',
  `receiver_province` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '省份/直辖市',
  `receiver_city` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '城市',
  `receiver_region` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '区',
  `receiver_detail_address` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '详细地址',
  `note` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '订单备注',
  `confirm_status` int DEFAULT NULL COMMENT '确认收货状态：0->未确认；1->已确认',
  `delete_status` int NOT NULL DEFAULT '0' COMMENT '删除状态：0->未删除；1->已删除',
  `use_integration` int DEFAULT NULL COMMENT '下单时使用的积分',
  `payment_time` datetime DEFAULT NULL COMMENT '支付时间',
  `delivery_time` datetime DEFAULT NULL COMMENT '发货时间',
  `receive_time` datetime DEFAULT NULL COMMENT '确认收货时间',
  `comment_time` datetime DEFAULT NULL COMMENT '评价时间',
  `modify_time` datetime DEFAULT NULL COMMENT '修改时间',
  `qrcode` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '支付二维码地址',
  `gmt_create` datetime(6) DEFAULT CURRENT_TIMESTAMP(6),
  `gmt_modified` datetime(6) DEFAULT NULL,
  `version` int DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ordersn` (`order_sn`),
  KEY `idx_member_id` (`member_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of oms_order_10
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for oms_order_11
-- ----------------------------
DROP TABLE IF EXISTS `oms_order_11`;
CREATE TABLE `oms_order_11` (
  `id` bigint NOT NULL DEFAULT '0' COMMENT '订单id',
  `member_id` bigint NOT NULL,
  `coupon_id` bigint DEFAULT NULL,
  `order_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '订单编号',
  `create_time` datetime DEFAULT NULL COMMENT '提交时间',
  `member_username` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '用户帐号',
  `total_amount` decimal(10,2) DEFAULT NULL COMMENT '订单总金额',
  `pay_amount` decimal(10,2) DEFAULT NULL COMMENT '应付金额（实际支付金额）',
  `freight_amount` decimal(10,2) DEFAULT NULL COMMENT '运费金额',
  `promotion_amount` decimal(10,2) DEFAULT NULL COMMENT '促销优化金额（促销价、满减、阶梯价）',
  `integration_amount` decimal(10,2) DEFAULT NULL COMMENT '积分抵扣金额',
  `coupon_amount` decimal(10,2) DEFAULT NULL COMMENT '优惠券抵扣金额',
  `discount_amount` decimal(10,2) DEFAULT NULL COMMENT '管理员后台调整订单使用的折扣金额',
  `pay_type` int DEFAULT NULL COMMENT '支付方式：0->未支付；1->支付宝；2->微信',
  `source_type` int DEFAULT NULL COMMENT '订单来源：0->PC订单；1->app订单',
  `status` int DEFAULT NULL COMMENT '订单状态：0->待付款；1->待发货；2->已发货；3->已完成；4->已关闭；5->无效订单',
  `order_type` int DEFAULT NULL COMMENT '订单类型：0->正常订单；1->秒杀订单',
  `delivery_company` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '物流公司(配送方式)',
  `delivery_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '物流单号',
  `auto_confirm_day` int DEFAULT NULL COMMENT '自动确认时间（天）',
  `integration` int DEFAULT NULL COMMENT '可以获得的积分',
  `growth` int DEFAULT NULL COMMENT '可以活动的成长值',
  `promotion_info` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '活动信息',
  `bill_type` int DEFAULT NULL COMMENT '发票类型：0->不开发票；1->电子发票；2->纸质发票',
  `bill_header` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '发票抬头',
  `bill_content` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '发票内容',
  `bill_receiver_phone` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '收票人电话',
  `bill_receiver_email` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '收票人邮箱',
  `receiver_name` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci NOT NULL COMMENT '收货人姓名',
  `receiver_phone` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci NOT NULL COMMENT '收货人电话',
  `receiver_post_code` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '收货人邮编',
  `receiver_province` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '省份/直辖市',
  `receiver_city` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '城市',
  `receiver_region` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '区',
  `receiver_detail_address` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '详细地址',
  `note` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '订单备注',
  `confirm_status` int DEFAULT NULL COMMENT '确认收货状态：0->未确认；1->已确认',
  `delete_status` int NOT NULL DEFAULT '0' COMMENT '删除状态：0->未删除；1->已删除',
  `use_integration` int DEFAULT NULL COMMENT '下单时使用的积分',
  `payment_time` datetime DEFAULT NULL COMMENT '支付时间',
  `delivery_time` datetime DEFAULT NULL COMMENT '发货时间',
  `receive_time` datetime DEFAULT NULL COMMENT '确认收货时间',
  `comment_time` datetime DEFAULT NULL COMMENT '评价时间',
  `modify_time` datetime DEFAULT NULL COMMENT '修改时间',
  `qrcode` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '支付二维码地址',
  `gmt_create` datetime(6) DEFAULT CURRENT_TIMESTAMP(6),
  `gmt_modified` datetime(6) DEFAULT NULL,
  `version` int DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ordersn` (`order_sn`),
  KEY `idx_member_id` (`member_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of oms_order_11
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for oms_order_12
-- ----------------------------
DROP TABLE IF EXISTS `oms_order_12`;
CREATE TABLE `oms_order_12` (
  `id` bigint NOT NULL DEFAULT '0' COMMENT '订单id',
  `member_id` bigint NOT NULL,
  `coupon_id` bigint DEFAULT NULL,
  `order_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '订单编号',
  `create_time` datetime DEFAULT NULL COMMENT '提交时间',
  `member_username` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '用户帐号',
  `total_amount` decimal(10,2) DEFAULT NULL COMMENT '订单总金额',
  `pay_amount` decimal(10,2) DEFAULT NULL COMMENT '应付金额（实际支付金额）',
  `freight_amount` decimal(10,2) DEFAULT NULL COMMENT '运费金额',
  `promotion_amount` decimal(10,2) DEFAULT NULL COMMENT '促销优化金额（促销价、满减、阶梯价）',
  `integration_amount` decimal(10,2) DEFAULT NULL COMMENT '积分抵扣金额',
  `coupon_amount` decimal(10,2) DEFAULT NULL COMMENT '优惠券抵扣金额',
  `discount_amount` decimal(10,2) DEFAULT NULL COMMENT '管理员后台调整订单使用的折扣金额',
  `pay_type` int DEFAULT NULL COMMENT '支付方式：0->未支付；1->支付宝；2->微信',
  `source_type` int DEFAULT NULL COMMENT '订单来源：0->PC订单；1->app订单',
  `status` int DEFAULT NULL COMMENT '订单状态：0->待付款；1->待发货；2->已发货；3->已完成；4->已关闭；5->无效订单',
  `order_type` int DEFAULT NULL COMMENT '订单类型：0->正常订单；1->秒杀订单',
  `delivery_company` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '物流公司(配送方式)',
  `delivery_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '物流单号',
  `auto_confirm_day` int DEFAULT NULL COMMENT '自动确认时间（天）',
  `integration` int DEFAULT NULL COMMENT '可以获得的积分',
  `growth` int DEFAULT NULL COMMENT '可以活动的成长值',
  `promotion_info` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '活动信息',
  `bill_type` int DEFAULT NULL COMMENT '发票类型：0->不开发票；1->电子发票；2->纸质发票',
  `bill_header` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '发票抬头',
  `bill_content` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '发票内容',
  `bill_receiver_phone` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '收票人电话',
  `bill_receiver_email` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '收票人邮箱',
  `receiver_name` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci NOT NULL COMMENT '收货人姓名',
  `receiver_phone` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci NOT NULL COMMENT '收货人电话',
  `receiver_post_code` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '收货人邮编',
  `receiver_province` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '省份/直辖市',
  `receiver_city` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '城市',
  `receiver_region` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '区',
  `receiver_detail_address` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '详细地址',
  `note` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '订单备注',
  `confirm_status` int DEFAULT NULL COMMENT '确认收货状态：0->未确认；1->已确认',
  `delete_status` int NOT NULL DEFAULT '0' COMMENT '删除状态：0->未删除；1->已删除',
  `use_integration` int DEFAULT NULL COMMENT '下单时使用的积分',
  `payment_time` datetime DEFAULT NULL COMMENT '支付时间',
  `delivery_time` datetime DEFAULT NULL COMMENT '发货时间',
  `receive_time` datetime DEFAULT NULL COMMENT '确认收货时间',
  `comment_time` datetime DEFAULT NULL COMMENT '评价时间',
  `modify_time` datetime DEFAULT NULL COMMENT '修改时间',
  `qrcode` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '支付二维码地址',
  `gmt_create` datetime(6) DEFAULT CURRENT_TIMESTAMP(6),
  `gmt_modified` datetime(6) DEFAULT NULL,
  `version` int DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ordersn` (`order_sn`),
  KEY `idx_member_id` (`member_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of oms_order_12
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for oms_order_13
-- ----------------------------
DROP TABLE IF EXISTS `oms_order_13`;
CREATE TABLE `oms_order_13` (
  `id` bigint NOT NULL DEFAULT '0' COMMENT '订单id',
  `member_id` bigint NOT NULL,
  `coupon_id` bigint DEFAULT NULL,
  `order_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '订单编号',
  `create_time` datetime DEFAULT NULL COMMENT '提交时间',
  `member_username` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '用户帐号',
  `total_amount` decimal(10,2) DEFAULT NULL COMMENT '订单总金额',
  `pay_amount` decimal(10,2) DEFAULT NULL COMMENT '应付金额（实际支付金额）',
  `freight_amount` decimal(10,2) DEFAULT NULL COMMENT '运费金额',
  `promotion_amount` decimal(10,2) DEFAULT NULL COMMENT '促销优化金额（促销价、满减、阶梯价）',
  `integration_amount` decimal(10,2) DEFAULT NULL COMMENT '积分抵扣金额',
  `coupon_amount` decimal(10,2) DEFAULT NULL COMMENT '优惠券抵扣金额',
  `discount_amount` decimal(10,2) DEFAULT NULL COMMENT '管理员后台调整订单使用的折扣金额',
  `pay_type` int DEFAULT NULL COMMENT '支付方式：0->未支付；1->支付宝；2->微信',
  `source_type` int DEFAULT NULL COMMENT '订单来源：0->PC订单；1->app订单',
  `status` int DEFAULT NULL COMMENT '订单状态：0->待付款；1->待发货；2->已发货；3->已完成；4->已关闭；5->无效订单',
  `order_type` int DEFAULT NULL COMMENT '订单类型：0->正常订单；1->秒杀订单',
  `delivery_company` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '物流公司(配送方式)',
  `delivery_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '物流单号',
  `auto_confirm_day` int DEFAULT NULL COMMENT '自动确认时间（天）',
  `integration` int DEFAULT NULL COMMENT '可以获得的积分',
  `growth` int DEFAULT NULL COMMENT '可以活动的成长值',
  `promotion_info` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '活动信息',
  `bill_type` int DEFAULT NULL COMMENT '发票类型：0->不开发票；1->电子发票；2->纸质发票',
  `bill_header` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '发票抬头',
  `bill_content` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '发票内容',
  `bill_receiver_phone` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '收票人电话',
  `bill_receiver_email` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '收票人邮箱',
  `receiver_name` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci NOT NULL COMMENT '收货人姓名',
  `receiver_phone` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci NOT NULL COMMENT '收货人电话',
  `receiver_post_code` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '收货人邮编',
  `receiver_province` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '省份/直辖市',
  `receiver_city` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '城市',
  `receiver_region` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '区',
  `receiver_detail_address` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '详细地址',
  `note` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '订单备注',
  `confirm_status` int DEFAULT NULL COMMENT '确认收货状态：0->未确认；1->已确认',
  `delete_status` int NOT NULL DEFAULT '0' COMMENT '删除状态：0->未删除；1->已删除',
  `use_integration` int DEFAULT NULL COMMENT '下单时使用的积分',
  `payment_time` datetime DEFAULT NULL COMMENT '支付时间',
  `delivery_time` datetime DEFAULT NULL COMMENT '发货时间',
  `receive_time` datetime DEFAULT NULL COMMENT '确认收货时间',
  `comment_time` datetime DEFAULT NULL COMMENT '评价时间',
  `modify_time` datetime DEFAULT NULL COMMENT '修改时间',
  `qrcode` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '支付二维码地址',
  `gmt_create` datetime(6) DEFAULT CURRENT_TIMESTAMP(6),
  `gmt_modified` datetime(6) DEFAULT NULL,
  `version` int DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ordersn` (`order_sn`),
  KEY `idx_member_id` (`member_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of oms_order_13
-- ----------------------------
BEGIN;
INSERT INTO `oms_order_13` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (61015, 462245, NULL, '61015', '2022-09-20 08:27:57', NULL, 4999.00, 4999.00, 0.00, 0.00, 0.00, NULL, 500.00, 1, 0, 0, 1, NULL, NULL, NULL, 5499, 5499, '秒杀特惠活动', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '福田区', '东晓街道', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2022-09-20 16:28:30.715127', NULL, 0);
INSERT INTO `oms_order_13` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (61016, 462245, NULL, '61016', '2022-09-20 08:59:54', NULL, 4999.00, 4999.00, 0.00, 0.00, 0.00, NULL, 500.00, 1, 0, 0, 1, NULL, NULL, NULL, 5499, 5499, '秒杀特惠活动', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '福田区', '东晓街道', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2022-09-20 16:59:54.674592', NULL, 0);
INSERT INTO `oms_order_13` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (302145, 462245, NULL, '302145', '2022-07-23 08:10:23', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 1, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, '2022-07-25 08:08:14', NULL, NULL, NULL, NULL, '/static/qrcode/alipay/qr-302145.png', NULL, NULL, NULL);
INSERT INTO `oms_order_13` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (500145, 462245, NULL, '500145', '2022-07-26 09:34:09', NULL, 111.00, 111.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_13` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (500245, 462245, NULL, '500245', '2022-07-26 09:36:59', NULL, 111.00, 111.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_13` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (500345, 462245, NULL, '500345', '2022-07-26 09:51:52', NULL, 111.00, 111.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_13` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (500445, 462245, NULL, '500445', '2022-07-26 09:56:26', NULL, 111.00, 111.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_13` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (500545, 462245, NULL, '500545', '2022-07-26 09:57:48', NULL, 111.00, 111.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_13` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (500645, 462245, NULL, '500645', '2022-07-26 10:08:48', NULL, 111.00, 111.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_13` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (500745, 462245, NULL, '500745', '2022-07-26 10:09:47', NULL, 111.00, 111.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '/static/qrcode/alipay/qr-500745.png', NULL, NULL, NULL);
INSERT INTO `oms_order_13` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (700045, 462245, NULL, '700045', '2022-07-27 07:23:48', NULL, 111.00, 111.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 5, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, '2022-07-27 09:26:38', NULL, NULL, NULL, NULL, '/static/qrcode/alipay/qr-700045.png', NULL, NULL, NULL);
INSERT INTO `oms_order_13` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (900045, 462245, NULL, '900045', '2022-09-14 06:06:04', NULL, 5398.00, 5398.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 5, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, '2022-09-14 06:11:20', NULL, NULL, NULL, NULL, '/static/qrcode/alipay/qr-900045.png', NULL, NULL, NULL);
INSERT INTO `oms_order_13` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (900145, 462245, NULL, '900145', '2022-09-14 06:06:33', NULL, 5398.00, 5398.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 5, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, '2022-09-14 07:06:21', NULL, NULL, NULL, NULL, '/static/qrcode/alipay/qr-900145.png', NULL, NULL, NULL);
INSERT INTO `oms_order_13` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (1100045, 462245, NULL, '1100045', '2022-09-14 07:07:54', NULL, 111.00, 111.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 5, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, '2022-09-14 07:13:21', NULL, NULL, NULL, NULL, '/static/qrcode/alipay/qr-1100045.png', NULL, NULL, NULL);
INSERT INTO `oms_order_13` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (1100145, 462245, NULL, '1100145', '2022-09-14 07:11:51', NULL, 111.00, 111.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 5, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, '2022-09-14 07:17:21', NULL, NULL, NULL, NULL, '/static/qrcode/alipay/qr-1100145.png', NULL, NULL, NULL);
INSERT INTO `oms_order_13` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (9700945, 462245, NULL, '9700945', '2022-10-11 05:32:25', NULL, 5398.00, 5398.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 5, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, '2022-10-11 05:44:30', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_13` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (10100645, 462245, NULL, '10100645', '2022-10-11 07:48:36', NULL, 5398.00, 5398.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 5, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, '2022-10-11 07:54:24', NULL, NULL, NULL, NULL, '/static/qrcode/alipay/qr-10100645.png', NULL, NULL, NULL);
INSERT INTO `oms_order_13` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (10100845, 462245, NULL, '10100845', '2022-10-11 07:50:31', NULL, 111.00, 111.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 5, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, '2022-10-11 07:58:14', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_13` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (10100945, 462245, NULL, '10100945', '2022-10-11 07:54:03', NULL, 111.00, 111.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 5, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, '2022-10-11 08:04:14', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_13` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (10505045, 462245, NULL, '10505045', '2022-10-16 08:01:47', NULL, 111.00, 111.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_13` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (18300045, 462245, NULL, '18300045', '2023-05-08 09:25:53', NULL, 2208.00, 2208.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 4, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, '2023-05-08 09:31:07', NULL, NULL, NULL, NULL, '/static/qrcode/alipay/qr-18300045.png', NULL, NULL, NULL);
INSERT INTO `oms_order_13` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (18300145, 462245, NULL, '18300145', '2023-05-08 09:26:20', NULL, 2208.00, 2208.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 4, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, '2023-05-08 09:32:07', NULL, NULL, NULL, NULL, '/static/qrcode/alipay/qr-18300145.png', NULL, NULL, NULL);
INSERT INTO `oms_order_13` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (18300245, 462245, NULL, '18300245', '2023-05-08 09:27:09', NULL, 2208.00, 2208.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 4, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, '2023-05-08 09:33:07', NULL, NULL, NULL, NULL, '/static/qrcode/alipay/qr-18300245.png', NULL, NULL, NULL);
INSERT INTO `oms_order_13` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (18300345, 462245, NULL, '18300345', '2023-05-08 09:52:37', NULL, 2208.00, 2208.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_13` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (18500045, 462245, NULL, '18500045', '2023-05-23 05:29:32', NULL, 111.00, 111.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 5, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, '2023-05-23 05:35:17', NULL, NULL, NULL, NULL, '/static/qrcode/alipay/qr-18500045.png', NULL, NULL, NULL);
INSERT INTO `oms_order_13` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (18500145, 462245, NULL, '18500145', '2023-05-23 05:32:41', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 5, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, '2023-05-23 05:38:17', NULL, NULL, NULL, NULL, '/static/qrcode/alipay/qr-18500145.png', NULL, NULL, NULL);
INSERT INTO `oms_order_13` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (18700145, 462245, NULL, '18700145', '2023-05-23 08:55:16', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_13` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (18700245, 462245, NULL, '18700245', '2023-05-23 08:56:00', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 5, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, '2023-05-23 09:01:17', NULL, NULL, NULL, NULL, '/static/qrcode/alipay/qr-18700245.png', NULL, NULL, NULL);
INSERT INTO `oms_order_13` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (18700345, 462245, NULL, '18700345', '2023-05-23 08:59:54', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 5, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, '2023-05-23 09:05:17', NULL, NULL, NULL, NULL, '/static/qrcode/alipay/qr-18700345.png', NULL, NULL, NULL);
INSERT INTO `oms_order_13` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (18700445, 462245, NULL, '18700445', '2023-05-23 09:04:48', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 5, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, '2023-05-23 09:10:17', NULL, NULL, NULL, NULL, '/static/qrcode/alipay/qr-18700445.png', NULL, NULL, NULL);
INSERT INTO `oms_order_13` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (18700545, 462245, NULL, '18700545', '2023-05-23 09:39:39', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 5, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, '2023-05-23 09:45:17', NULL, NULL, NULL, NULL, '/static/qrcode/alipay/qr-18700545.png', NULL, NULL, NULL);
INSERT INTO `oms_order_13` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (18700645, 462245, NULL, '18700645', '2023-05-24 06:37:02', NULL, 2699.00, 2699.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 5, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, '2023-05-24 06:42:18', NULL, NULL, NULL, NULL, '/static/qrcode/alipay/qr-18700645.png', NULL, NULL, NULL);
INSERT INTO `oms_order_13` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (20100045, 462245, NULL, '20100045', '2023-06-12 07:41:09', NULL, 139.00, 139.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 5, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, '2023-06-14 08:29:29', NULL, NULL, NULL, NULL, '/static/qrcode/alipay/qr-20100045.png', NULL, NULL, NULL);
INSERT INTO `oms_order_13` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (20100145, 462245, NULL, '20100145', '2023-06-12 09:31:28', NULL, 139.00, 139.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 5, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, '2023-06-12 09:37:28', NULL, NULL, NULL, NULL, '/static/qrcode/alipay/qr-20100145.png', NULL, NULL, NULL);
INSERT INTO `oms_order_13` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (20300045, 462245, NULL, '20300045', '2023-06-14 07:24:43', NULL, 139.00, 139.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '/static/qrcode/alipay/qr-20300045.png', NULL, NULL, NULL);
COMMIT;

-- ----------------------------
-- Table structure for oms_order_14
-- ----------------------------
DROP TABLE IF EXISTS `oms_order_14`;
CREATE TABLE `oms_order_14` (
  `id` bigint NOT NULL DEFAULT '0' COMMENT '订单id',
  `member_id` bigint NOT NULL,
  `coupon_id` bigint DEFAULT NULL,
  `order_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '订单编号',
  `create_time` datetime DEFAULT NULL COMMENT '提交时间',
  `member_username` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '用户帐号',
  `total_amount` decimal(10,2) DEFAULT NULL COMMENT '订单总金额',
  `pay_amount` decimal(10,2) DEFAULT NULL COMMENT '应付金额（实际支付金额）',
  `freight_amount` decimal(10,2) DEFAULT NULL COMMENT '运费金额',
  `promotion_amount` decimal(10,2) DEFAULT NULL COMMENT '促销优化金额（促销价、满减、阶梯价）',
  `integration_amount` decimal(10,2) DEFAULT NULL COMMENT '积分抵扣金额',
  `coupon_amount` decimal(10,2) DEFAULT NULL COMMENT '优惠券抵扣金额',
  `discount_amount` decimal(10,2) DEFAULT NULL COMMENT '管理员后台调整订单使用的折扣金额',
  `pay_type` int DEFAULT NULL COMMENT '支付方式：0->未支付；1->支付宝；2->微信',
  `source_type` int DEFAULT NULL COMMENT '订单来源：0->PC订单；1->app订单',
  `status` int DEFAULT NULL COMMENT '订单状态：0->待付款；1->待发货；2->已发货；3->已完成；4->已关闭；5->无效订单',
  `order_type` int DEFAULT NULL COMMENT '订单类型：0->正常订单；1->秒杀订单',
  `delivery_company` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '物流公司(配送方式)',
  `delivery_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '物流单号',
  `auto_confirm_day` int DEFAULT NULL COMMENT '自动确认时间（天）',
  `integration` int DEFAULT NULL COMMENT '可以获得的积分',
  `growth` int DEFAULT NULL COMMENT '可以活动的成长值',
  `promotion_info` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '活动信息',
  `bill_type` int DEFAULT NULL COMMENT '发票类型：0->不开发票；1->电子发票；2->纸质发票',
  `bill_header` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '发票抬头',
  `bill_content` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '发票内容',
  `bill_receiver_phone` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '收票人电话',
  `bill_receiver_email` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '收票人邮箱',
  `receiver_name` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci NOT NULL COMMENT '收货人姓名',
  `receiver_phone` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci NOT NULL COMMENT '收货人电话',
  `receiver_post_code` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '收货人邮编',
  `receiver_province` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '省份/直辖市',
  `receiver_city` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '城市',
  `receiver_region` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '区',
  `receiver_detail_address` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '详细地址',
  `note` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '订单备注',
  `confirm_status` int DEFAULT NULL COMMENT '确认收货状态：0->未确认；1->已确认',
  `delete_status` int NOT NULL DEFAULT '0' COMMENT '删除状态：0->未删除；1->已删除',
  `use_integration` int DEFAULT NULL COMMENT '下单时使用的积分',
  `payment_time` datetime DEFAULT NULL COMMENT '支付时间',
  `delivery_time` datetime DEFAULT NULL COMMENT '发货时间',
  `receive_time` datetime DEFAULT NULL COMMENT '确认收货时间',
  `comment_time` datetime DEFAULT NULL COMMENT '评价时间',
  `modify_time` datetime DEFAULT NULL COMMENT '修改时间',
  `qrcode` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '支付二维码地址',
  `gmt_create` datetime(6) DEFAULT CURRENT_TIMESTAMP(6),
  `gmt_modified` datetime(6) DEFAULT NULL,
  `version` int DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ordersn` (`order_sn`),
  KEY `idx_member_id` (`member_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of oms_order_14
-- ----------------------------
BEGIN;
INSERT INTO `oms_order_14` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (9300846, 462246, NULL, '9300846', '2022-10-11 03:17:23', NULL, 139.00, 139.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 5, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, 'mark', '13912345678', '100001', '河北', '河北', '北京', 'mark', NULL, 0, 0, NULL, '2022-10-11 03:23:30', NULL, NULL, NULL, NULL, '/static/qrcode/alipay/qr-9300846.png', NULL, NULL, NULL);
INSERT INTO `oms_order_14` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (9700046, 462246, NULL, '9700046', '2022-10-11 04:01:12', NULL, 139.00, 139.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, 'mark', '13912345678', '100001', '河北', '河北', '北京', 'mark', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_14` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (9700146, 462246, NULL, '9700146', '2022-10-11 04:10:12', NULL, 139.00, 139.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 5, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, 'mark', '13912345678', '100001', '河北', '河北', '北京', 'mark', NULL, 0, 0, NULL, '2022-10-11 04:21:30', NULL, NULL, NULL, NULL, '/static/qrcode/alipay/qr-9700146.png', NULL, NULL, NULL);
INSERT INTO `oms_order_14` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (9700446, 462246, NULL, '9700446', '2022-10-11 05:15:07', NULL, 278.00, 278.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 5, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, 'mark', '13912345678', '100001', '河北', '河北', '北京', 'mark', NULL, 0, 0, NULL, '2022-10-11 05:25:30', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
COMMIT;

-- ----------------------------
-- Table structure for oms_order_15
-- ----------------------------
DROP TABLE IF EXISTS `oms_order_15`;
CREATE TABLE `oms_order_15` (
  `id` bigint NOT NULL DEFAULT '0' COMMENT '订单id',
  `member_id` bigint NOT NULL,
  `coupon_id` bigint DEFAULT NULL,
  `order_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '订单编号',
  `create_time` datetime DEFAULT NULL COMMENT '提交时间',
  `member_username` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '用户帐号',
  `total_amount` decimal(10,2) DEFAULT NULL COMMENT '订单总金额',
  `pay_amount` decimal(10,2) DEFAULT NULL COMMENT '应付金额（实际支付金额）',
  `freight_amount` decimal(10,2) DEFAULT NULL COMMENT '运费金额',
  `promotion_amount` decimal(10,2) DEFAULT NULL COMMENT '促销优化金额（促销价、满减、阶梯价）',
  `integration_amount` decimal(10,2) DEFAULT NULL COMMENT '积分抵扣金额',
  `coupon_amount` decimal(10,2) DEFAULT NULL COMMENT '优惠券抵扣金额',
  `discount_amount` decimal(10,2) DEFAULT NULL COMMENT '管理员后台调整订单使用的折扣金额',
  `pay_type` int DEFAULT NULL COMMENT '支付方式：0->未支付；1->支付宝；2->微信',
  `source_type` int DEFAULT NULL COMMENT '订单来源：0->PC订单；1->app订单',
  `status` int DEFAULT NULL COMMENT '订单状态：0->待付款；1->待发货；2->已发货；3->已完成；4->已关闭；5->无效订单',
  `order_type` int DEFAULT NULL COMMENT '订单类型：0->正常订单；1->秒杀订单',
  `delivery_company` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '物流公司(配送方式)',
  `delivery_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '物流单号',
  `auto_confirm_day` int DEFAULT NULL COMMENT '自动确认时间（天）',
  `integration` int DEFAULT NULL COMMENT '可以获得的积分',
  `growth` int DEFAULT NULL COMMENT '可以活动的成长值',
  `promotion_info` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '活动信息',
  `bill_type` int DEFAULT NULL COMMENT '发票类型：0->不开发票；1->电子发票；2->纸质发票',
  `bill_header` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '发票抬头',
  `bill_content` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '发票内容',
  `bill_receiver_phone` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '收票人电话',
  `bill_receiver_email` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '收票人邮箱',
  `receiver_name` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci NOT NULL COMMENT '收货人姓名',
  `receiver_phone` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci NOT NULL COMMENT '收货人电话',
  `receiver_post_code` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '收货人邮编',
  `receiver_province` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '省份/直辖市',
  `receiver_city` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '城市',
  `receiver_region` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '区',
  `receiver_detail_address` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '详细地址',
  `note` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '订单备注',
  `confirm_status` int DEFAULT NULL COMMENT '确认收货状态：0->未确认；1->已确认',
  `delete_status` int NOT NULL DEFAULT '0' COMMENT '删除状态：0->未删除；1->已删除',
  `use_integration` int DEFAULT NULL COMMENT '下单时使用的积分',
  `payment_time` datetime DEFAULT NULL COMMENT '支付时间',
  `delivery_time` datetime DEFAULT NULL COMMENT '发货时间',
  `receive_time` datetime DEFAULT NULL COMMENT '确认收货时间',
  `comment_time` datetime DEFAULT NULL COMMENT '评价时间',
  `modify_time` datetime DEFAULT NULL COMMENT '修改时间',
  `qrcode` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '支付二维码地址',
  `gmt_create` datetime(6) DEFAULT CURRENT_TIMESTAMP(6),
  `gmt_modified` datetime(6) DEFAULT NULL,
  `version` int DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ordersn` (`order_sn`),
  KEY `idx_member_id` (`member_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of oms_order_15
-- ----------------------------
BEGIN;
INSERT INTO `oms_order_15` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (61015, 462245, NULL, '61015', '2022-09-20 08:27:57', NULL, 4999.00, 4999.00, 0.00, 0.00, 0.00, NULL, 500.00, 1, 0, 0, 1, NULL, NULL, NULL, 5499, 5499, '秒杀特惠活动', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '福田区', '东晓街道', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2022-09-20 16:28:30.717761', NULL, 0);
INSERT INTO `oms_order_15` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (9701147, 462247, NULL, '9701147', '2022-10-11 05:56:22', NULL, 278.00, 278.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 5, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, 'xxx', '12312234233', '111111', '北京', '天津', '河北', '11', NULL, 0, 0, NULL, '2022-10-11 06:07:10', NULL, NULL, NULL, NULL, '/static/qrcode/alipay/qr-9701147.png', NULL, NULL, NULL);
INSERT INTO `oms_order_15` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (9701247, 462247, NULL, '9701247', '2022-10-11 05:58:07', NULL, 417.00, 417.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 5, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, 'xxx', '12312234233', '111111', '北京', '天津', '河北', '11', NULL, 0, 0, NULL, '2022-10-11 06:06:10', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_15` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (10100547, 462247, NULL, '10100547', '2022-10-11 07:48:32', NULL, 556.00, 556.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 5, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, 'xxx', '12312234233', '111111', '北京', '天津', '河北', '11', NULL, 0, 0, NULL, '2022-10-11 07:55:57', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_15` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (10503447, 462247, NULL, '10503447', '2022-10-11 09:36:20', NULL, 834.00, 834.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, 'xxx', '12312234233', '111111', '北京', '天津', '河北', '11', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_15` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (10503547, 462247, NULL, '10503547', '2022-10-11 09:37:48', NULL, 834.00, 834.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 5, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, 'xxx', '12312234233', '111111', '北京', '天津', '河北', '11', NULL, 0, 0, NULL, '2022-10-11 09:46:37', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_15` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (10503647, 462247, NULL, '10503647', '2022-10-11 09:38:50', NULL, 834.00, 834.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, 'xxx', '12312234233', '111111', '北京', '天津', '河北', '11', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_15` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (10504447, 462247, NULL, '10504447', '2022-10-11 09:56:34', NULL, 834.00, 834.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_15` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (10504547, 462247, NULL, '10504547', '2022-10-11 09:56:49', NULL, 834.00, 834.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_15` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (16901347, 462247, NULL, '16901347', '2022-11-16 05:32:52', NULL, 834.00, 834.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_15` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (16901447, 462247, NULL, '16901447', '2022-11-16 05:33:17', NULL, 834.00, 834.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_15` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (16901547, 462247, NULL, '16901547', '2022-11-16 05:34:08', NULL, 834.00, 834.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_15` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (16901647, 462247, NULL, '16901647', '2022-11-16 05:34:39', NULL, 834.00, 834.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_15` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (16901747, 462247, NULL, '16901747', '2022-11-16 05:35:30', NULL, 834.00, 834.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_15` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (16902847, 462247, NULL, '16902847', '2022-11-16 05:40:13', NULL, 834.00, 834.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_15` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (16902947, 462247, NULL, '16902947', '2022-11-16 05:41:16', NULL, 834.00, 834.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `oms_order_15` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (16903147, 462247, NULL, '16903147', '2022-11-16 05:41:49', NULL, 834.00, 834.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1, 1, 0, 0, NULL, NULL, NULL, 0, 0, '无优惠', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '南山区', '科兴科学园', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
COMMIT;

-- ----------------------------
-- Table structure for oms_order_16
-- ----------------------------
DROP TABLE IF EXISTS `oms_order_16`;
CREATE TABLE `oms_order_16` (
  `id` bigint NOT NULL DEFAULT '0' COMMENT '订单id',
  `member_id` bigint NOT NULL,
  `coupon_id` bigint DEFAULT NULL,
  `order_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '订单编号',
  `create_time` datetime DEFAULT NULL COMMENT '提交时间',
  `member_username` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '用户帐号',
  `total_amount` decimal(10,2) DEFAULT NULL COMMENT '订单总金额',
  `pay_amount` decimal(10,2) DEFAULT NULL COMMENT '应付金额（实际支付金额）',
  `freight_amount` decimal(10,2) DEFAULT NULL COMMENT '运费金额',
  `promotion_amount` decimal(10,2) DEFAULT NULL COMMENT '促销优化金额（促销价、满减、阶梯价）',
  `integration_amount` decimal(10,2) DEFAULT NULL COMMENT '积分抵扣金额',
  `coupon_amount` decimal(10,2) DEFAULT NULL COMMENT '优惠券抵扣金额',
  `discount_amount` decimal(10,2) DEFAULT NULL COMMENT '管理员后台调整订单使用的折扣金额',
  `pay_type` int DEFAULT NULL COMMENT '支付方式：0->未支付；1->支付宝；2->微信',
  `source_type` int DEFAULT NULL COMMENT '订单来源：0->PC订单；1->app订单',
  `status` int DEFAULT NULL COMMENT '订单状态：0->待付款；1->待发货；2->已发货；3->已完成；4->已关闭；5->无效订单',
  `order_type` int DEFAULT NULL COMMENT '订单类型：0->正常订单；1->秒杀订单',
  `delivery_company` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '物流公司(配送方式)',
  `delivery_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '物流单号',
  `auto_confirm_day` int DEFAULT NULL COMMENT '自动确认时间（天）',
  `integration` int DEFAULT NULL COMMENT '可以获得的积分',
  `growth` int DEFAULT NULL COMMENT '可以活动的成长值',
  `promotion_info` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '活动信息',
  `bill_type` int DEFAULT NULL COMMENT '发票类型：0->不开发票；1->电子发票；2->纸质发票',
  `bill_header` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '发票抬头',
  `bill_content` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '发票内容',
  `bill_receiver_phone` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '收票人电话',
  `bill_receiver_email` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '收票人邮箱',
  `receiver_name` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci NOT NULL COMMENT '收货人姓名',
  `receiver_phone` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci NOT NULL COMMENT '收货人电话',
  `receiver_post_code` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '收货人邮编',
  `receiver_province` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '省份/直辖市',
  `receiver_city` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '城市',
  `receiver_region` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '区',
  `receiver_detail_address` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '详细地址',
  `note` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '订单备注',
  `confirm_status` int DEFAULT NULL COMMENT '确认收货状态：0->未确认；1->已确认',
  `delete_status` int NOT NULL DEFAULT '0' COMMENT '删除状态：0->未删除；1->已删除',
  `use_integration` int DEFAULT NULL COMMENT '下单时使用的积分',
  `payment_time` datetime DEFAULT NULL COMMENT '支付时间',
  `delivery_time` datetime DEFAULT NULL COMMENT '发货时间',
  `receive_time` datetime DEFAULT NULL COMMENT '确认收货时间',
  `comment_time` datetime DEFAULT NULL COMMENT '评价时间',
  `modify_time` datetime DEFAULT NULL COMMENT '修改时间',
  `qrcode` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '支付二维码地址',
  `gmt_create` datetime(6) DEFAULT CURRENT_TIMESTAMP(6),
  `gmt_modified` datetime(6) DEFAULT NULL,
  `version` int DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ordersn` (`order_sn`),
  KEY `idx_member_id` (`member_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of oms_order_16
-- ----------------------------
BEGIN;
INSERT INTO `oms_order_16` (`id`, `member_id`, `coupon_id`, `order_sn`, `create_time`, `member_username`, `total_amount`, `pay_amount`, `freight_amount`, `promotion_amount`, `integration_amount`, `coupon_amount`, `discount_amount`, `pay_type`, `source_type`, `status`, `order_type`, `delivery_company`, `delivery_sn`, `auto_confirm_day`, `integration`, `growth`, `promotion_info`, `bill_type`, `bill_header`, `bill_content`, `bill_receiver_phone`, `bill_receiver_email`, `receiver_name`, `receiver_phone`, `receiver_post_code`, `receiver_province`, `receiver_city`, `receiver_region`, `receiver_detail_address`, `note`, `confirm_status`, `delete_status`, `use_integration`, `payment_time`, `delivery_time`, `receive_time`, `comment_time`, `modify_time`, `qrcode`, `gmt_create`, `gmt_modified`, `version`) VALUES (61016, 462245, NULL, '61016', '2022-09-20 08:59:54', NULL, 4999.00, 4999.00, 0.00, 0.00, 0.00, NULL, 500.00, 1, 0, 0, 1, NULL, NULL, NULL, 5499, 5499, '秒杀特惠活动', NULL, NULL, NULL, NULL, NULL, '大梨', '18033441849', '518000', '广东省', '深圳市', '福田区', '东晓街道', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2022-09-20 16:59:54.677871', NULL, 0);
COMMIT;

-- ----------------------------
-- Table structure for oms_order_17
-- ----------------------------
DROP TABLE IF EXISTS `oms_order_17`;
CREATE TABLE `oms_order_17` (
  `id` bigint NOT NULL DEFAULT '0' COMMENT '订单id',
  `member_id` bigint NOT NULL,
  `coupon_id` bigint DEFAULT NULL,
  `order_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '订单编号',
  `create_time` datetime DEFAULT NULL COMMENT '提交时间',
  `member_username` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '用户帐号',
  `total_amount` decimal(10,2) DEFAULT NULL COMMENT '订单总金额',
  `pay_amount` decimal(10,2) DEFAULT NULL COMMENT '应付金额（实际支付金额）',
  `freight_amount` decimal(10,2) DEFAULT NULL COMMENT '运费金额',
  `promotion_amount` decimal(10,2) DEFAULT NULL COMMENT '促销优化金额（促销价、满减、阶梯价）',
  `integration_amount` decimal(10,2) DEFAULT NULL COMMENT '积分抵扣金额',
  `coupon_amount` decimal(10,2) DEFAULT NULL COMMENT '优惠券抵扣金额',
  `discount_amount` decimal(10,2) DEFAULT NULL COMMENT '管理员后台调整订单使用的折扣金额',
  `pay_type` int DEFAULT NULL COMMENT '支付方式：0->未支付；1->支付宝；2->微信',
  `source_type` int DEFAULT NULL COMMENT '订单来源：0->PC订单；1->app订单',
  `status` int DEFAULT NULL COMMENT '订单状态：0->待付款；1->待发货；2->已发货；3->已完成；4->已关闭；5->无效订单',
  `order_type` int DEFAULT NULL COMMENT '订单类型：0->正常订单；1->秒杀订单',
  `delivery_company` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '物流公司(配送方式)',
  `delivery_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '物流单号',
  `auto_confirm_day` int DEFAULT NULL COMMENT '自动确认时间（天）',
  `integration` int DEFAULT NULL COMMENT '可以获得的积分',
  `growth` int DEFAULT NULL COMMENT '可以活动的成长值',
  `promotion_info` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '活动信息',
  `bill_type` int DEFAULT NULL COMMENT '发票类型：0->不开发票；1->电子发票；2->纸质发票',
  `bill_header` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '发票抬头',
  `bill_content` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '发票内容',
  `bill_receiver_phone` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '收票人电话',
  `bill_receiver_email` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '收票人邮箱',
  `receiver_name` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci NOT NULL COMMENT '收货人姓名',
  `receiver_phone` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci NOT NULL COMMENT '收货人电话',
  `receiver_post_code` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '收货人邮编',
  `receiver_province` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '省份/直辖市',
  `receiver_city` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '城市',
  `receiver_region` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '区',
  `receiver_detail_address` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '详细地址',
  `note` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '订单备注',
  `confirm_status` int DEFAULT NULL COMMENT '确认收货状态：0->未确认；1->已确认',
  `delete_status` int NOT NULL DEFAULT '0' COMMENT '删除状态：0->未删除；1->已删除',
  `use_integration` int DEFAULT NULL COMMENT '下单时使用的积分',
  `payment_time` datetime DEFAULT NULL COMMENT '支付时间',
  `delivery_time` datetime DEFAULT NULL COMMENT '发货时间',
  `receive_time` datetime DEFAULT NULL COMMENT '确认收货时间',
  `comment_time` datetime DEFAULT NULL COMMENT '评价时间',
  `modify_time` datetime DEFAULT NULL COMMENT '修改时间',
  `qrcode` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '支付二维码地址',
  `gmt_create` datetime(6) DEFAULT CURRENT_TIMESTAMP(6),
  `gmt_modified` datetime(6) DEFAULT NULL,
  `version` int DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ordersn` (`order_sn`),
  KEY `idx_member_id` (`member_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of oms_order_17
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for oms_order_18
-- ----------------------------
DROP TABLE IF EXISTS `oms_order_18`;
CREATE TABLE `oms_order_18` (
  `id` bigint NOT NULL DEFAULT '0' COMMENT '订单id',
  `member_id` bigint NOT NULL,
  `coupon_id` bigint DEFAULT NULL,
  `order_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '订单编号',
  `create_time` datetime DEFAULT NULL COMMENT '提交时间',
  `member_username` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '用户帐号',
  `total_amount` decimal(10,2) DEFAULT NULL COMMENT '订单总金额',
  `pay_amount` decimal(10,2) DEFAULT NULL COMMENT '应付金额（实际支付金额）',
  `freight_amount` decimal(10,2) DEFAULT NULL COMMENT '运费金额',
  `promotion_amount` decimal(10,2) DEFAULT NULL COMMENT '促销优化金额（促销价、满减、阶梯价）',
  `integration_amount` decimal(10,2) DEFAULT NULL COMMENT '积分抵扣金额',
  `coupon_amount` decimal(10,2) DEFAULT NULL COMMENT '优惠券抵扣金额',
  `discount_amount` decimal(10,2) DEFAULT NULL COMMENT '管理员后台调整订单使用的折扣金额',
  `pay_type` int DEFAULT NULL COMMENT '支付方式：0->未支付；1->支付宝；2->微信',
  `source_type` int DEFAULT NULL COMMENT '订单来源：0->PC订单；1->app订单',
  `status` int DEFAULT NULL COMMENT '订单状态：0->待付款；1->待发货；2->已发货；3->已完成；4->已关闭；5->无效订单',
  `order_type` int DEFAULT NULL COMMENT '订单类型：0->正常订单；1->秒杀订单',
  `delivery_company` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '物流公司(配送方式)',
  `delivery_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '物流单号',
  `auto_confirm_day` int DEFAULT NULL COMMENT '自动确认时间（天）',
  `integration` int DEFAULT NULL COMMENT '可以获得的积分',
  `growth` int DEFAULT NULL COMMENT '可以活动的成长值',
  `promotion_info` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '活动信息',
  `bill_type` int DEFAULT NULL COMMENT '发票类型：0->不开发票；1->电子发票；2->纸质发票',
  `bill_header` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '发票抬头',
  `bill_content` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '发票内容',
  `bill_receiver_phone` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '收票人电话',
  `bill_receiver_email` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '收票人邮箱',
  `receiver_name` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci NOT NULL COMMENT '收货人姓名',
  `receiver_phone` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci NOT NULL COMMENT '收货人电话',
  `receiver_post_code` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '收货人邮编',
  `receiver_province` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '省份/直辖市',
  `receiver_city` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '城市',
  `receiver_region` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '区',
  `receiver_detail_address` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '详细地址',
  `note` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '订单备注',
  `confirm_status` int DEFAULT NULL COMMENT '确认收货状态：0->未确认；1->已确认',
  `delete_status` int NOT NULL DEFAULT '0' COMMENT '删除状态：0->未删除；1->已删除',
  `use_integration` int DEFAULT NULL COMMENT '下单时使用的积分',
  `payment_time` datetime DEFAULT NULL COMMENT '支付时间',
  `delivery_time` datetime DEFAULT NULL COMMENT '发货时间',
  `receive_time` datetime DEFAULT NULL COMMENT '确认收货时间',
  `comment_time` datetime DEFAULT NULL COMMENT '评价时间',
  `modify_time` datetime DEFAULT NULL COMMENT '修改时间',
  `qrcode` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '支付二维码地址',
  `gmt_create` datetime(6) DEFAULT CURRENT_TIMESTAMP(6),
  `gmt_modified` datetime(6) DEFAULT NULL,
  `version` int DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ordersn` (`order_sn`),
  KEY `idx_member_id` (`member_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of oms_order_18
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for oms_order_19
-- ----------------------------
DROP TABLE IF EXISTS `oms_order_19`;
CREATE TABLE `oms_order_19` (
  `id` bigint NOT NULL DEFAULT '0' COMMENT '订单id',
  `member_id` bigint NOT NULL,
  `coupon_id` bigint DEFAULT NULL,
  `order_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '订单编号',
  `create_time` datetime DEFAULT NULL COMMENT '提交时间',
  `member_username` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '用户帐号',
  `total_amount` decimal(10,2) DEFAULT NULL COMMENT '订单总金额',
  `pay_amount` decimal(10,2) DEFAULT NULL COMMENT '应付金额（实际支付金额）',
  `freight_amount` decimal(10,2) DEFAULT NULL COMMENT '运费金额',
  `promotion_amount` decimal(10,2) DEFAULT NULL COMMENT '促销优化金额（促销价、满减、阶梯价）',
  `integration_amount` decimal(10,2) DEFAULT NULL COMMENT '积分抵扣金额',
  `coupon_amount` decimal(10,2) DEFAULT NULL COMMENT '优惠券抵扣金额',
  `discount_amount` decimal(10,2) DEFAULT NULL COMMENT '管理员后台调整订单使用的折扣金额',
  `pay_type` int DEFAULT NULL COMMENT '支付方式：0->未支付；1->支付宝；2->微信',
  `source_type` int DEFAULT NULL COMMENT '订单来源：0->PC订单；1->app订单',
  `status` int DEFAULT NULL COMMENT '订单状态：0->待付款；1->待发货；2->已发货；3->已完成；4->已关闭；5->无效订单',
  `order_type` int DEFAULT NULL COMMENT '订单类型：0->正常订单；1->秒杀订单',
  `delivery_company` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '物流公司(配送方式)',
  `delivery_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '物流单号',
  `auto_confirm_day` int DEFAULT NULL COMMENT '自动确认时间（天）',
  `integration` int DEFAULT NULL COMMENT '可以获得的积分',
  `growth` int DEFAULT NULL COMMENT '可以活动的成长值',
  `promotion_info` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '活动信息',
  `bill_type` int DEFAULT NULL COMMENT '发票类型：0->不开发票；1->电子发票；2->纸质发票',
  `bill_header` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '发票抬头',
  `bill_content` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '发票内容',
  `bill_receiver_phone` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '收票人电话',
  `bill_receiver_email` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '收票人邮箱',
  `receiver_name` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci NOT NULL COMMENT '收货人姓名',
  `receiver_phone` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci NOT NULL COMMENT '收货人电话',
  `receiver_post_code` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '收货人邮编',
  `receiver_province` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '省份/直辖市',
  `receiver_city` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '城市',
  `receiver_region` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '区',
  `receiver_detail_address` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '详细地址',
  `note` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '订单备注',
  `confirm_status` int DEFAULT NULL COMMENT '确认收货状态：0->未确认；1->已确认',
  `delete_status` int NOT NULL DEFAULT '0' COMMENT '删除状态：0->未删除；1->已删除',
  `use_integration` int DEFAULT NULL COMMENT '下单时使用的积分',
  `payment_time` datetime DEFAULT NULL COMMENT '支付时间',
  `delivery_time` datetime DEFAULT NULL COMMENT '发货时间',
  `receive_time` datetime DEFAULT NULL COMMENT '确认收货时间',
  `comment_time` datetime DEFAULT NULL COMMENT '评价时间',
  `modify_time` datetime DEFAULT NULL COMMENT '修改时间',
  `qrcode` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '支付二维码地址',
  `gmt_create` datetime(6) DEFAULT CURRENT_TIMESTAMP(6),
  `gmt_modified` datetime(6) DEFAULT NULL,
  `version` int DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ordersn` (`order_sn`),
  KEY `idx_member_id` (`member_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of oms_order_19
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for oms_order_2
-- ----------------------------
DROP TABLE IF EXISTS `oms_order_2`;
CREATE TABLE `oms_order_2` (
  `id` bigint NOT NULL DEFAULT '0' COMMENT '订单id',
  `member_id` bigint NOT NULL,
  `coupon_id` bigint DEFAULT NULL,
  `order_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '订单编号',
  `create_time` datetime DEFAULT NULL COMMENT '提交时间',
  `member_username` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '用户帐号',
  `total_amount` decimal(10,2) DEFAULT NULL COMMENT '订单总金额',
  `pay_amount` decimal(10,2) DEFAULT NULL COMMENT '应付金额（实际支付金额）',
  `freight_amount` decimal(10,2) DEFAULT NULL COMMENT '运费金额',
  `promotion_amount` decimal(10,2) DEFAULT NULL COMMENT '促销优化金额（促销价、满减、阶梯价）',
  `integration_amount` decimal(10,2) DEFAULT NULL COMMENT '积分抵扣金额',
  `coupon_amount` decimal(10,2) DEFAULT NULL COMMENT '优惠券抵扣金额',
  `discount_amount` decimal(10,2) DEFAULT NULL COMMENT '管理员后台调整订单使用的折扣金额',
  `pay_type` int DEFAULT NULL COMMENT '支付方式：0->未支付；1->支付宝；2->微信',
  `source_type` int DEFAULT NULL COMMENT '订单来源：0->PC订单；1->app订单',
  `status` int DEFAULT NULL COMMENT '订单状态：0->待付款；1->待发货；2->已发货；3->已完成；4->已关闭；5->无效订单',
  `order_type` int DEFAULT NULL COMMENT '订单类型：0->正常订单；1->秒杀订单',
  `delivery_company` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '物流公司(配送方式)',
  `delivery_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '物流单号',
  `auto_confirm_day` int DEFAULT NULL COMMENT '自动确认时间（天）',
  `integration` int DEFAULT NULL COMMENT '可以获得的积分',
  `growth` int DEFAULT NULL COMMENT '可以活动的成长值',
  `promotion_info` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '活动信息',
  `bill_type` int DEFAULT NULL COMMENT '发票类型：0->不开发票；1->电子发票；2->纸质发票',
  `bill_header` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '发票抬头',
  `bill_content` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '发票内容',
  `bill_receiver_phone` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '收票人电话',
  `bill_receiver_email` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '收票人邮箱',
  `receiver_name` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci NOT NULL COMMENT '收货人姓名',
  `receiver_phone` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci NOT NULL COMMENT '收货人电话',
  `receiver_post_code` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '收货人邮编',
  `receiver_province` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '省份/直辖市',
  `receiver_city` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '城市',
  `receiver_region` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '区',
  `receiver_detail_address` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '详细地址',
  `note` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '订单备注',
  `confirm_status` int DEFAULT NULL COMMENT '确认收货状态：0->未确认；1->已确认',
  `delete_status` int NOT NULL DEFAULT '0' COMMENT '删除状态：0->未删除；1->已删除',
  `use_integration` int DEFAULT NULL COMMENT '下单时使用的积分',
  `payment_time` datetime DEFAULT NULL COMMENT '支付时间',
  `delivery_time` datetime DEFAULT NULL COMMENT '发货时间',
  `receive_time` datetime DEFAULT NULL COMMENT '确认收货时间',
  `comment_time` datetime DEFAULT NULL COMMENT '评价时间',
  `modify_time` datetime DEFAULT NULL COMMENT '修改时间',
  `qrcode` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '支付二维码地址',
  `gmt_create` datetime(6) DEFAULT CURRENT_TIMESTAMP(6),
  `gmt_modified` datetime(6) DEFAULT NULL,
  `version` int DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ordersn` (`order_sn`),
  KEY `idx_member_id` (`member_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of oms_order_2
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for oms_order_20
-- ----------------------------
DROP TABLE IF EXISTS `oms_order_20`;
CREATE TABLE `oms_order_20` (
  `id` bigint NOT NULL DEFAULT '0' COMMENT '订单id',
  `member_id` bigint NOT NULL,
  `coupon_id` bigint DEFAULT NULL,
  `order_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '订单编号',
  `create_time` datetime DEFAULT NULL COMMENT '提交时间',
  `member_username` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '用户帐号',
  `total_amount` decimal(10,2) DEFAULT NULL COMMENT '订单总金额',
  `pay_amount` decimal(10,2) DEFAULT NULL COMMENT '应付金额（实际支付金额）',
  `freight_amount` decimal(10,2) DEFAULT NULL COMMENT '运费金额',
  `promotion_amount` decimal(10,2) DEFAULT NULL COMMENT '促销优化金额（促销价、满减、阶梯价）',
  `integration_amount` decimal(10,2) DEFAULT NULL COMMENT '积分抵扣金额',
  `coupon_amount` decimal(10,2) DEFAULT NULL COMMENT '优惠券抵扣金额',
  `discount_amount` decimal(10,2) DEFAULT NULL COMMENT '管理员后台调整订单使用的折扣金额',
  `pay_type` int DEFAULT NULL COMMENT '支付方式：0->未支付；1->支付宝；2->微信',
  `source_type` int DEFAULT NULL COMMENT '订单来源：0->PC订单；1->app订单',
  `status` int DEFAULT NULL COMMENT '订单状态：0->待付款；1->待发货；2->已发货；3->已完成；4->已关闭；5->无效订单',
  `order_type` int DEFAULT NULL COMMENT '订单类型：0->正常订单；1->秒杀订单',
  `delivery_company` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '物流公司(配送方式)',
  `delivery_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '物流单号',
  `auto_confirm_day` int DEFAULT NULL COMMENT '自动确认时间（天）',
  `integration` int DEFAULT NULL COMMENT '可以获得的积分',
  `growth` int DEFAULT NULL COMMENT '可以活动的成长值',
  `promotion_info` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '活动信息',
  `bill_type` int DEFAULT NULL COMMENT '发票类型：0->不开发票；1->电子发票；2->纸质发票',
  `bill_header` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '发票抬头',
  `bill_content` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '发票内容',
  `bill_receiver_phone` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '收票人电话',
  `bill_receiver_email` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '收票人邮箱',
  `receiver_name` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci NOT NULL COMMENT '收货人姓名',
  `receiver_phone` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci NOT NULL COMMENT '收货人电话',
  `receiver_post_code` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '收货人邮编',
  `receiver_province` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '省份/直辖市',
  `receiver_city` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '城市',
  `receiver_region` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '区',
  `receiver_detail_address` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '详细地址',
  `note` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '订单备注',
  `confirm_status` int DEFAULT NULL COMMENT '确认收货状态：0->未确认；1->已确认',
  `delete_status` int NOT NULL DEFAULT '0' COMMENT '删除状态：0->未删除；1->已删除',
  `use_integration` int DEFAULT NULL COMMENT '下单时使用的积分',
  `payment_time` datetime DEFAULT NULL COMMENT '支付时间',
  `delivery_time` datetime DEFAULT NULL COMMENT '发货时间',
  `receive_time` datetime DEFAULT NULL COMMENT '确认收货时间',
  `comment_time` datetime DEFAULT NULL COMMENT '评价时间',
  `modify_time` datetime DEFAULT NULL COMMENT '修改时间',
  `qrcode` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '支付二维码地址',
  `gmt_create` datetime(6) DEFAULT CURRENT_TIMESTAMP(6),
  `gmt_modified` datetime(6) DEFAULT NULL,
  `version` int DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ordersn` (`order_sn`),
  KEY `idx_member_id` (`member_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of oms_order_20
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for oms_order_21
-- ----------------------------
DROP TABLE IF EXISTS `oms_order_21`;
CREATE TABLE `oms_order_21` (
  `id` bigint NOT NULL DEFAULT '0' COMMENT '订单id',
  `member_id` bigint NOT NULL,
  `coupon_id` bigint DEFAULT NULL,
  `order_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '订单编号',
  `create_time` datetime DEFAULT NULL COMMENT '提交时间',
  `member_username` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '用户帐号',
  `total_amount` decimal(10,2) DEFAULT NULL COMMENT '订单总金额',
  `pay_amount` decimal(10,2) DEFAULT NULL COMMENT '应付金额（实际支付金额）',
  `freight_amount` decimal(10,2) DEFAULT NULL COMMENT '运费金额',
  `promotion_amount` decimal(10,2) DEFAULT NULL COMMENT '促销优化金额（促销价、满减、阶梯价）',
  `integration_amount` decimal(10,2) DEFAULT NULL COMMENT '积分抵扣金额',
  `coupon_amount` decimal(10,2) DEFAULT NULL COMMENT '优惠券抵扣金额',
  `discount_amount` decimal(10,2) DEFAULT NULL COMMENT '管理员后台调整订单使用的折扣金额',
  `pay_type` int DEFAULT NULL COMMENT '支付方式：0->未支付；1->支付宝；2->微信',
  `source_type` int DEFAULT NULL COMMENT '订单来源：0->PC订单；1->app订单',
  `status` int DEFAULT NULL COMMENT '订单状态：0->待付款；1->待发货；2->已发货；3->已完成；4->已关闭；5->无效订单',
  `order_type` int DEFAULT NULL COMMENT '订单类型：0->正常订单；1->秒杀订单',
  `delivery_company` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '物流公司(配送方式)',
  `delivery_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '物流单号',
  `auto_confirm_day` int DEFAULT NULL COMMENT '自动确认时间（天）',
  `integration` int DEFAULT NULL COMMENT '可以获得的积分',
  `growth` int DEFAULT NULL COMMENT '可以活动的成长值',
  `promotion_info` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '活动信息',
  `bill_type` int DEFAULT NULL COMMENT '发票类型：0->不开发票；1->电子发票；2->纸质发票',
  `bill_header` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '发票抬头',
  `bill_content` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '发票内容',
  `bill_receiver_phone` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '收票人电话',
  `bill_receiver_email` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '收票人邮箱',
  `receiver_name` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci NOT NULL COMMENT '收货人姓名',
  `receiver_phone` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci NOT NULL COMMENT '收货人电话',
  `receiver_post_code` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '收货人邮编',
  `receiver_province` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '省份/直辖市',
  `receiver_city` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '城市',
  `receiver_region` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '区',
  `receiver_detail_address` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '详细地址',
  `note` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '订单备注',
  `confirm_status` int DEFAULT NULL COMMENT '确认收货状态：0->未确认；1->已确认',
  `delete_status` int NOT NULL DEFAULT '0' COMMENT '删除状态：0->未删除；1->已删除',
  `use_integration` int DEFAULT NULL COMMENT '下单时使用的积分',
  `payment_time` datetime DEFAULT NULL COMMENT '支付时间',
  `delivery_time` datetime DEFAULT NULL COMMENT '发货时间',
  `receive_time` datetime DEFAULT NULL COMMENT '确认收货时间',
  `comment_time` datetime DEFAULT NULL COMMENT '评价时间',
  `modify_time` datetime DEFAULT NULL COMMENT '修改时间',
  `qrcode` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '支付二维码地址',
  `gmt_create` datetime(6) DEFAULT CURRENT_TIMESTAMP(6),
  `gmt_modified` datetime(6) DEFAULT NULL,
  `version` int DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ordersn` (`order_sn`),
  KEY `idx_member_id` (`member_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of oms_order_21
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for oms_order_22
-- ----------------------------
DROP TABLE IF EXISTS `oms_order_22`;
CREATE TABLE `oms_order_22` (
  `id` bigint NOT NULL DEFAULT '0' COMMENT '订单id',
  `member_id` bigint NOT NULL,
  `coupon_id` bigint DEFAULT NULL,
  `order_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '订单编号',
  `create_time` datetime DEFAULT NULL COMMENT '提交时间',
  `member_username` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '用户帐号',
  `total_amount` decimal(10,2) DEFAULT NULL COMMENT '订单总金额',
  `pay_amount` decimal(10,2) DEFAULT NULL COMMENT '应付金额（实际支付金额）',
  `freight_amount` decimal(10,2) DEFAULT NULL COMMENT '运费金额',
  `promotion_amount` decimal(10,2) DEFAULT NULL COMMENT '促销优化金额（促销价、满减、阶梯价）',
  `integration_amount` decimal(10,2) DEFAULT NULL COMMENT '积分抵扣金额',
  `coupon_amount` decimal(10,2) DEFAULT NULL COMMENT '优惠券抵扣金额',
  `discount_amount` decimal(10,2) DEFAULT NULL COMMENT '管理员后台调整订单使用的折扣金额',
  `pay_type` int DEFAULT NULL COMMENT '支付方式：0->未支付；1->支付宝；2->微信',
  `source_type` int DEFAULT NULL COMMENT '订单来源：0->PC订单；1->app订单',
  `status` int DEFAULT NULL COMMENT '订单状态：0->待付款；1->待发货；2->已发货；3->已完成；4->已关闭；5->无效订单',
  `order_type` int DEFAULT NULL COMMENT '订单类型：0->正常订单；1->秒杀订单',
  `delivery_company` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '物流公司(配送方式)',
  `delivery_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '物流单号',
  `auto_confirm_day` int DEFAULT NULL COMMENT '自动确认时间（天）',
  `integration` int DEFAULT NULL COMMENT '可以获得的积分',
  `growth` int DEFAULT NULL COMMENT '可以活动的成长值',
  `promotion_info` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '活动信息',
  `bill_type` int DEFAULT NULL COMMENT '发票类型：0->不开发票；1->电子发票；2->纸质发票',
  `bill_header` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '发票抬头',
  `bill_content` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '发票内容',
  `bill_receiver_phone` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '收票人电话',
  `bill_receiver_email` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '收票人邮箱',
  `receiver_name` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci NOT NULL COMMENT '收货人姓名',
  `receiver_phone` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci NOT NULL COMMENT '收货人电话',
  `receiver_post_code` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '收货人邮编',
  `receiver_province` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '省份/直辖市',
  `receiver_city` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '城市',
  `receiver_region` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '区',
  `receiver_detail_address` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '详细地址',
  `note` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '订单备注',
  `confirm_status` int DEFAULT NULL COMMENT '确认收货状态：0->未确认；1->已确认',
  `delete_status` int NOT NULL DEFAULT '0' COMMENT '删除状态：0->未删除；1->已删除',
  `use_integration` int DEFAULT NULL COMMENT '下单时使用的积分',
  `payment_time` datetime DEFAULT NULL COMMENT '支付时间',
  `delivery_time` datetime DEFAULT NULL COMMENT '发货时间',
  `receive_time` datetime DEFAULT NULL COMMENT '确认收货时间',
  `comment_time` datetime DEFAULT NULL COMMENT '评价时间',
  `modify_time` datetime DEFAULT NULL COMMENT '修改时间',
  `qrcode` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '支付二维码地址',
  `gmt_create` datetime(6) DEFAULT CURRENT_TIMESTAMP(6),
  `gmt_modified` datetime(6) DEFAULT NULL,
  `version` int DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ordersn` (`order_sn`),
  KEY `idx_member_id` (`member_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of oms_order_22
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for oms_order_23
-- ----------------------------
DROP TABLE IF EXISTS `oms_order_23`;
CREATE TABLE `oms_order_23` (
  `id` bigint NOT NULL DEFAULT '0' COMMENT '订单id',
  `member_id` bigint NOT NULL,
  `coupon_id` bigint DEFAULT NULL,
  `order_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '订单编号',
  `create_time` datetime DEFAULT NULL COMMENT '提交时间',
  `member_username` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '用户帐号',
  `total_amount` decimal(10,2) DEFAULT NULL COMMENT '订单总金额',
  `pay_amount` decimal(10,2) DEFAULT NULL COMMENT '应付金额（实际支付金额）',
  `freight_amount` decimal(10,2) DEFAULT NULL COMMENT '运费金额',
  `promotion_amount` decimal(10,2) DEFAULT NULL COMMENT '促销优化金额（促销价、满减、阶梯价）',
  `integration_amount` decimal(10,2) DEFAULT NULL COMMENT '积分抵扣金额',
  `coupon_amount` decimal(10,2) DEFAULT NULL COMMENT '优惠券抵扣金额',
  `discount_amount` decimal(10,2) DEFAULT NULL COMMENT '管理员后台调整订单使用的折扣金额',
  `pay_type` int DEFAULT NULL COMMENT '支付方式：0->未支付；1->支付宝；2->微信',
  `source_type` int DEFAULT NULL COMMENT '订单来源：0->PC订单；1->app订单',
  `status` int DEFAULT NULL COMMENT '订单状态：0->待付款；1->待发货；2->已发货；3->已完成；4->已关闭；5->无效订单',
  `order_type` int DEFAULT NULL COMMENT '订单类型：0->正常订单；1->秒杀订单',
  `delivery_company` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '物流公司(配送方式)',
  `delivery_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '物流单号',
  `auto_confirm_day` int DEFAULT NULL COMMENT '自动确认时间（天）',
  `integration` int DEFAULT NULL COMMENT '可以获得的积分',
  `growth` int DEFAULT NULL COMMENT '可以活动的成长值',
  `promotion_info` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '活动信息',
  `bill_type` int DEFAULT NULL COMMENT '发票类型：0->不开发票；1->电子发票；2->纸质发票',
  `bill_header` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '发票抬头',
  `bill_content` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '发票内容',
  `bill_receiver_phone` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '收票人电话',
  `bill_receiver_email` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '收票人邮箱',
  `receiver_name` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci NOT NULL COMMENT '收货人姓名',
  `receiver_phone` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci NOT NULL COMMENT '收货人电话',
  `receiver_post_code` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '收货人邮编',
  `receiver_province` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '省份/直辖市',
  `receiver_city` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '城市',
  `receiver_region` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '区',
  `receiver_detail_address` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '详细地址',
  `note` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '订单备注',
  `confirm_status` int DEFAULT NULL COMMENT '确认收货状态：0->未确认；1->已确认',
  `delete_status` int NOT NULL DEFAULT '0' COMMENT '删除状态：0->未删除；1->已删除',
  `use_integration` int DEFAULT NULL COMMENT '下单时使用的积分',
  `payment_time` datetime DEFAULT NULL COMMENT '支付时间',
  `delivery_time` datetime DEFAULT NULL COMMENT '发货时间',
  `receive_time` datetime DEFAULT NULL COMMENT '确认收货时间',
  `comment_time` datetime DEFAULT NULL COMMENT '评价时间',
  `modify_time` datetime DEFAULT NULL COMMENT '修改时间',
  `qrcode` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '支付二维码地址',
  `gmt_create` datetime(6) DEFAULT CURRENT_TIMESTAMP(6),
  `gmt_modified` datetime(6) DEFAULT NULL,
  `version` int DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ordersn` (`order_sn`),
  KEY `idx_member_id` (`member_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of oms_order_23
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for oms_order_24
-- ----------------------------
DROP TABLE IF EXISTS `oms_order_24`;
CREATE TABLE `oms_order_24` (
  `id` bigint NOT NULL DEFAULT '0' COMMENT '订单id',
  `member_id` bigint NOT NULL,
  `coupon_id` bigint DEFAULT NULL,
  `order_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '订单编号',
  `create_time` datetime DEFAULT NULL COMMENT '提交时间',
  `member_username` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '用户帐号',
  `total_amount` decimal(10,2) DEFAULT NULL COMMENT '订单总金额',
  `pay_amount` decimal(10,2) DEFAULT NULL COMMENT '应付金额（实际支付金额）',
  `freight_amount` decimal(10,2) DEFAULT NULL COMMENT '运费金额',
  `promotion_amount` decimal(10,2) DEFAULT NULL COMMENT '促销优化金额（促销价、满减、阶梯价）',
  `integration_amount` decimal(10,2) DEFAULT NULL COMMENT '积分抵扣金额',
  `coupon_amount` decimal(10,2) DEFAULT NULL COMMENT '优惠券抵扣金额',
  `discount_amount` decimal(10,2) DEFAULT NULL COMMENT '管理员后台调整订单使用的折扣金额',
  `pay_type` int DEFAULT NULL COMMENT '支付方式：0->未支付；1->支付宝；2->微信',
  `source_type` int DEFAULT NULL COMMENT '订单来源：0->PC订单；1->app订单',
  `status` int DEFAULT NULL COMMENT '订单状态：0->待付款；1->待发货；2->已发货；3->已完成；4->已关闭；5->无效订单',
  `order_type` int DEFAULT NULL COMMENT '订单类型：0->正常订单；1->秒杀订单',
  `delivery_company` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '物流公司(配送方式)',
  `delivery_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '物流单号',
  `auto_confirm_day` int DEFAULT NULL COMMENT '自动确认时间（天）',
  `integration` int DEFAULT NULL COMMENT '可以获得的积分',
  `growth` int DEFAULT NULL COMMENT '可以活动的成长值',
  `promotion_info` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '活动信息',
  `bill_type` int DEFAULT NULL COMMENT '发票类型：0->不开发票；1->电子发票；2->纸质发票',
  `bill_header` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '发票抬头',
  `bill_content` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '发票内容',
  `bill_receiver_phone` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '收票人电话',
  `bill_receiver_email` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '收票人邮箱',
  `receiver_name` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci NOT NULL COMMENT '收货人姓名',
  `receiver_phone` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci NOT NULL COMMENT '收货人电话',
  `receiver_post_code` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '收货人邮编',
  `receiver_province` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '省份/直辖市',
  `receiver_city` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '城市',
  `receiver_region` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '区',
  `receiver_detail_address` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '详细地址',
  `note` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '订单备注',
  `confirm_status` int DEFAULT NULL COMMENT '确认收货状态：0->未确认；1->已确认',
  `delete_status` int NOT NULL DEFAULT '0' COMMENT '删除状态：0->未删除；1->已删除',
  `use_integration` int DEFAULT NULL COMMENT '下单时使用的积分',
  `payment_time` datetime DEFAULT NULL COMMENT '支付时间',
  `delivery_time` datetime DEFAULT NULL COMMENT '发货时间',
  `receive_time` datetime DEFAULT NULL COMMENT '确认收货时间',
  `comment_time` datetime DEFAULT NULL COMMENT '评价时间',
  `modify_time` datetime DEFAULT NULL COMMENT '修改时间',
  `qrcode` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '支付二维码地址',
  `gmt_create` datetime(6) DEFAULT CURRENT_TIMESTAMP(6),
  `gmt_modified` datetime(6) DEFAULT NULL,
  `version` int DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ordersn` (`order_sn`),
  KEY `idx_member_id` (`member_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of oms_order_24
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for oms_order_25
-- ----------------------------
DROP TABLE IF EXISTS `oms_order_25`;
CREATE TABLE `oms_order_25` (
  `id` bigint NOT NULL DEFAULT '0' COMMENT '订单id',
  `member_id` bigint NOT NULL,
  `coupon_id` bigint DEFAULT NULL,
  `order_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '订单编号',
  `create_time` datetime DEFAULT NULL COMMENT '提交时间',
  `member_username` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '用户帐号',
  `total_amount` decimal(10,2) DEFAULT NULL COMMENT '订单总金额',
  `pay_amount` decimal(10,2) DEFAULT NULL COMMENT '应付金额（实际支付金额）',
  `freight_amount` decimal(10,2) DEFAULT NULL COMMENT '运费金额',
  `promotion_amount` decimal(10,2) DEFAULT NULL COMMENT '促销优化金额（促销价、满减、阶梯价）',
  `integration_amount` decimal(10,2) DEFAULT NULL COMMENT '积分抵扣金额',
  `coupon_amount` decimal(10,2) DEFAULT NULL COMMENT '优惠券抵扣金额',
  `discount_amount` decimal(10,2) DEFAULT NULL COMMENT '管理员后台调整订单使用的折扣金额',
  `pay_type` int DEFAULT NULL COMMENT '支付方式：0->未支付；1->支付宝；2->微信',
  `source_type` int DEFAULT NULL COMMENT '订单来源：0->PC订单；1->app订单',
  `status` int DEFAULT NULL COMMENT '订单状态：0->待付款；1->待发货；2->已发货；3->已完成；4->已关闭；5->无效订单',
  `order_type` int DEFAULT NULL COMMENT '订单类型：0->正常订单；1->秒杀订单',
  `delivery_company` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '物流公司(配送方式)',
  `delivery_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '物流单号',
  `auto_confirm_day` int DEFAULT NULL COMMENT '自动确认时间（天）',
  `integration` int DEFAULT NULL COMMENT '可以获得的积分',
  `growth` int DEFAULT NULL COMMENT '可以活动的成长值',
  `promotion_info` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '活动信息',
  `bill_type` int DEFAULT NULL COMMENT '发票类型：0->不开发票；1->电子发票；2->纸质发票',
  `bill_header` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '发票抬头',
  `bill_content` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '发票内容',
  `bill_receiver_phone` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '收票人电话',
  `bill_receiver_email` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '收票人邮箱',
  `receiver_name` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci NOT NULL COMMENT '收货人姓名',
  `receiver_phone` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci NOT NULL COMMENT '收货人电话',
  `receiver_post_code` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '收货人邮编',
  `receiver_province` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '省份/直辖市',
  `receiver_city` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '城市',
  `receiver_region` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '区',
  `receiver_detail_address` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '详细地址',
  `note` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '订单备注',
  `confirm_status` int DEFAULT NULL COMMENT '确认收货状态：0->未确认；1->已确认',
  `delete_status` int NOT NULL DEFAULT '0' COMMENT '删除状态：0->未删除；1->已删除',
  `use_integration` int DEFAULT NULL COMMENT '下单时使用的积分',
  `payment_time` datetime DEFAULT NULL COMMENT '支付时间',
  `delivery_time` datetime DEFAULT NULL COMMENT '发货时间',
  `receive_time` datetime DEFAULT NULL COMMENT '确认收货时间',
  `comment_time` datetime DEFAULT NULL COMMENT '评价时间',
  `modify_time` datetime DEFAULT NULL COMMENT '修改时间',
  `qrcode` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '支付二维码地址',
  `gmt_create` datetime(6) DEFAULT CURRENT_TIMESTAMP(6),
  `gmt_modified` datetime(6) DEFAULT NULL,
  `version` int DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ordersn` (`order_sn`),
  KEY `idx_member_id` (`member_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of oms_order_25
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for oms_order_26
-- ----------------------------
DROP TABLE IF EXISTS `oms_order_26`;
CREATE TABLE `oms_order_26` (
  `id` bigint NOT NULL DEFAULT '0' COMMENT '订单id',
  `member_id` bigint NOT NULL,
  `coupon_id` bigint DEFAULT NULL,
  `order_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '订单编号',
  `create_time` datetime DEFAULT NULL COMMENT '提交时间',
  `member_username` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '用户帐号',
  `total_amount` decimal(10,2) DEFAULT NULL COMMENT '订单总金额',
  `pay_amount` decimal(10,2) DEFAULT NULL COMMENT '应付金额（实际支付金额）',
  `freight_amount` decimal(10,2) DEFAULT NULL COMMENT '运费金额',
  `promotion_amount` decimal(10,2) DEFAULT NULL COMMENT '促销优化金额（促销价、满减、阶梯价）',
  `integration_amount` decimal(10,2) DEFAULT NULL COMMENT '积分抵扣金额',
  `coupon_amount` decimal(10,2) DEFAULT NULL COMMENT '优惠券抵扣金额',
  `discount_amount` decimal(10,2) DEFAULT NULL COMMENT '管理员后台调整订单使用的折扣金额',
  `pay_type` int DEFAULT NULL COMMENT '支付方式：0->未支付；1->支付宝；2->微信',
  `source_type` int DEFAULT NULL COMMENT '订单来源：0->PC订单；1->app订单',
  `status` int DEFAULT NULL COMMENT '订单状态：0->待付款；1->待发货；2->已发货；3->已完成；4->已关闭；5->无效订单',
  `order_type` int DEFAULT NULL COMMENT '订单类型：0->正常订单；1->秒杀订单',
  `delivery_company` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '物流公司(配送方式)',
  `delivery_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '物流单号',
  `auto_confirm_day` int DEFAULT NULL COMMENT '自动确认时间（天）',
  `integration` int DEFAULT NULL COMMENT '可以获得的积分',
  `growth` int DEFAULT NULL COMMENT '可以活动的成长值',
  `promotion_info` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '活动信息',
  `bill_type` int DEFAULT NULL COMMENT '发票类型：0->不开发票；1->电子发票；2->纸质发票',
  `bill_header` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '发票抬头',
  `bill_content` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '发票内容',
  `bill_receiver_phone` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '收票人电话',
  `bill_receiver_email` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '收票人邮箱',
  `receiver_name` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci NOT NULL COMMENT '收货人姓名',
  `receiver_phone` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci NOT NULL COMMENT '收货人电话',
  `receiver_post_code` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '收货人邮编',
  `receiver_province` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '省份/直辖市',
  `receiver_city` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '城市',
  `receiver_region` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '区',
  `receiver_detail_address` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '详细地址',
  `note` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '订单备注',
  `confirm_status` int DEFAULT NULL COMMENT '确认收货状态：0->未确认；1->已确认',
  `delete_status` int NOT NULL DEFAULT '0' COMMENT '删除状态：0->未删除；1->已删除',
  `use_integration` int DEFAULT NULL COMMENT '下单时使用的积分',
  `payment_time` datetime DEFAULT NULL COMMENT '支付时间',
  `delivery_time` datetime DEFAULT NULL COMMENT '发货时间',
  `receive_time` datetime DEFAULT NULL COMMENT '确认收货时间',
  `comment_time` datetime DEFAULT NULL COMMENT '评价时间',
  `modify_time` datetime DEFAULT NULL COMMENT '修改时间',
  `qrcode` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '支付二维码地址',
  `gmt_create` datetime(6) DEFAULT CURRENT_TIMESTAMP(6),
  `gmt_modified` datetime(6) DEFAULT NULL,
  `version` int DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ordersn` (`order_sn`),
  KEY `idx_member_id` (`member_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of oms_order_26
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for oms_order_27
-- ----------------------------
DROP TABLE IF EXISTS `oms_order_27`;
CREATE TABLE `oms_order_27` (
  `id` bigint NOT NULL DEFAULT '0' COMMENT '订单id',
  `member_id` bigint NOT NULL,
  `coupon_id` bigint DEFAULT NULL,
  `order_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '订单编号',
  `create_time` datetime DEFAULT NULL COMMENT '提交时间',
  `member_username` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '用户帐号',
  `total_amount` decimal(10,2) DEFAULT NULL COMMENT '订单总金额',
  `pay_amount` decimal(10,2) DEFAULT NULL COMMENT '应付金额（实际支付金额）',
  `freight_amount` decimal(10,2) DEFAULT NULL COMMENT '运费金额',
  `promotion_amount` decimal(10,2) DEFAULT NULL COMMENT '促销优化金额（促销价、满减、阶梯价）',
  `integration_amount` decimal(10,2) DEFAULT NULL COMMENT '积分抵扣金额',
  `coupon_amount` decimal(10,2) DEFAULT NULL COMMENT '优惠券抵扣金额',
  `discount_amount` decimal(10,2) DEFAULT NULL COMMENT '管理员后台调整订单使用的折扣金额',
  `pay_type` int DEFAULT NULL COMMENT '支付方式：0->未支付；1->支付宝；2->微信',
  `source_type` int DEFAULT NULL COMMENT '订单来源：0->PC订单；1->app订单',
  `status` int DEFAULT NULL COMMENT '订单状态：0->待付款；1->待发货；2->已发货；3->已完成；4->已关闭；5->无效订单',
  `order_type` int DEFAULT NULL COMMENT '订单类型：0->正常订单；1->秒杀订单',
  `delivery_company` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '物流公司(配送方式)',
  `delivery_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '物流单号',
  `auto_confirm_day` int DEFAULT NULL COMMENT '自动确认时间（天）',
  `integration` int DEFAULT NULL COMMENT '可以获得的积分',
  `growth` int DEFAULT NULL COMMENT '可以活动的成长值',
  `promotion_info` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '活动信息',
  `bill_type` int DEFAULT NULL COMMENT '发票类型：0->不开发票；1->电子发票；2->纸质发票',
  `bill_header` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '发票抬头',
  `bill_content` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '发票内容',
  `bill_receiver_phone` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '收票人电话',
  `bill_receiver_email` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '收票人邮箱',
  `receiver_name` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci NOT NULL COMMENT '收货人姓名',
  `receiver_phone` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci NOT NULL COMMENT '收货人电话',
  `receiver_post_code` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '收货人邮编',
  `receiver_province` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '省份/直辖市',
  `receiver_city` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '城市',
  `receiver_region` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '区',
  `receiver_detail_address` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '详细地址',
  `note` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '订单备注',
  `confirm_status` int DEFAULT NULL COMMENT '确认收货状态：0->未确认；1->已确认',
  `delete_status` int NOT NULL DEFAULT '0' COMMENT '删除状态：0->未删除；1->已删除',
  `use_integration` int DEFAULT NULL COMMENT '下单时使用的积分',
  `payment_time` datetime DEFAULT NULL COMMENT '支付时间',
  `delivery_time` datetime DEFAULT NULL COMMENT '发货时间',
  `receive_time` datetime DEFAULT NULL COMMENT '确认收货时间',
  `comment_time` datetime DEFAULT NULL COMMENT '评价时间',
  `modify_time` datetime DEFAULT NULL COMMENT '修改时间',
  `qrcode` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '支付二维码地址',
  `gmt_create` datetime(6) DEFAULT CURRENT_TIMESTAMP(6),
  `gmt_modified` datetime(6) DEFAULT NULL,
  `version` int DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ordersn` (`order_sn`),
  KEY `idx_member_id` (`member_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of oms_order_27
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for oms_order_28
-- ----------------------------
DROP TABLE IF EXISTS `oms_order_28`;
CREATE TABLE `oms_order_28` (
  `id` bigint NOT NULL DEFAULT '0' COMMENT '订单id',
  `member_id` bigint NOT NULL,
  `coupon_id` bigint DEFAULT NULL,
  `order_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '订单编号',
  `create_time` datetime DEFAULT NULL COMMENT '提交时间',
  `member_username` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '用户帐号',
  `total_amount` decimal(10,2) DEFAULT NULL COMMENT '订单总金额',
  `pay_amount` decimal(10,2) DEFAULT NULL COMMENT '应付金额（实际支付金额）',
  `freight_amount` decimal(10,2) DEFAULT NULL COMMENT '运费金额',
  `promotion_amount` decimal(10,2) DEFAULT NULL COMMENT '促销优化金额（促销价、满减、阶梯价）',
  `integration_amount` decimal(10,2) DEFAULT NULL COMMENT '积分抵扣金额',
  `coupon_amount` decimal(10,2) DEFAULT NULL COMMENT '优惠券抵扣金额',
  `discount_amount` decimal(10,2) DEFAULT NULL COMMENT '管理员后台调整订单使用的折扣金额',
  `pay_type` int DEFAULT NULL COMMENT '支付方式：0->未支付；1->支付宝；2->微信',
  `source_type` int DEFAULT NULL COMMENT '订单来源：0->PC订单；1->app订单',
  `status` int DEFAULT NULL COMMENT '订单状态：0->待付款；1->待发货；2->已发货；3->已完成；4->已关闭；5->无效订单',
  `order_type` int DEFAULT NULL COMMENT '订单类型：0->正常订单；1->秒杀订单',
  `delivery_company` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '物流公司(配送方式)',
  `delivery_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '物流单号',
  `auto_confirm_day` int DEFAULT NULL COMMENT '自动确认时间（天）',
  `integration` int DEFAULT NULL COMMENT '可以获得的积分',
  `growth` int DEFAULT NULL COMMENT '可以活动的成长值',
  `promotion_info` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '活动信息',
  `bill_type` int DEFAULT NULL COMMENT '发票类型：0->不开发票；1->电子发票；2->纸质发票',
  `bill_header` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '发票抬头',
  `bill_content` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '发票内容',
  `bill_receiver_phone` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '收票人电话',
  `bill_receiver_email` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '收票人邮箱',
  `receiver_name` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci NOT NULL COMMENT '收货人姓名',
  `receiver_phone` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci NOT NULL COMMENT '收货人电话',
  `receiver_post_code` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '收货人邮编',
  `receiver_province` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '省份/直辖市',
  `receiver_city` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '城市',
  `receiver_region` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '区',
  `receiver_detail_address` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '详细地址',
  `note` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '订单备注',
  `confirm_status` int DEFAULT NULL COMMENT '确认收货状态：0->未确认；1->已确认',
  `delete_status` int NOT NULL DEFAULT '0' COMMENT '删除状态：0->未删除；1->已删除',
  `use_integration` int DEFAULT NULL COMMENT '下单时使用的积分',
  `payment_time` datetime DEFAULT NULL COMMENT '支付时间',
  `delivery_time` datetime DEFAULT NULL COMMENT '发货时间',
  `receive_time` datetime DEFAULT NULL COMMENT '确认收货时间',
  `comment_time` datetime DEFAULT NULL COMMENT '评价时间',
  `modify_time` datetime DEFAULT NULL COMMENT '修改时间',
  `qrcode` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '支付二维码地址',
  `gmt_create` datetime(6) DEFAULT CURRENT_TIMESTAMP(6),
  `gmt_modified` datetime(6) DEFAULT NULL,
  `version` int DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ordersn` (`order_sn`),
  KEY `idx_member_id` (`member_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of oms_order_28
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for oms_order_29
-- ----------------------------
DROP TABLE IF EXISTS `oms_order_29`;
CREATE TABLE `oms_order_29` (
  `id` bigint NOT NULL DEFAULT '0' COMMENT '订单id',
  `member_id` bigint NOT NULL,
  `coupon_id` bigint DEFAULT NULL,
  `order_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '订单编号',
  `create_time` datetime DEFAULT NULL COMMENT '提交时间',
  `member_username` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '用户帐号',
  `total_amount` decimal(10,2) DEFAULT NULL COMMENT '订单总金额',
  `pay_amount` decimal(10,2) DEFAULT NULL COMMENT '应付金额（实际支付金额）',
  `freight_amount` decimal(10,2) DEFAULT NULL COMMENT '运费金额',
  `promotion_amount` decimal(10,2) DEFAULT NULL COMMENT '促销优化金额（促销价、满减、阶梯价）',
  `integration_amount` decimal(10,2) DEFAULT NULL COMMENT '积分抵扣金额',
  `coupon_amount` decimal(10,2) DEFAULT NULL COMMENT '优惠券抵扣金额',
  `discount_amount` decimal(10,2) DEFAULT NULL COMMENT '管理员后台调整订单使用的折扣金额',
  `pay_type` int DEFAULT NULL COMMENT '支付方式：0->未支付；1->支付宝；2->微信',
  `source_type` int DEFAULT NULL COMMENT '订单来源：0->PC订单；1->app订单',
  `status` int DEFAULT NULL COMMENT '订单状态：0->待付款；1->待发货；2->已发货；3->已完成；4->已关闭；5->无效订单',
  `order_type` int DEFAULT NULL COMMENT '订单类型：0->正常订单；1->秒杀订单',
  `delivery_company` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '物流公司(配送方式)',
  `delivery_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '物流单号',
  `auto_confirm_day` int DEFAULT NULL COMMENT '自动确认时间（天）',
  `integration` int DEFAULT NULL COMMENT '可以获得的积分',
  `growth` int DEFAULT NULL COMMENT '可以活动的成长值',
  `promotion_info` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '活动信息',
  `bill_type` int DEFAULT NULL COMMENT '发票类型：0->不开发票；1->电子发票；2->纸质发票',
  `bill_header` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '发票抬头',
  `bill_content` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '发票内容',
  `bill_receiver_phone` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '收票人电话',
  `bill_receiver_email` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '收票人邮箱',
  `receiver_name` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci NOT NULL COMMENT '收货人姓名',
  `receiver_phone` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci NOT NULL COMMENT '收货人电话',
  `receiver_post_code` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '收货人邮编',
  `receiver_province` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '省份/直辖市',
  `receiver_city` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '城市',
  `receiver_region` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '区',
  `receiver_detail_address` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '详细地址',
  `note` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '订单备注',
  `confirm_status` int DEFAULT NULL COMMENT '确认收货状态：0->未确认；1->已确认',
  `delete_status` int NOT NULL DEFAULT '0' COMMENT '删除状态：0->未删除；1->已删除',
  `use_integration` int DEFAULT NULL COMMENT '下单时使用的积分',
  `payment_time` datetime DEFAULT NULL COMMENT '支付时间',
  `delivery_time` datetime DEFAULT NULL COMMENT '发货时间',
  `receive_time` datetime DEFAULT NULL COMMENT '确认收货时间',
  `comment_time` datetime DEFAULT NULL COMMENT '评价时间',
  `modify_time` datetime DEFAULT NULL COMMENT '修改时间',
  `qrcode` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '支付二维码地址',
  `gmt_create` datetime(6) DEFAULT CURRENT_TIMESTAMP(6),
  `gmt_modified` datetime(6) DEFAULT NULL,
  `version` int DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ordersn` (`order_sn`),
  KEY `idx_member_id` (`member_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of oms_order_29
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for oms_order_3
-- ----------------------------
DROP TABLE IF EXISTS `oms_order_3`;
CREATE TABLE `oms_order_3` (
  `id` bigint NOT NULL DEFAULT '0' COMMENT '订单id',
  `member_id` bigint NOT NULL,
  `coupon_id` bigint DEFAULT NULL,
  `order_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '订单编号',
  `create_time` datetime DEFAULT NULL COMMENT '提交时间',
  `member_username` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '用户帐号',
  `total_amount` decimal(10,2) DEFAULT NULL COMMENT '订单总金额',
  `pay_amount` decimal(10,2) DEFAULT NULL COMMENT '应付金额（实际支付金额）',
  `freight_amount` decimal(10,2) DEFAULT NULL COMMENT '运费金额',
  `promotion_amount` decimal(10,2) DEFAULT NULL COMMENT '促销优化金额（促销价、满减、阶梯价）',
  `integration_amount` decimal(10,2) DEFAULT NULL COMMENT '积分抵扣金额',
  `coupon_amount` decimal(10,2) DEFAULT NULL COMMENT '优惠券抵扣金额',
  `discount_amount` decimal(10,2) DEFAULT NULL COMMENT '管理员后台调整订单使用的折扣金额',
  `pay_type` int DEFAULT NULL COMMENT '支付方式：0->未支付；1->支付宝；2->微信',
  `source_type` int DEFAULT NULL COMMENT '订单来源：0->PC订单；1->app订单',
  `status` int DEFAULT NULL COMMENT '订单状态：0->待付款；1->待发货；2->已发货；3->已完成；4->已关闭；5->无效订单',
  `order_type` int DEFAULT NULL COMMENT '订单类型：0->正常订单；1->秒杀订单',
  `delivery_company` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '物流公司(配送方式)',
  `delivery_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '物流单号',
  `auto_confirm_day` int DEFAULT NULL COMMENT '自动确认时间（天）',
  `integration` int DEFAULT NULL COMMENT '可以获得的积分',
  `growth` int DEFAULT NULL COMMENT '可以活动的成长值',
  `promotion_info` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '活动信息',
  `bill_type` int DEFAULT NULL COMMENT '发票类型：0->不开发票；1->电子发票；2->纸质发票',
  `bill_header` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '发票抬头',
  `bill_content` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '发票内容',
  `bill_receiver_phone` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '收票人电话',
  `bill_receiver_email` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '收票人邮箱',
  `receiver_name` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci NOT NULL COMMENT '收货人姓名',
  `receiver_phone` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci NOT NULL COMMENT '收货人电话',
  `receiver_post_code` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '收货人邮编',
  `receiver_province` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '省份/直辖市',
  `receiver_city` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '城市',
  `receiver_region` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '区',
  `receiver_detail_address` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '详细地址',
  `note` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '订单备注',
  `confirm_status` int DEFAULT NULL COMMENT '确认收货状态：0->未确认；1->已确认',
  `delete_status` int NOT NULL DEFAULT '0' COMMENT '删除状态：0->未删除；1->已删除',
  `use_integration` int DEFAULT NULL COMMENT '下单时使用的积分',
  `payment_time` datetime DEFAULT NULL COMMENT '支付时间',
  `delivery_time` datetime DEFAULT NULL COMMENT '发货时间',
  `receive_time` datetime DEFAULT NULL COMMENT '确认收货时间',
  `comment_time` datetime DEFAULT NULL COMMENT '评价时间',
  `modify_time` datetime DEFAULT NULL COMMENT '修改时间',
  `qrcode` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '支付二维码地址',
  `gmt_create` datetime(6) DEFAULT CURRENT_TIMESTAMP(6),
  `gmt_modified` datetime(6) DEFAULT NULL,
  `version` int DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ordersn` (`order_sn`),
  KEY `idx_member_id` (`member_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of oms_order_3
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for oms_order_30
-- ----------------------------
DROP TABLE IF EXISTS `oms_order_30`;
CREATE TABLE `oms_order_30` (
  `id` bigint NOT NULL DEFAULT '0' COMMENT '订单id',
  `member_id` bigint NOT NULL,
  `coupon_id` bigint DEFAULT NULL,
  `order_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '订单编号',
  `create_time` datetime DEFAULT NULL COMMENT '提交时间',
  `member_username` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '用户帐号',
  `total_amount` decimal(10,2) DEFAULT NULL COMMENT '订单总金额',
  `pay_amount` decimal(10,2) DEFAULT NULL COMMENT '应付金额（实际支付金额）',
  `freight_amount` decimal(10,2) DEFAULT NULL COMMENT '运费金额',
  `promotion_amount` decimal(10,2) DEFAULT NULL COMMENT '促销优化金额（促销价、满减、阶梯价）',
  `integration_amount` decimal(10,2) DEFAULT NULL COMMENT '积分抵扣金额',
  `coupon_amount` decimal(10,2) DEFAULT NULL COMMENT '优惠券抵扣金额',
  `discount_amount` decimal(10,2) DEFAULT NULL COMMENT '管理员后台调整订单使用的折扣金额',
  `pay_type` int DEFAULT NULL COMMENT '支付方式：0->未支付；1->支付宝；2->微信',
  `source_type` int DEFAULT NULL COMMENT '订单来源：0->PC订单；1->app订单',
  `status` int DEFAULT NULL COMMENT '订单状态：0->待付款；1->待发货；2->已发货；3->已完成；4->已关闭；5->无效订单',
  `order_type` int DEFAULT NULL COMMENT '订单类型：0->正常订单；1->秒杀订单',
  `delivery_company` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '物流公司(配送方式)',
  `delivery_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '物流单号',
  `auto_confirm_day` int DEFAULT NULL COMMENT '自动确认时间（天）',
  `integration` int DEFAULT NULL COMMENT '可以获得的积分',
  `growth` int DEFAULT NULL COMMENT '可以活动的成长值',
  `promotion_info` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '活动信息',
  `bill_type` int DEFAULT NULL COMMENT '发票类型：0->不开发票；1->电子发票；2->纸质发票',
  `bill_header` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '发票抬头',
  `bill_content` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '发票内容',
  `bill_receiver_phone` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '收票人电话',
  `bill_receiver_email` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '收票人邮箱',
  `receiver_name` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci NOT NULL COMMENT '收货人姓名',
  `receiver_phone` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci NOT NULL COMMENT '收货人电话',
  `receiver_post_code` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '收货人邮编',
  `receiver_province` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '省份/直辖市',
  `receiver_city` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '城市',
  `receiver_region` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '区',
  `receiver_detail_address` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '详细地址',
  `note` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '订单备注',
  `confirm_status` int DEFAULT NULL COMMENT '确认收货状态：0->未确认；1->已确认',
  `delete_status` int NOT NULL DEFAULT '0' COMMENT '删除状态：0->未删除；1->已删除',
  `use_integration` int DEFAULT NULL COMMENT '下单时使用的积分',
  `payment_time` datetime DEFAULT NULL COMMENT '支付时间',
  `delivery_time` datetime DEFAULT NULL COMMENT '发货时间',
  `receive_time` datetime DEFAULT NULL COMMENT '确认收货时间',
  `comment_time` datetime DEFAULT NULL COMMENT '评价时间',
  `modify_time` datetime DEFAULT NULL COMMENT '修改时间',
  `qrcode` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '支付二维码地址',
  `gmt_create` datetime(6) DEFAULT CURRENT_TIMESTAMP(6),
  `gmt_modified` datetime(6) DEFAULT NULL,
  `version` int DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ordersn` (`order_sn`),
  KEY `idx_member_id` (`member_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of oms_order_30
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for oms_order_31
-- ----------------------------
DROP TABLE IF EXISTS `oms_order_31`;
CREATE TABLE `oms_order_31` (
  `id` bigint NOT NULL DEFAULT '0' COMMENT '订单id',
  `member_id` bigint NOT NULL,
  `coupon_id` bigint DEFAULT NULL,
  `order_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '订单编号',
  `create_time` datetime DEFAULT NULL COMMENT '提交时间',
  `member_username` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '用户帐号',
  `total_amount` decimal(10,2) DEFAULT NULL COMMENT '订单总金额',
  `pay_amount` decimal(10,2) DEFAULT NULL COMMENT '应付金额（实际支付金额）',
  `freight_amount` decimal(10,2) DEFAULT NULL COMMENT '运费金额',
  `promotion_amount` decimal(10,2) DEFAULT NULL COMMENT '促销优化金额（促销价、满减、阶梯价）',
  `integration_amount` decimal(10,2) DEFAULT NULL COMMENT '积分抵扣金额',
  `coupon_amount` decimal(10,2) DEFAULT NULL COMMENT '优惠券抵扣金额',
  `discount_amount` decimal(10,2) DEFAULT NULL COMMENT '管理员后台调整订单使用的折扣金额',
  `pay_type` int DEFAULT NULL COMMENT '支付方式：0->未支付；1->支付宝；2->微信',
  `source_type` int DEFAULT NULL COMMENT '订单来源：0->PC订单；1->app订单',
  `status` int DEFAULT NULL COMMENT '订单状态：0->待付款；1->待发货；2->已发货；3->已完成；4->已关闭；5->无效订单',
  `order_type` int DEFAULT NULL COMMENT '订单类型：0->正常订单；1->秒杀订单',
  `delivery_company` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '物流公司(配送方式)',
  `delivery_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '物流单号',
  `auto_confirm_day` int DEFAULT NULL COMMENT '自动确认时间（天）',
  `integration` int DEFAULT NULL COMMENT '可以获得的积分',
  `growth` int DEFAULT NULL COMMENT '可以活动的成长值',
  `promotion_info` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '活动信息',
  `bill_type` int DEFAULT NULL COMMENT '发票类型：0->不开发票；1->电子发票；2->纸质发票',
  `bill_header` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '发票抬头',
  `bill_content` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '发票内容',
  `bill_receiver_phone` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '收票人电话',
  `bill_receiver_email` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '收票人邮箱',
  `receiver_name` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci NOT NULL COMMENT '收货人姓名',
  `receiver_phone` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci NOT NULL COMMENT '收货人电话',
  `receiver_post_code` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '收货人邮编',
  `receiver_province` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '省份/直辖市',
  `receiver_city` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '城市',
  `receiver_region` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '区',
  `receiver_detail_address` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '详细地址',
  `note` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '订单备注',
  `confirm_status` int DEFAULT NULL COMMENT '确认收货状态：0->未确认；1->已确认',
  `delete_status` int NOT NULL DEFAULT '0' COMMENT '删除状态：0->未删除；1->已删除',
  `use_integration` int DEFAULT NULL COMMENT '下单时使用的积分',
  `payment_time` datetime DEFAULT NULL COMMENT '支付时间',
  `delivery_time` datetime DEFAULT NULL COMMENT '发货时间',
  `receive_time` datetime DEFAULT NULL COMMENT '确认收货时间',
  `comment_time` datetime DEFAULT NULL COMMENT '评价时间',
  `modify_time` datetime DEFAULT NULL COMMENT '修改时间',
  `qrcode` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '支付二维码地址',
  `gmt_create` datetime(6) DEFAULT CURRENT_TIMESTAMP(6),
  `gmt_modified` datetime(6) DEFAULT NULL,
  `version` int DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ordersn` (`order_sn`),
  KEY `idx_member_id` (`member_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of oms_order_31
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for oms_order_4
-- ----------------------------
DROP TABLE IF EXISTS `oms_order_4`;
CREATE TABLE `oms_order_4` (
  `id` bigint NOT NULL DEFAULT '0' COMMENT '订单id',
  `member_id` bigint NOT NULL,
  `coupon_id` bigint DEFAULT NULL,
  `order_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '订单编号',
  `create_time` datetime DEFAULT NULL COMMENT '提交时间',
  `member_username` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '用户帐号',
  `total_amount` decimal(10,2) DEFAULT NULL COMMENT '订单总金额',
  `pay_amount` decimal(10,2) DEFAULT NULL COMMENT '应付金额（实际支付金额）',
  `freight_amount` decimal(10,2) DEFAULT NULL COMMENT '运费金额',
  `promotion_amount` decimal(10,2) DEFAULT NULL COMMENT '促销优化金额（促销价、满减、阶梯价）',
  `integration_amount` decimal(10,2) DEFAULT NULL COMMENT '积分抵扣金额',
  `coupon_amount` decimal(10,2) DEFAULT NULL COMMENT '优惠券抵扣金额',
  `discount_amount` decimal(10,2) DEFAULT NULL COMMENT '管理员后台调整订单使用的折扣金额',
  `pay_type` int DEFAULT NULL COMMENT '支付方式：0->未支付；1->支付宝；2->微信',
  `source_type` int DEFAULT NULL COMMENT '订单来源：0->PC订单；1->app订单',
  `status` int DEFAULT NULL COMMENT '订单状态：0->待付款；1->待发货；2->已发货；3->已完成；4->已关闭；5->无效订单',
  `order_type` int DEFAULT NULL COMMENT '订单类型：0->正常订单；1->秒杀订单',
  `delivery_company` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '物流公司(配送方式)',
  `delivery_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '物流单号',
  `auto_confirm_day` int DEFAULT NULL COMMENT '自动确认时间（天）',
  `integration` int DEFAULT NULL COMMENT '可以获得的积分',
  `growth` int DEFAULT NULL COMMENT '可以活动的成长值',
  `promotion_info` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '活动信息',
  `bill_type` int DEFAULT NULL COMMENT '发票类型：0->不开发票；1->电子发票；2->纸质发票',
  `bill_header` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '发票抬头',
  `bill_content` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '发票内容',
  `bill_receiver_phone` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '收票人电话',
  `bill_receiver_email` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '收票人邮箱',
  `receiver_name` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci NOT NULL COMMENT '收货人姓名',
  `receiver_phone` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci NOT NULL COMMENT '收货人电话',
  `receiver_post_code` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '收货人邮编',
  `receiver_province` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '省份/直辖市',
  `receiver_city` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '城市',
  `receiver_region` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '区',
  `receiver_detail_address` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '详细地址',
  `note` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '订单备注',
  `confirm_status` int DEFAULT NULL COMMENT '确认收货状态：0->未确认；1->已确认',
  `delete_status` int NOT NULL DEFAULT '0' COMMENT '删除状态：0->未删除；1->已删除',
  `use_integration` int DEFAULT NULL COMMENT '下单时使用的积分',
  `payment_time` datetime DEFAULT NULL COMMENT '支付时间',
  `delivery_time` datetime DEFAULT NULL COMMENT '发货时间',
  `receive_time` datetime DEFAULT NULL COMMENT '确认收货时间',
  `comment_time` datetime DEFAULT NULL COMMENT '评价时间',
  `modify_time` datetime DEFAULT NULL COMMENT '修改时间',
  `qrcode` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '支付二维码地址',
  `gmt_create` datetime(6) DEFAULT CURRENT_TIMESTAMP(6),
  `gmt_modified` datetime(6) DEFAULT NULL,
  `version` int DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ordersn` (`order_sn`),
  KEY `idx_member_id` (`member_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of oms_order_4
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for oms_order_5
-- ----------------------------
DROP TABLE IF EXISTS `oms_order_5`;
CREATE TABLE `oms_order_5` (
  `id` bigint NOT NULL DEFAULT '0' COMMENT '订单id',
  `member_id` bigint NOT NULL,
  `coupon_id` bigint DEFAULT NULL,
  `order_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '订单编号',
  `create_time` datetime DEFAULT NULL COMMENT '提交时间',
  `member_username` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '用户帐号',
  `total_amount` decimal(10,2) DEFAULT NULL COMMENT '订单总金额',
  `pay_amount` decimal(10,2) DEFAULT NULL COMMENT '应付金额（实际支付金额）',
  `freight_amount` decimal(10,2) DEFAULT NULL COMMENT '运费金额',
  `promotion_amount` decimal(10,2) DEFAULT NULL COMMENT '促销优化金额（促销价、满减、阶梯价）',
  `integration_amount` decimal(10,2) DEFAULT NULL COMMENT '积分抵扣金额',
  `coupon_amount` decimal(10,2) DEFAULT NULL COMMENT '优惠券抵扣金额',
  `discount_amount` decimal(10,2) DEFAULT NULL COMMENT '管理员后台调整订单使用的折扣金额',
  `pay_type` int DEFAULT NULL COMMENT '支付方式：0->未支付；1->支付宝；2->微信',
  `source_type` int DEFAULT NULL COMMENT '订单来源：0->PC订单；1->app订单',
  `status` int DEFAULT NULL COMMENT '订单状态：0->待付款；1->待发货；2->已发货；3->已完成；4->已关闭；5->无效订单',
  `order_type` int DEFAULT NULL COMMENT '订单类型：0->正常订单；1->秒杀订单',
  `delivery_company` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '物流公司(配送方式)',
  `delivery_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '物流单号',
  `auto_confirm_day` int DEFAULT NULL COMMENT '自动确认时间（天）',
  `integration` int DEFAULT NULL COMMENT '可以获得的积分',
  `growth` int DEFAULT NULL COMMENT '可以活动的成长值',
  `promotion_info` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '活动信息',
  `bill_type` int DEFAULT NULL COMMENT '发票类型：0->不开发票；1->电子发票；2->纸质发票',
  `bill_header` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '发票抬头',
  `bill_content` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '发票内容',
  `bill_receiver_phone` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '收票人电话',
  `bill_receiver_email` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '收票人邮箱',
  `receiver_name` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci NOT NULL COMMENT '收货人姓名',
  `receiver_phone` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci NOT NULL COMMENT '收货人电话',
  `receiver_post_code` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '收货人邮编',
  `receiver_province` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '省份/直辖市',
  `receiver_city` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '城市',
  `receiver_region` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '区',
  `receiver_detail_address` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '详细地址',
  `note` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '订单备注',
  `confirm_status` int DEFAULT NULL COMMENT '确认收货状态：0->未确认；1->已确认',
  `delete_status` int NOT NULL DEFAULT '0' COMMENT '删除状态：0->未删除；1->已删除',
  `use_integration` int DEFAULT NULL COMMENT '下单时使用的积分',
  `payment_time` datetime DEFAULT NULL COMMENT '支付时间',
  `delivery_time` datetime DEFAULT NULL COMMENT '发货时间',
  `receive_time` datetime DEFAULT NULL COMMENT '确认收货时间',
  `comment_time` datetime DEFAULT NULL COMMENT '评价时间',
  `modify_time` datetime DEFAULT NULL COMMENT '修改时间',
  `qrcode` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '支付二维码地址',
  `gmt_create` datetime(6) DEFAULT CURRENT_TIMESTAMP(6),
  `gmt_modified` datetime(6) DEFAULT NULL,
  `version` int DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ordersn` (`order_sn`),
  KEY `idx_member_id` (`member_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of oms_order_5
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for oms_order_6
-- ----------------------------
DROP TABLE IF EXISTS `oms_order_6`;
CREATE TABLE `oms_order_6` (
  `id` bigint NOT NULL DEFAULT '0' COMMENT '订单id',
  `member_id` bigint NOT NULL,
  `coupon_id` bigint DEFAULT NULL,
  `order_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '订单编号',
  `create_time` datetime DEFAULT NULL COMMENT '提交时间',
  `member_username` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '用户帐号',
  `total_amount` decimal(10,2) DEFAULT NULL COMMENT '订单总金额',
  `pay_amount` decimal(10,2) DEFAULT NULL COMMENT '应付金额（实际支付金额）',
  `freight_amount` decimal(10,2) DEFAULT NULL COMMENT '运费金额',
  `promotion_amount` decimal(10,2) DEFAULT NULL COMMENT '促销优化金额（促销价、满减、阶梯价）',
  `integration_amount` decimal(10,2) DEFAULT NULL COMMENT '积分抵扣金额',
  `coupon_amount` decimal(10,2) DEFAULT NULL COMMENT '优惠券抵扣金额',
  `discount_amount` decimal(10,2) DEFAULT NULL COMMENT '管理员后台调整订单使用的折扣金额',
  `pay_type` int DEFAULT NULL COMMENT '支付方式：0->未支付；1->支付宝；2->微信',
  `source_type` int DEFAULT NULL COMMENT '订单来源：0->PC订单；1->app订单',
  `status` int DEFAULT NULL COMMENT '订单状态：0->待付款；1->待发货；2->已发货；3->已完成；4->已关闭；5->无效订单',
  `order_type` int DEFAULT NULL COMMENT '订单类型：0->正常订单；1->秒杀订单',
  `delivery_company` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '物流公司(配送方式)',
  `delivery_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '物流单号',
  `auto_confirm_day` int DEFAULT NULL COMMENT '自动确认时间（天）',
  `integration` int DEFAULT NULL COMMENT '可以获得的积分',
  `growth` int DEFAULT NULL COMMENT '可以活动的成长值',
  `promotion_info` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '活动信息',
  `bill_type` int DEFAULT NULL COMMENT '发票类型：0->不开发票；1->电子发票；2->纸质发票',
  `bill_header` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '发票抬头',
  `bill_content` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '发票内容',
  `bill_receiver_phone` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '收票人电话',
  `bill_receiver_email` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '收票人邮箱',
  `receiver_name` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci NOT NULL COMMENT '收货人姓名',
  `receiver_phone` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci NOT NULL COMMENT '收货人电话',
  `receiver_post_code` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '收货人邮编',
  `receiver_province` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '省份/直辖市',
  `receiver_city` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '城市',
  `receiver_region` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '区',
  `receiver_detail_address` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '详细地址',
  `note` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '订单备注',
  `confirm_status` int DEFAULT NULL COMMENT '确认收货状态：0->未确认；1->已确认',
  `delete_status` int NOT NULL DEFAULT '0' COMMENT '删除状态：0->未删除；1->已删除',
  `use_integration` int DEFAULT NULL COMMENT '下单时使用的积分',
  `payment_time` datetime DEFAULT NULL COMMENT '支付时间',
  `delivery_time` datetime DEFAULT NULL COMMENT '发货时间',
  `receive_time` datetime DEFAULT NULL COMMENT '确认收货时间',
  `comment_time` datetime DEFAULT NULL COMMENT '评价时间',
  `modify_time` datetime DEFAULT NULL COMMENT '修改时间',
  `qrcode` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '支付二维码地址',
  `gmt_create` datetime(6) DEFAULT CURRENT_TIMESTAMP(6),
  `gmt_modified` datetime(6) DEFAULT NULL,
  `version` int DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ordersn` (`order_sn`),
  KEY `idx_member_id` (`member_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of oms_order_6
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for oms_order_7
-- ----------------------------
DROP TABLE IF EXISTS `oms_order_7`;
CREATE TABLE `oms_order_7` (
  `id` bigint NOT NULL DEFAULT '0' COMMENT '订单id',
  `member_id` bigint NOT NULL,
  `coupon_id` bigint DEFAULT NULL,
  `order_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '订单编号',
  `create_time` datetime DEFAULT NULL COMMENT '提交时间',
  `member_username` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '用户帐号',
  `total_amount` decimal(10,2) DEFAULT NULL COMMENT '订单总金额',
  `pay_amount` decimal(10,2) DEFAULT NULL COMMENT '应付金额（实际支付金额）',
  `freight_amount` decimal(10,2) DEFAULT NULL COMMENT '运费金额',
  `promotion_amount` decimal(10,2) DEFAULT NULL COMMENT '促销优化金额（促销价、满减、阶梯价）',
  `integration_amount` decimal(10,2) DEFAULT NULL COMMENT '积分抵扣金额',
  `coupon_amount` decimal(10,2) DEFAULT NULL COMMENT '优惠券抵扣金额',
  `discount_amount` decimal(10,2) DEFAULT NULL COMMENT '管理员后台调整订单使用的折扣金额',
  `pay_type` int DEFAULT NULL COMMENT '支付方式：0->未支付；1->支付宝；2->微信',
  `source_type` int DEFAULT NULL COMMENT '订单来源：0->PC订单；1->app订单',
  `status` int DEFAULT NULL COMMENT '订单状态：0->待付款；1->待发货；2->已发货；3->已完成；4->已关闭；5->无效订单',
  `order_type` int DEFAULT NULL COMMENT '订单类型：0->正常订单；1->秒杀订单',
  `delivery_company` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '物流公司(配送方式)',
  `delivery_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '物流单号',
  `auto_confirm_day` int DEFAULT NULL COMMENT '自动确认时间（天）',
  `integration` int DEFAULT NULL COMMENT '可以获得的积分',
  `growth` int DEFAULT NULL COMMENT '可以活动的成长值',
  `promotion_info` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '活动信息',
  `bill_type` int DEFAULT NULL COMMENT '发票类型：0->不开发票；1->电子发票；2->纸质发票',
  `bill_header` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '发票抬头',
  `bill_content` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '发票内容',
  `bill_receiver_phone` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '收票人电话',
  `bill_receiver_email` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '收票人邮箱',
  `receiver_name` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci NOT NULL COMMENT '收货人姓名',
  `receiver_phone` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci NOT NULL COMMENT '收货人电话',
  `receiver_post_code` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '收货人邮编',
  `receiver_province` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '省份/直辖市',
  `receiver_city` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '城市',
  `receiver_region` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '区',
  `receiver_detail_address` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '详细地址',
  `note` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '订单备注',
  `confirm_status` int DEFAULT NULL COMMENT '确认收货状态：0->未确认；1->已确认',
  `delete_status` int NOT NULL DEFAULT '0' COMMENT '删除状态：0->未删除；1->已删除',
  `use_integration` int DEFAULT NULL COMMENT '下单时使用的积分',
  `payment_time` datetime DEFAULT NULL COMMENT '支付时间',
  `delivery_time` datetime DEFAULT NULL COMMENT '发货时间',
  `receive_time` datetime DEFAULT NULL COMMENT '确认收货时间',
  `comment_time` datetime DEFAULT NULL COMMENT '评价时间',
  `modify_time` datetime DEFAULT NULL COMMENT '修改时间',
  `qrcode` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '支付二维码地址',
  `gmt_create` datetime(6) DEFAULT CURRENT_TIMESTAMP(6),
  `gmt_modified` datetime(6) DEFAULT NULL,
  `version` int DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ordersn` (`order_sn`),
  KEY `idx_member_id` (`member_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of oms_order_7
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for oms_order_8
-- ----------------------------
DROP TABLE IF EXISTS `oms_order_8`;
CREATE TABLE `oms_order_8` (
  `id` bigint NOT NULL DEFAULT '0' COMMENT '订单id',
  `member_id` bigint NOT NULL,
  `coupon_id` bigint DEFAULT NULL,
  `order_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '订单编号',
  `create_time` datetime DEFAULT NULL COMMENT '提交时间',
  `member_username` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '用户帐号',
  `total_amount` decimal(10,2) DEFAULT NULL COMMENT '订单总金额',
  `pay_amount` decimal(10,2) DEFAULT NULL COMMENT '应付金额（实际支付金额）',
  `freight_amount` decimal(10,2) DEFAULT NULL COMMENT '运费金额',
  `promotion_amount` decimal(10,2) DEFAULT NULL COMMENT '促销优化金额（促销价、满减、阶梯价）',
  `integration_amount` decimal(10,2) DEFAULT NULL COMMENT '积分抵扣金额',
  `coupon_amount` decimal(10,2) DEFAULT NULL COMMENT '优惠券抵扣金额',
  `discount_amount` decimal(10,2) DEFAULT NULL COMMENT '管理员后台调整订单使用的折扣金额',
  `pay_type` int DEFAULT NULL COMMENT '支付方式：0->未支付；1->支付宝；2->微信',
  `source_type` int DEFAULT NULL COMMENT '订单来源：0->PC订单；1->app订单',
  `status` int DEFAULT NULL COMMENT '订单状态：0->待付款；1->待发货；2->已发货；3->已完成；4->已关闭；5->无效订单',
  `order_type` int DEFAULT NULL COMMENT '订单类型：0->正常订单；1->秒杀订单',
  `delivery_company` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '物流公司(配送方式)',
  `delivery_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '物流单号',
  `auto_confirm_day` int DEFAULT NULL COMMENT '自动确认时间（天）',
  `integration` int DEFAULT NULL COMMENT '可以获得的积分',
  `growth` int DEFAULT NULL COMMENT '可以活动的成长值',
  `promotion_info` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '活动信息',
  `bill_type` int DEFAULT NULL COMMENT '发票类型：0->不开发票；1->电子发票；2->纸质发票',
  `bill_header` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '发票抬头',
  `bill_content` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '发票内容',
  `bill_receiver_phone` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '收票人电话',
  `bill_receiver_email` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '收票人邮箱',
  `receiver_name` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci NOT NULL COMMENT '收货人姓名',
  `receiver_phone` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci NOT NULL COMMENT '收货人电话',
  `receiver_post_code` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '收货人邮编',
  `receiver_province` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '省份/直辖市',
  `receiver_city` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '城市',
  `receiver_region` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '区',
  `receiver_detail_address` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '详细地址',
  `note` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '订单备注',
  `confirm_status` int DEFAULT NULL COMMENT '确认收货状态：0->未确认；1->已确认',
  `delete_status` int NOT NULL DEFAULT '0' COMMENT '删除状态：0->未删除；1->已删除',
  `use_integration` int DEFAULT NULL COMMENT '下单时使用的积分',
  `payment_time` datetime DEFAULT NULL COMMENT '支付时间',
  `delivery_time` datetime DEFAULT NULL COMMENT '发货时间',
  `receive_time` datetime DEFAULT NULL COMMENT '确认收货时间',
  `comment_time` datetime DEFAULT NULL COMMENT '评价时间',
  `modify_time` datetime DEFAULT NULL COMMENT '修改时间',
  `qrcode` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '支付二维码地址',
  `gmt_create` datetime(6) DEFAULT CURRENT_TIMESTAMP(6),
  `gmt_modified` datetime(6) DEFAULT NULL,
  `version` int DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ordersn` (`order_sn`),
  KEY `idx_member_id` (`member_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of oms_order_8
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for oms_order_9
-- ----------------------------
DROP TABLE IF EXISTS `oms_order_9`;
CREATE TABLE `oms_order_9` (
  `id` bigint NOT NULL DEFAULT '0' COMMENT '订单id',
  `member_id` bigint NOT NULL,
  `coupon_id` bigint DEFAULT NULL,
  `order_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '订单编号',
  `create_time` datetime DEFAULT NULL COMMENT '提交时间',
  `member_username` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '用户帐号',
  `total_amount` decimal(10,2) DEFAULT NULL COMMENT '订单总金额',
  `pay_amount` decimal(10,2) DEFAULT NULL COMMENT '应付金额（实际支付金额）',
  `freight_amount` decimal(10,2) DEFAULT NULL COMMENT '运费金额',
  `promotion_amount` decimal(10,2) DEFAULT NULL COMMENT '促销优化金额（促销价、满减、阶梯价）',
  `integration_amount` decimal(10,2) DEFAULT NULL COMMENT '积分抵扣金额',
  `coupon_amount` decimal(10,2) DEFAULT NULL COMMENT '优惠券抵扣金额',
  `discount_amount` decimal(10,2) DEFAULT NULL COMMENT '管理员后台调整订单使用的折扣金额',
  `pay_type` int DEFAULT NULL COMMENT '支付方式：0->未支付；1->支付宝；2->微信',
  `source_type` int DEFAULT NULL COMMENT '订单来源：0->PC订单；1->app订单',
  `status` int DEFAULT NULL COMMENT '订单状态：0->待付款；1->待发货；2->已发货；3->已完成；4->已关闭；5->无效订单',
  `order_type` int DEFAULT NULL COMMENT '订单类型：0->正常订单；1->秒杀订单',
  `delivery_company` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '物流公司(配送方式)',
  `delivery_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '物流单号',
  `auto_confirm_day` int DEFAULT NULL COMMENT '自动确认时间（天）',
  `integration` int DEFAULT NULL COMMENT '可以获得的积分',
  `growth` int DEFAULT NULL COMMENT '可以活动的成长值',
  `promotion_info` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '活动信息',
  `bill_type` int DEFAULT NULL COMMENT '发票类型：0->不开发票；1->电子发票；2->纸质发票',
  `bill_header` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '发票抬头',
  `bill_content` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '发票内容',
  `bill_receiver_phone` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '收票人电话',
  `bill_receiver_email` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '收票人邮箱',
  `receiver_name` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci NOT NULL COMMENT '收货人姓名',
  `receiver_phone` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci NOT NULL COMMENT '收货人电话',
  `receiver_post_code` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '收货人邮编',
  `receiver_province` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '省份/直辖市',
  `receiver_city` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '城市',
  `receiver_region` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '区',
  `receiver_detail_address` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '详细地址',
  `note` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '订单备注',
  `confirm_status` int DEFAULT NULL COMMENT '确认收货状态：0->未确认；1->已确认',
  `delete_status` int NOT NULL DEFAULT '0' COMMENT '删除状态：0->未删除；1->已删除',
  `use_integration` int DEFAULT NULL COMMENT '下单时使用的积分',
  `payment_time` datetime DEFAULT NULL COMMENT '支付时间',
  `delivery_time` datetime DEFAULT NULL COMMENT '发货时间',
  `receive_time` datetime DEFAULT NULL COMMENT '确认收货时间',
  `comment_time` datetime DEFAULT NULL COMMENT '评价时间',
  `modify_time` datetime DEFAULT NULL COMMENT '修改时间',
  `qrcode` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '支付二维码地址',
  `gmt_create` datetime(6) DEFAULT CURRENT_TIMESTAMP(6),
  `gmt_modified` datetime(6) DEFAULT NULL,
  `version` int DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ordersn` (`order_sn`),
  KEY `idx_member_id` (`member_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of oms_order_9
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for oms_order_item_0
-- ----------------------------
DROP TABLE IF EXISTS `oms_order_item_0`;
CREATE TABLE `oms_order_item_0` (
  `id` bigint NOT NULL DEFAULT '0',
  `order_id` bigint DEFAULT NULL COMMENT '订单id',
  `order_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '订单编号',
  `product_id` bigint DEFAULT NULL,
  `product_pic` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_name` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_brand` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_price` decimal(10,2) DEFAULT NULL COMMENT '销售价格',
  `product_quantity` int DEFAULT NULL COMMENT '购买数量',
  `product_sku_id` bigint DEFAULT NULL COMMENT '商品sku编号',
  `product_sku_code` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品sku条码',
  `product_category_id` bigint DEFAULT NULL COMMENT '商品分类id',
  `sp1` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品的销售属性',
  `sp2` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `sp3` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `promotion_name` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品促销名称',
  `promotion_amount` decimal(10,2) DEFAULT NULL COMMENT '商品促销分解金额',
  `coupon_amount` decimal(10,2) DEFAULT NULL COMMENT '优惠券优惠分解金额',
  `integration_amount` decimal(10,2) DEFAULT NULL COMMENT '积分优惠分解金额',
  `real_amount` decimal(10,2) DEFAULT NULL COMMENT '该商品经过优惠后的分解金额',
  `gift_integration` int DEFAULT '0',
  `gift_growth` int DEFAULT '0',
  `product_attr` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品销售属性:[{"key":"颜色","value":"颜色"},{"key":"容量","value":"4G"}]',
  `gmt_create` datetime(6) DEFAULT CURRENT_TIMESTAMP(6),
  `gmt_modified` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_order_id` (`order_id`),
  KEY `idx_order_sn` (`order_sn`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of oms_order_item_0
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for oms_order_item_1
-- ----------------------------
DROP TABLE IF EXISTS `oms_order_item_1`;
CREATE TABLE `oms_order_item_1` (
  `id` bigint NOT NULL DEFAULT '0',
  `order_id` bigint DEFAULT NULL COMMENT '订单id',
  `order_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '订单编号',
  `product_id` bigint DEFAULT NULL,
  `product_pic` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_name` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_brand` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_price` decimal(10,2) DEFAULT NULL COMMENT '销售价格',
  `product_quantity` int DEFAULT NULL COMMENT '购买数量',
  `product_sku_id` bigint DEFAULT NULL COMMENT '商品sku编号',
  `product_sku_code` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品sku条码',
  `product_category_id` bigint DEFAULT NULL COMMENT '商品分类id',
  `sp1` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品的销售属性',
  `sp2` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `sp3` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `promotion_name` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品促销名称',
  `promotion_amount` decimal(10,2) DEFAULT NULL COMMENT '商品促销分解金额',
  `coupon_amount` decimal(10,2) DEFAULT NULL COMMENT '优惠券优惠分解金额',
  `integration_amount` decimal(10,2) DEFAULT NULL COMMENT '积分优惠分解金额',
  `real_amount` decimal(10,2) DEFAULT NULL COMMENT '该商品经过优惠后的分解金额',
  `gift_integration` int DEFAULT '0',
  `gift_growth` int DEFAULT '0',
  `product_attr` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品销售属性:[{"key":"颜色","value":"颜色"},{"key":"容量","value":"4G"}]',
  `gmt_create` datetime(6) DEFAULT CURRENT_TIMESTAMP(6),
  `gmt_modified` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_order_id` (`order_id`),
  KEY `idx_order_sn` (`order_sn`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of oms_order_item_1
-- ----------------------------
BEGIN;
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (89002, 10100101, '10100101', 38, 'http://tuling-mall.oss-cn-shenzhen.aliyuncs.com/tulingmall/images/20200311/78_78_AB008D014A661DF6E52E184269C6A8A453885402D7D6FC0Bmp.png', '华为nova6se 手机 绮境森林 全网通（8G+128G)', NULL, NULL, 2199.00, 2, 122, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2199.00, 0, 0, NULL, '2022-10-11 15:32:51.415271', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (89003, 10100101, '10100101', 40, 'http://tuling-mall.oss-cn-shenzhen.aliyuncs.com/tulingmall/images/20200311/19e846e727dff337.jpg', '七匹狼短袖T恤男纯棉舒适春夏修身运动休闲短袖三条装 圆领3条装', NULL, NULL, 139.00, 12, 132, NULL, NULL, NULL, NULL, NULL, '满减优惠：满200.00元，减50.00元', 4.00, 0.00, 0.00, 139.00, 0, 0, NULL, '2022-10-11 15:32:51.415271', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (89023, 10101201, '10101201', 26, 'http://macro-oss.oss-cn-shenzhen.aliyuncs.com/mall/images/20180607/5ac1bf58Ndefaac16.jpg', '小米 11 ', NULL, NULL, 3788.00, 1, 143, NULL, NULL, NULL, NULL, NULL, '单品促销', NULL, 0.00, 0.00, 3788.00, 0, 0, NULL, '2022-10-11 16:30:55.182528', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (93044, 10508301, '10508301', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2022-10-18 13:30:15.837037', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (95001, 10700801, '10700801', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2022-10-18 14:22:15.177941', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (95002, 10700901, '10700901', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2022-10-18 14:22:57.549436', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (95004, 10701201, '10701201', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2022-10-18 14:51:38.362566', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (95010, 10702001, '10702001', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2022-10-18 15:15:45.836068', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (95012, 10702201, '10702201', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2022-10-18 15:19:10.085604', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (95013, 10702301, '10702301', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2022-10-18 15:20:07.972948', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (97000, 10900201, '10900201', 40, 'http://tuling-mall.oss-cn-shenzhen.aliyuncs.com/tulingmall/images/20200311/19e846e727dff337.jpg', '七匹狼短袖T恤男纯棉舒适春夏修身运动休闲短袖三条装 圆领3条装', NULL, NULL, 139.00, 13, 132, NULL, NULL, NULL, NULL, NULL, '满减优惠：满200.00元，减50.00元', 4.00, 0.00, 0.00, 139.00, 0, 0, NULL, '2022-11-02 18:44:23.168146', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (97001, 10900301, '10900301', 38, 'http://tuling-mall.oss-cn-shenzhen.aliyuncs.com/tulingmall/images/20200311/78_78_AB008D014A661DF6E52E184269C6A8A453885402D7D6FC0Bmp.png', '华为nova6se 手机 绮境森林 全网通（8G+128G)', NULL, NULL, 2199.00, 2, 122, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2199.00, 0, 0, NULL, '2022-11-02 21:11:15.786515', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (97002, 10900401, '10900401', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2022-11-02 21:17:58.408767', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (99000, 11100001, '11100001', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2022-11-03 16:50:18.424659', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (101003, 11300301, '11300301', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2022-11-04 16:57:38.078209', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (103001, 11500101, '11500101', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2022-11-04 21:03:41.014772', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (103003, 11500301, '11500301', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2022-11-04 21:48:34.773591', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (105000, 11700001, '11700001', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2022-11-09 15:24:16.826562', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (105001, 11700101, '11700101', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2022-11-09 15:33:08.122907', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (105002, 11700201, '11700201', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2022-11-09 15:34:02.266123', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (105003, 11700301, '11700301', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2022-11-09 15:37:16.498173', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (105004, 11700401, '11700401', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2022-11-09 15:38:22.702340', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (105005, 11700501, '11700501', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2022-11-09 15:41:44.707432', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (105006, 11700601, '11700601', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2022-11-09 15:43:04.158454', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (105007, 11700701, '11700701', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2022-11-09 15:44:24.782649', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (105008, 11700801, '11700801', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2022-11-09 15:45:04.946681', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (105009, 11700901, '11700901', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2022-11-09 15:47:06.336812', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (105010, 11701001, '11701001', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2022-11-09 15:51:33.542493', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (107000, 11900001, '11900001', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2022-11-10 09:16:53.300993', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (107001, 11900101, '11900101', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2022-11-10 09:19:54.499577', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (107002, 11900201, '11900201', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2022-11-10 09:27:16.932720', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (113000, 12500101, '12500101', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2022-11-15 10:55:52.218454', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (113001, 12500201, '12500201', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2022-11-15 10:58:50.247031', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (113002, 12500301, '12500301', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2022-11-15 10:59:31.116969', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (113003, 12500401, '12500401', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2022-11-15 11:01:04.372253', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (113004, 12500501, '12500501', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2022-11-15 11:01:09.384212', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (113005, 12500601, '12500601', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2022-11-15 11:01:14.148362', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (113006, 12500701, '12500701', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2022-11-15 11:04:44.745140', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (115000, 12700001, '12700001', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2022-11-15 11:14:59.646266', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (115002, 12700201, '12700201', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2022-11-15 11:18:52.826616', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (115004, 12700401, '12700401', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2022-11-15 11:23:39.908751', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (115005, 12700501, '12700501', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2022-11-15 11:25:21.914549', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (115006, 12700601, '12700601', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2022-11-15 11:26:30.776136', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (115007, 12700701, '12700701', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2022-11-15 11:31:04.496856', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (115008, 12701001, '12701001', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2022-11-15 16:43:13.256995', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (115009, 12701101, '12701101', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2022-11-15 16:43:55.472631', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (115010, 12701401, '12701401', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2022-11-15 16:45:28.003594', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (115011, 12701501, '12701501', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2022-11-15 17:00:03.849838', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (115012, 12701601, '12701601', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2022-11-15 17:00:31.258741', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (115014, 12701801, '12701801', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2022-11-15 17:37:34.633856', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (115015, 12701901, '12701901', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2022-11-15 17:38:05.662950', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (115016, 12702001, '12702001', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2022-11-15 17:38:36.525867', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (115017, 12702101, '12702101', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2022-11-15 17:48:00.707361', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (115018, 12702201, '12702201', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2022-11-15 18:05:04.695592', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (115019, 12702301, '12702301', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2022-11-15 18:07:04.772842', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (189005, 16901801, '16901801', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2022-11-16 13:39:41.539393', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (189010, 16902301, '16902301', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2022-11-16 13:39:46.930176', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (189013, 16902601, '16902601', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2022-11-16 13:39:52.386972', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (189017, 16903001, '16903001', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2022-11-16 13:41:40.845300', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (189019, 16903201, '16903201', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2022-11-16 13:41:51.547424', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (189020, 16903301, '16903301', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2022-11-16 13:42:34.259233', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (189023, 16903601, '16903601', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2022-11-16 13:42:43.319438', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (189031, 16904401, '16904401', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2022-11-16 13:43:09.131516', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (189032, 16904501, '16904501', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2022-11-16 13:46:25.286356', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (189033, 16904601, '16904601', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2022-11-16 13:46:48.062904', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (189034, 16904701, '16904701', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2022-11-16 13:46:51.808979', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (189035, 16904801, '16904801', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2022-11-16 13:47:15.689562', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (189037, 16905001, '16905001', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2022-11-16 13:47:34.253794', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (189038, 16905101, '16905101', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2022-11-16 13:47:48.042927', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (189044, 16905701, '16905701', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2022-11-16 13:47:54.079716', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (189048, 16906101, '16906101', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2022-11-16 13:48:27.846861', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (189054, 16906701, '16906701', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2022-11-16 13:48:32.540030', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (189056, 16906901, '16906901', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2022-11-16 13:48:38.915468', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (189059, 16907201, '16907201', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2022-11-16 13:48:42.903435', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (189063, 16907601, '16907601', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2022-11-16 13:49:33.996478', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (189066, 16907901, '16907901', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2022-11-16 13:49:39.550620', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (189075, 16908801, '16908801', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2022-11-16 13:49:48.912919', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (189081, 16909401, '16909401', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2022-11-16 13:49:53.469203', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (189083, 16909601, '16909601', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2022-11-16 14:09:32.390555', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (189084, 16909701, '16909701', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2022-11-16 14:09:39.352046', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (189085, 16909801, '16909801', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2022-11-16 14:10:18.094154', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (189086, 16909901, '16909901', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2022-11-16 14:10:22.333469', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (189087, 16910001, '16910001', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2022-11-16 14:10:24.098753', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (189088, 16910101, '16910101', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2022-11-16 14:11:35.425802', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (189089, 16910201, '16910201', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2022-11-16 14:12:03.801970', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (191000, 17100101, '17100101', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2022-11-16 14:54:28.286380', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (193000, 17300001, '17300001', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2022-11-16 22:09:58.395389', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (193001, 17300101, '17300101', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2022-11-16 22:10:38.836990', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (209000, 18900001, '18900001', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2023-05-28 13:46:55.591119', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (209001, 18900101, '18900101', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2023-05-28 13:48:21.692631', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (209003, 18900301, '18900301', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2023-05-28 13:53:57.368876', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (209004, 18900401, '18900401', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2023-05-28 13:54:16.446419', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (209005, 18900501, '18900501', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2023-05-28 14:01:05.418700', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (209006, 18900601, '18900601', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2023-05-28 14:03:26.937238', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (209007, 18900701, '18900701', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2023-05-28 14:04:36.479363', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (209010, 18901301, '18901301', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2023-05-28 14:14:24.069084', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (211000, 19100001, '19100001', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2023-05-28 14:22:45.176950', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (211005, 19101101, '19101101', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2023-05-28 14:32:24.515345', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (211006, 19101201, '19101201', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2023-05-28 14:33:08.718061', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (213000, 19300001, '19300001', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2023-05-29 14:16:15.155976', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (215000, 19500001, '19500001', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2023-05-29 14:40:12.880042', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (217002, 19700201, '19700201', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2023-05-29 16:05:42.726427', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (219000, 19900001, '19900001', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2023-05-31 10:54:19.168039', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (219001, 19900101, '19900101', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2023-05-31 10:54:27.885228', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (219002, 19900201, '19900201', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2023-05-31 10:54:36.817049', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (219003, 19900301, '19900301', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2023-05-31 10:54:43.677742', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (219004, 19900401, '19900401', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2023-05-31 10:57:16.811157', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (219005, 19900501, '19900501', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2023-05-31 10:57:22.805933', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (219006, 19900601, '19900601', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2023-05-31 10:57:28.632228', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (219007, 19900701, '19900701', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2023-05-31 10:57:41.704056', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (219008, 19900801, '19900801', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2023-05-31 11:13:29.947885', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (219009, 19900901, '19900901', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2023-05-31 11:21:08.068421', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (219010, 19901001, '19901001', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2023-05-31 11:21:57.258018', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (219011, 19901101, '19901101', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2023-05-31 11:22:15.057472', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (219012, 19901201, '19901201', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2023-05-31 11:22:19.997666', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (219013, 19901301, '19901301', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2023-05-31 11:27:55.192662', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (219014, 19901401, '19901401', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2023-05-31 11:27:57.762541', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (219015, 19901501, '19901501', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2023-05-31 11:28:01.302624', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (219028, 19903301, '19903301', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2023-05-31 11:28:32.418241', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (219029, 19903401, '19903401', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2023-05-31 11:28:49.174119', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (219030, 19903501, '19903501', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2023-05-31 11:29:32.351859', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (219031, 19903601, '19903601', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2023-05-31 11:29:35.688494', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (219032, 19903701, '19903701', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2023-05-31 11:29:35.909497', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (219033, 19903801, '19903801', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2023-05-31 11:29:38.143390', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (219048, 19905501, '19905501', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2023-05-31 11:30:04.908942', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (219049, 19905601, '19905601', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2023-05-31 11:30:09.701201', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (219060, 19906801, '19906801', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2023-05-31 11:32:45.121760', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (219061, 19906701, '19906701', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2023-05-31 11:32:44.346066', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (219062, 19906901, '19906901', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2023-05-31 11:32:44.346060', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (219063, 19907001, '19907001', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2023-05-31 11:32:44.346162', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (219064, 19907101, '19907101', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2023-05-31 11:32:45.879929', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (219065, 19907201, '19907201', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2023-05-31 11:32:46.641624', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (219066, 19907301, '19907301', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2023-05-31 11:32:50.403446', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (219067, 19907401, '19907401', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2023-05-31 11:32:49.608556', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (219068, 19907501, '19907501', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2023-05-31 11:32:49.608630', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (219069, 19907601, '19907601', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2023-05-31 11:32:49.608960', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (219070, 19907701, '19907701', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2023-05-31 11:32:51.583190', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (219071, 19907801, '19907801', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2023-05-31 11:32:51.940017', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (219072, 19907901, '19907901', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2023-05-31 11:32:53.950415', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (219073, 19908001, '19908001', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2023-05-31 11:32:53.279195', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (219074, 19908101, '19908101', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2023-05-31 11:32:52.494033', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (219077, 19909901, '19909901', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2023-05-31 11:32:56.784945', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (219081, 19910201, '19910201', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2023-05-31 11:32:57.911195', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (219096, 19912801, '19912801', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2023-05-31 11:34:58.364707', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (219097, 19912901, '19912901', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2023-05-31 11:47:06.043573', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (225001, 20500101, '20500101', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2023-06-20 19:13:49.769223', NULL);
INSERT INTO `oms_order_item_1` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (225002, 20500201, '20500201', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2023-06-20 19:15:09.174324', NULL);
COMMIT;

-- ----------------------------
-- Table structure for oms_order_item_10
-- ----------------------------
DROP TABLE IF EXISTS `oms_order_item_10`;
CREATE TABLE `oms_order_item_10` (
  `id` bigint NOT NULL DEFAULT '0',
  `order_id` bigint DEFAULT NULL COMMENT '订单id',
  `order_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '订单编号',
  `product_id` bigint DEFAULT NULL,
  `product_pic` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_name` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_brand` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_price` decimal(10,2) DEFAULT NULL COMMENT '销售价格',
  `product_quantity` int DEFAULT NULL COMMENT '购买数量',
  `product_sku_id` bigint DEFAULT NULL COMMENT '商品sku编号',
  `product_sku_code` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品sku条码',
  `product_category_id` bigint DEFAULT NULL COMMENT '商品分类id',
  `sp1` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品的销售属性',
  `sp2` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `sp3` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `promotion_name` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品促销名称',
  `promotion_amount` decimal(10,2) DEFAULT NULL COMMENT '商品促销分解金额',
  `coupon_amount` decimal(10,2) DEFAULT NULL COMMENT '优惠券优惠分解金额',
  `integration_amount` decimal(10,2) DEFAULT NULL COMMENT '积分优惠分解金额',
  `real_amount` decimal(10,2) DEFAULT NULL COMMENT '该商品经过优惠后的分解金额',
  `gift_integration` int DEFAULT '0',
  `gift_growth` int DEFAULT '0',
  `product_attr` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品销售属性:[{"key":"颜色","value":"颜色"},{"key":"容量","value":"4G"}]',
  `gmt_create` datetime(6) DEFAULT CURRENT_TIMESTAMP(6),
  `gmt_modified` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_order_id` (`order_id`),
  KEY `idx_order_sn` (`order_sn`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of oms_order_item_10
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for oms_order_item_11
-- ----------------------------
DROP TABLE IF EXISTS `oms_order_item_11`;
CREATE TABLE `oms_order_item_11` (
  `id` bigint NOT NULL DEFAULT '0',
  `order_id` bigint DEFAULT NULL COMMENT '订单id',
  `order_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '订单编号',
  `product_id` bigint DEFAULT NULL,
  `product_pic` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_name` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_brand` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_price` decimal(10,2) DEFAULT NULL COMMENT '销售价格',
  `product_quantity` int DEFAULT NULL COMMENT '购买数量',
  `product_sku_id` bigint DEFAULT NULL COMMENT '商品sku编号',
  `product_sku_code` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品sku条码',
  `product_category_id` bigint DEFAULT NULL COMMENT '商品分类id',
  `sp1` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品的销售属性',
  `sp2` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `sp3` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `promotion_name` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品促销名称',
  `promotion_amount` decimal(10,2) DEFAULT NULL COMMENT '商品促销分解金额',
  `coupon_amount` decimal(10,2) DEFAULT NULL COMMENT '优惠券优惠分解金额',
  `integration_amount` decimal(10,2) DEFAULT NULL COMMENT '积分优惠分解金额',
  `real_amount` decimal(10,2) DEFAULT NULL COMMENT '该商品经过优惠后的分解金额',
  `gift_integration` int DEFAULT '0',
  `gift_growth` int DEFAULT '0',
  `product_attr` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品销售属性:[{"key":"颜色","value":"颜色"},{"key":"容量","value":"4G"}]',
  `gmt_create` datetime(6) DEFAULT CURRENT_TIMESTAMP(6),
  `gmt_modified` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_order_id` (`order_id`),
  KEY `idx_order_sn` (`order_sn`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of oms_order_item_11
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for oms_order_item_12
-- ----------------------------
DROP TABLE IF EXISTS `oms_order_item_12`;
CREATE TABLE `oms_order_item_12` (
  `id` bigint NOT NULL DEFAULT '0',
  `order_id` bigint DEFAULT NULL COMMENT '订单id',
  `order_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '订单编号',
  `product_id` bigint DEFAULT NULL,
  `product_pic` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_name` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_brand` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_price` decimal(10,2) DEFAULT NULL COMMENT '销售价格',
  `product_quantity` int DEFAULT NULL COMMENT '购买数量',
  `product_sku_id` bigint DEFAULT NULL COMMENT '商品sku编号',
  `product_sku_code` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品sku条码',
  `product_category_id` bigint DEFAULT NULL COMMENT '商品分类id',
  `sp1` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品的销售属性',
  `sp2` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `sp3` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `promotion_name` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品促销名称',
  `promotion_amount` decimal(10,2) DEFAULT NULL COMMENT '商品促销分解金额',
  `coupon_amount` decimal(10,2) DEFAULT NULL COMMENT '优惠券优惠分解金额',
  `integration_amount` decimal(10,2) DEFAULT NULL COMMENT '积分优惠分解金额',
  `real_amount` decimal(10,2) DEFAULT NULL COMMENT '该商品经过优惠后的分解金额',
  `gift_integration` int DEFAULT '0',
  `gift_growth` int DEFAULT '0',
  `product_attr` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品销售属性:[{"key":"颜色","value":"颜色"},{"key":"容量","value":"4G"}]',
  `gmt_create` datetime(6) DEFAULT CURRENT_TIMESTAMP(6),
  `gmt_modified` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_order_id` (`order_id`),
  KEY `idx_order_sn` (`order_sn`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of oms_order_item_12
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for oms_order_item_13
-- ----------------------------
DROP TABLE IF EXISTS `oms_order_item_13`;
CREATE TABLE `oms_order_item_13` (
  `id` bigint NOT NULL DEFAULT '0',
  `order_id` bigint DEFAULT NULL COMMENT '订单id',
  `order_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '订单编号',
  `product_id` bigint DEFAULT NULL,
  `product_pic` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_name` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_brand` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_price` decimal(10,2) DEFAULT NULL COMMENT '销售价格',
  `product_quantity` int DEFAULT NULL COMMENT '购买数量',
  `product_sku_id` bigint DEFAULT NULL COMMENT '商品sku编号',
  `product_sku_code` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品sku条码',
  `product_category_id` bigint DEFAULT NULL COMMENT '商品分类id',
  `sp1` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品的销售属性',
  `sp2` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `sp3` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `promotion_name` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品促销名称',
  `promotion_amount` decimal(10,2) DEFAULT NULL COMMENT '商品促销分解金额',
  `coupon_amount` decimal(10,2) DEFAULT NULL COMMENT '优惠券优惠分解金额',
  `integration_amount` decimal(10,2) DEFAULT NULL COMMENT '积分优惠分解金额',
  `real_amount` decimal(10,2) DEFAULT NULL COMMENT '该商品经过优惠后的分解金额',
  `gift_integration` int DEFAULT '0',
  `gift_growth` int DEFAULT '0',
  `product_attr` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品销售属性:[{"key":"颜色","value":"颜色"},{"key":"容量","value":"4G"}]',
  `gmt_create` datetime(6) DEFAULT CURRENT_TIMESTAMP(6),
  `gmt_modified` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_order_id` (`order_id`),
  KEY `idx_order_sn` (`order_sn`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of oms_order_item_13
-- ----------------------------
BEGIN;
INSERT INTO `oms_order_item_13` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (7000, 302145, '302145', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2022-07-23 16:10:23.698912', NULL);
INSERT INTO `oms_order_item_13` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (9001, 500145, '500145', 30, 'http://tuling-mall.oss-cn-shenzhen.aliyuncs.com/tulingmall/images/20200309/面试宝典图 .jpg', 'HLA海澜之家简约动物印花短袖T恤', NULL, NULL, 111.00, 1, 112, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 111.00, 0, 0, NULL, '2022-07-26 17:34:30.767960', NULL);
INSERT INTO `oms_order_item_13` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (9002, 500245, '500245', 30, 'http://tuling-mall.oss-cn-shenzhen.aliyuncs.com/tulingmall/images/20200309/面试宝典图 .jpg', 'HLA海澜之家简约动物印花短袖T恤', NULL, NULL, 111.00, 1, 112, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 111.00, 0, 0, NULL, '2022-07-26 17:36:59.533195', NULL);
INSERT INTO `oms_order_item_13` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (9003, 500345, '500345', 30, 'http://tuling-mall.oss-cn-shenzhen.aliyuncs.com/tulingmall/images/20200309/面试宝典图 .jpg', 'HLA海澜之家简约动物印花短袖T恤', NULL, NULL, 111.00, 1, 112, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 111.00, 0, 0, NULL, '2022-07-26 17:51:53.530037', NULL);
INSERT INTO `oms_order_item_13` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (9004, 500445, '500445', 30, 'http://tuling-mall.oss-cn-shenzhen.aliyuncs.com/tulingmall/images/20200309/面试宝典图 .jpg', 'HLA海澜之家简约动物印花短袖T恤', NULL, NULL, 111.00, 1, 112, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 111.00, 0, 0, NULL, '2022-07-26 17:56:25.972931', NULL);
INSERT INTO `oms_order_item_13` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (9005, 500545, '500545', 30, 'http://tuling-mall.oss-cn-shenzhen.aliyuncs.com/tulingmall/images/20200309/面试宝典图 .jpg', 'HLA海澜之家简约动物印花短袖T恤', NULL, NULL, 111.00, 1, 112, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 111.00, 0, 0, NULL, '2022-07-26 17:57:48.565267', NULL);
INSERT INTO `oms_order_item_13` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (9006, 500645, '500645', 30, 'http://tuling-mall.oss-cn-shenzhen.aliyuncs.com/tulingmall/images/20200309/面试宝典图 .jpg', 'HLA海澜之家简约动物印花短袖T恤', NULL, NULL, 111.00, 1, 112, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 111.00, 0, 0, NULL, '2022-07-26 18:08:48.688037', NULL);
INSERT INTO `oms_order_item_13` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (9007, 500745, '500745', 30, 'http://tuling-mall.oss-cn-shenzhen.aliyuncs.com/tulingmall/images/20200309/面试宝典图 .jpg', 'HLA海澜之家简约动物印花短袖T恤', NULL, NULL, 111.00, 1, 112, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 111.00, 0, 0, NULL, '2022-07-26 18:09:47.089195', NULL);
INSERT INTO `oms_order_item_13` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (11000, 700045, '700045', 30, 'http://tuling-mall.oss-cn-shenzhen.aliyuncs.com/tulingmall/images/20200309/面试宝典图 .jpg', 'HLA海澜之家简约动物印花短袖T恤', NULL, NULL, 111.00, 1, 112, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 111.00, 0, 0, NULL, '2022-07-27 15:23:50.124813', NULL);
INSERT INTO `oms_order_item_13` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (13000, 900045, '900045', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 2, 98, NULL, NULL, NULL, NULL, NULL, '打折优惠：满2件，打8.00折', 539.80, 0.00, 0.00, 2699.00, 0, 0, NULL, '2022-09-14 14:06:04.254932', NULL);
INSERT INTO `oms_order_item_13` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (13001, 900145, '900145', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 2, 98, NULL, NULL, NULL, NULL, NULL, '打折优惠：满2件，打8.00折', 539.80, 0.00, 0.00, 2699.00, 0, 0, NULL, '2022-09-14 14:06:32.568144', NULL);
INSERT INTO `oms_order_item_13` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (13002, 1100045, '1100045', 30, 'http://tuling-mall.oss-cn-shenzhen.aliyuncs.com/tulingmall/images/20200309/面试宝典图 .jpg', 'HLA海澜之家简约动物印花短袖T恤', NULL, NULL, 111.00, 1, 112, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 111.00, 0, 0, NULL, '2022-09-14 15:07:54.249002', NULL);
INSERT INTO `oms_order_item_13` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (13003, 1100145, '1100145', 30, 'http://tuling-mall.oss-cn-shenzhen.aliyuncs.com/tulingmall/images/20200309/面试宝典图 .jpg', 'HLA海澜之家简约动物印花短袖T恤', NULL, NULL, 111.00, 1, 112, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 111.00, 0, 0, NULL, '2022-09-14 15:11:51.428483', NULL);
INSERT INTO `oms_order_item_13` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (87008, 9700945, '9700945', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 2, 98, NULL, NULL, NULL, NULL, NULL, '打折优惠：满2件，打8.00折', 539.80, 0.00, 0.00, 2699.00, 0, 0, NULL, '2022-10-11 13:32:24.851646', NULL);
INSERT INTO `oms_order_item_13` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (89016, 10100645, '10100645', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 2, 98, NULL, NULL, NULL, NULL, NULL, '打折优惠：满2件，打8.00折', 539.80, 0.00, 0.00, 2699.00, 0, 0, NULL, '2022-10-11 15:48:35.153905', NULL);
INSERT INTO `oms_order_item_13` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (89021, 10100845, '10100845', 30, 'http://tuling-mall.oss-cn-shenzhen.aliyuncs.com/tulingmall/images/20200309/面试宝典图 .jpg', 'HLA海澜之家简约动物印花短袖T恤', NULL, NULL, 111.00, 1, 112, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 111.00, 0, 0, NULL, '2022-10-11 15:50:30.208120', NULL);
INSERT INTO `oms_order_item_13` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (89022, 10100945, '10100945', 30, 'http://tuling-mall.oss-cn-shenzhen.aliyuncs.com/tulingmall/images/20200309/面试宝典图 .jpg', 'HLA海澜之家简约动物印花短袖T恤', NULL, NULL, 111.00, 1, 112, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 111.00, 0, 0, NULL, '2022-10-11 15:54:03.155921', NULL);
INSERT INTO `oms_order_item_13` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (93011, 10505045, '10505045', 30, 'http://tuling-mall.oss-cn-shenzhen.aliyuncs.com/tulingmall/images/20200309/面试宝典图 .jpg', 'HLA海澜之家简约动物印花短袖T恤', NULL, NULL, 111.00, 1, 112, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 111.00, 0, 0, NULL, '2022-10-16 16:01:47.229480', NULL);
INSERT INTO `oms_order_item_13` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (203000, 18300045, '18300045', 28, NULL, '小米 红米5A 全网通版 3GB+32GB 香槟金 移动联通电信4G手机 双卡双待', NULL, NULL, 699.00, 3, 103, NULL, NULL, NULL, NULL, NULL, '满减优惠：满1000.00元，减120.00元', 39.60, 0.00, 0.00, 699.00, 0, 0, NULL, '2023-05-08 17:25:53.914271', NULL);
INSERT INTO `oms_order_item_13` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (203001, 18300045, '18300045', 30, 'http://tuling-mall.oss-cn-shenzhen.aliyuncs.com/tulingmall/images/20200309/面试宝典图 .jpg', 'HLA海澜之家简约动物印花短袖T恤', NULL, NULL, 111.00, 1, 112, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 111.00, 0, 0, NULL, '2023-05-08 17:25:53.914271', NULL);
INSERT INTO `oms_order_item_13` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (203002, 18300145, '18300145', 28, NULL, '小米 红米5A 全网通版 3GB+32GB 香槟金 移动联通电信4G手机 双卡双待', NULL, NULL, 699.00, 3, 103, NULL, NULL, NULL, NULL, NULL, '满减优惠：满1000.00元，减120.00元', 39.60, 3.33, 0.00, 699.00, 0, 0, NULL, '2023-05-08 17:26:20.085420', NULL);
INSERT INTO `oms_order_item_13` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (203003, 18300145, '18300145', 30, 'http://tuling-mall.oss-cn-shenzhen.aliyuncs.com/tulingmall/images/20200309/面试宝典图 .jpg', 'HLA海澜之家简约动物印花短袖T恤', NULL, NULL, 111.00, 1, 112, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 111.00, 0, 0, NULL, '2023-05-08 17:26:20.085420', NULL);
INSERT INTO `oms_order_item_13` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (203004, 18300245, '18300245', 28, NULL, '小米 红米5A 全网通版 3GB+32GB 香槟金 移动联通电信4G手机 双卡双待', NULL, NULL, 699.00, 3, 103, NULL, NULL, NULL, NULL, NULL, '满减优惠：满1000.00元，减120.00元', 39.60, 3.33, 0.00, 699.00, 0, 0, NULL, '2023-05-08 17:27:09.739298', NULL);
INSERT INTO `oms_order_item_13` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (203005, 18300245, '18300245', 30, 'http://tuling-mall.oss-cn-shenzhen.aliyuncs.com/tulingmall/images/20200309/面试宝典图 .jpg', 'HLA海澜之家简约动物印花短袖T恤', NULL, NULL, 111.00, 1, 112, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 111.00, 0, 0, NULL, '2023-05-08 17:27:09.739298', NULL);
INSERT INTO `oms_order_item_13` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (203006, 18300345, '18300345', 28, NULL, '小米 红米5A 全网通版 3GB+32GB 香槟金 移动联通电信4G手机 双卡双待', NULL, NULL, 699.00, 3, 103, NULL, NULL, NULL, NULL, NULL, '满减优惠：满1000.00元，减120.00元', 39.60, 3.33, 0.00, 699.00, 0, 0, NULL, '2023-05-08 17:52:36.948130', NULL);
INSERT INTO `oms_order_item_13` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (203007, 18300345, '18300345', 30, 'http://tuling-mall.oss-cn-shenzhen.aliyuncs.com/tulingmall/images/20200309/面试宝典图 .jpg', 'HLA海澜之家简约动物印花短袖T恤', NULL, NULL, 111.00, 1, 112, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 111.00, 0, 0, NULL, '2023-05-08 17:52:36.948130', NULL);
INSERT INTO `oms_order_item_13` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (205000, 18500045, '18500045', 30, 'http://tuling-mall.oss-cn-shenzhen.aliyuncs.com/tulingmall/images/20200309/面试宝典图 .jpg', 'HLA海澜之家简约动物印花短袖T恤', NULL, NULL, 111.00, 1, 112, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 111.00, 0, 0, NULL, '2023-05-23 13:29:33.287170', NULL);
INSERT INTO `oms_order_item_13` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (205001, 18500145, '18500145', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2023-05-23 13:32:41.038256', NULL);
INSERT INTO `oms_order_item_13` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (207001, 18700145, '18700145', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2023-05-23 16:55:25.032403', NULL);
INSERT INTO `oms_order_item_13` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (207002, 18700245, '18700245', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2023-05-23 16:56:00.256182', NULL);
INSERT INTO `oms_order_item_13` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (207003, 18700345, '18700345', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2023-05-23 16:59:53.907439', NULL);
INSERT INTO `oms_order_item_13` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (207004, 18700445, '18700445', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2023-05-23 17:04:47.618849', NULL);
INSERT INTO `oms_order_item_13` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (207005, 18700545, '18700545', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2023-05-23 17:39:39.254300', NULL);
INSERT INTO `oms_order_item_13` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (207006, 18700645, '18700645', 27, NULL, '小米8 全面屏游戏智能手机 12GB+64GB 黑色 全网通4G 双卡双待', NULL, NULL, 2699.00, 1, 98, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 2699.00, 0, 0, NULL, '2023-05-24 14:37:01.845620', NULL);
INSERT INTO `oms_order_item_13` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (221000, 20100045, '20100045', 40, 'http://tuling-mall.oss-cn-shenzhen.aliyuncs.com/tulingmall/images/20200311/19e846e727dff337.jpg', '七匹狼短袖T恤男纯棉舒适春夏修身运动休闲短袖三条装 圆领3条装', NULL, NULL, 139.00, 1, 132, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 139.00, 0, 0, NULL, '2023-06-12 15:41:10.230903', NULL);
INSERT INTO `oms_order_item_13` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (221001, 20100145, '20100145', 40, 'http://tuling-mall.oss-cn-shenzhen.aliyuncs.com/tulingmall/images/20200311/19e846e727dff337.jpg', '七匹狼短袖T恤男纯棉舒适春夏修身运动休闲短袖三条装 圆领3条装', NULL, NULL, 139.00, 1, 132, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 139.00, 0, 0, NULL, '2023-06-12 17:31:27.947761', NULL);
INSERT INTO `oms_order_item_13` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (223000, 20300045, '20300045', 40, 'http://tuling-mall.oss-cn-shenzhen.aliyuncs.com/tulingmall/images/20200311/19e846e727dff337.jpg', '七匹狼短袖T恤男纯棉舒适春夏修身运动休闲短袖三条装 圆领3条装', NULL, NULL, 139.00, 1, 132, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 139.00, 0, 0, NULL, '2023-06-14 15:24:43.126448', NULL);
COMMIT;

-- ----------------------------
-- Table structure for oms_order_item_14
-- ----------------------------
DROP TABLE IF EXISTS `oms_order_item_14`;
CREATE TABLE `oms_order_item_14` (
  `id` bigint NOT NULL DEFAULT '0',
  `order_id` bigint DEFAULT NULL COMMENT '订单id',
  `order_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '订单编号',
  `product_id` bigint DEFAULT NULL,
  `product_pic` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_name` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_brand` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_price` decimal(10,2) DEFAULT NULL COMMENT '销售价格',
  `product_quantity` int DEFAULT NULL COMMENT '购买数量',
  `product_sku_id` bigint DEFAULT NULL COMMENT '商品sku编号',
  `product_sku_code` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品sku条码',
  `product_category_id` bigint DEFAULT NULL COMMENT '商品分类id',
  `sp1` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品的销售属性',
  `sp2` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `sp3` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `promotion_name` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品促销名称',
  `promotion_amount` decimal(10,2) DEFAULT NULL COMMENT '商品促销分解金额',
  `coupon_amount` decimal(10,2) DEFAULT NULL COMMENT '优惠券优惠分解金额',
  `integration_amount` decimal(10,2) DEFAULT NULL COMMENT '积分优惠分解金额',
  `real_amount` decimal(10,2) DEFAULT NULL COMMENT '该商品经过优惠后的分解金额',
  `gift_integration` int DEFAULT '0',
  `gift_growth` int DEFAULT '0',
  `product_attr` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品销售属性:[{"key":"颜色","value":"颜色"},{"key":"容量","value":"4G"}]',
  `gmt_create` datetime(6) DEFAULT CURRENT_TIMESTAMP(6),
  `gmt_modified` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_order_id` (`order_id`),
  KEY `idx_order_sn` (`order_sn`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of oms_order_item_14
-- ----------------------------
BEGIN;
INSERT INTO `oms_order_item_14` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (85008, 9300846, '9300846', 40, 'http://tuling-mall.oss-cn-shenzhen.aliyuncs.com/tulingmall/images/20200311/19e846e727dff337.jpg', '七匹狼短袖T恤男纯棉舒适春夏修身运动休闲短袖三条装 圆领3条装', NULL, NULL, 139.00, 1, 130, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 139.00, 0, 0, NULL, '2022-10-11 11:17:23.369953', NULL);
INSERT INTO `oms_order_item_14` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (87000, 9700046, '9700046', 40, 'http://tuling-mall.oss-cn-shenzhen.aliyuncs.com/tulingmall/images/20200311/19e846e727dff337.jpg', '七匹狼短袖T恤男纯棉舒适春夏修身运动休闲短袖三条装 圆领3条装', NULL, NULL, 139.00, 1, 130, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 139.00, 0, 0, NULL, '2022-10-11 12:01:15.023214', NULL);
INSERT INTO `oms_order_item_14` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (87001, 9700146, '9700146', 40, 'http://tuling-mall.oss-cn-shenzhen.aliyuncs.com/tulingmall/images/20200311/19e846e727dff337.jpg', '七匹狼短袖T恤男纯棉舒适春夏修身运动休闲短袖三条装 圆领3条装', NULL, NULL, 139.00, 1, 130, NULL, NULL, NULL, NULL, NULL, '无优惠', 0.00, 0.00, 0.00, 139.00, 0, 0, NULL, '2022-10-11 12:10:11.676686', NULL);
INSERT INTO `oms_order_item_14` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (87004, 9700446, '9700446', 40, 'http://tuling-mall.oss-cn-shenzhen.aliyuncs.com/tulingmall/images/20200311/19e846e727dff337.jpg', '七匹狼短袖T恤男纯棉舒适春夏修身运动休闲短袖三条装 圆领3条装', NULL, NULL, 139.00, 2, 130, NULL, NULL, NULL, NULL, NULL, '满减优惠：满200.00元，减50.00元', 25.00, 0.00, 0.00, 139.00, 0, 0, NULL, '2022-10-11 13:15:07.117299', NULL);
COMMIT;

-- ----------------------------
-- Table structure for oms_order_item_15
-- ----------------------------
DROP TABLE IF EXISTS `oms_order_item_15`;
CREATE TABLE `oms_order_item_15` (
  `id` bigint NOT NULL DEFAULT '0',
  `order_id` bigint DEFAULT NULL COMMENT '订单id',
  `order_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '订单编号',
  `product_id` bigint DEFAULT NULL,
  `product_pic` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_name` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_brand` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_price` decimal(10,2) DEFAULT NULL COMMENT '销售价格',
  `product_quantity` int DEFAULT NULL COMMENT '购买数量',
  `product_sku_id` bigint DEFAULT NULL COMMENT '商品sku编号',
  `product_sku_code` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品sku条码',
  `product_category_id` bigint DEFAULT NULL COMMENT '商品分类id',
  `sp1` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品的销售属性',
  `sp2` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `sp3` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `promotion_name` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品促销名称',
  `promotion_amount` decimal(10,2) DEFAULT NULL COMMENT '商品促销分解金额',
  `coupon_amount` decimal(10,2) DEFAULT NULL COMMENT '优惠券优惠分解金额',
  `integration_amount` decimal(10,2) DEFAULT NULL COMMENT '积分优惠分解金额',
  `real_amount` decimal(10,2) DEFAULT NULL COMMENT '该商品经过优惠后的分解金额',
  `gift_integration` int DEFAULT '0',
  `gift_growth` int DEFAULT '0',
  `product_attr` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品销售属性:[{"key":"颜色","value":"颜色"},{"key":"容量","value":"4G"}]',
  `gmt_create` datetime(6) DEFAULT CURRENT_TIMESTAMP(6),
  `gmt_modified` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_order_id` (`order_id`),
  KEY `idx_order_sn` (`order_sn`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of oms_order_item_15
-- ----------------------------
BEGIN;
INSERT INTO `oms_order_item_15` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (63015, 61015, '61015', 29, 'http://macro-oss.oss-cn-shenzhen.aliyuncs.com/mall/images/20180615/5acc5248N6a5f81cd.jpg', 'Apple iPhone 8 Plus 64GB 红色特别版 移动联通电信4G手机', '苹果', '7437799', 4999.00, 1, NULL, NULL, 19, NULL, NULL, NULL, '秒杀特惠活动', 0.00, 0.00, 0.00, 4999.00, 5499, 5499, NULL, '2022-09-20 16:28:30.759155', NULL);
INSERT INTO `oms_order_item_15` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (87010, 9701147, '9701147', 40, 'http://tuling-mall.oss-cn-shenzhen.aliyuncs.com/tulingmall/images/20200311/19e846e727dff337.jpg', '七匹狼短袖T恤男纯棉舒适春夏修身运动休闲短袖三条装 圆领3条装', NULL, NULL, 139.00, 2, 130, NULL, NULL, NULL, NULL, NULL, '满减优惠：满200.00元，减50.00元', 25.00, 0.00, 0.00, 139.00, 0, 0, NULL, '2022-10-11 13:56:21.898776', NULL);
INSERT INTO `oms_order_item_15` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (87011, 9701247, '9701247', 40, 'http://tuling-mall.oss-cn-shenzhen.aliyuncs.com/tulingmall/images/20200311/19e846e727dff337.jpg', '七匹狼短袖T恤男纯棉舒适春夏修身运动休闲短袖三条装 圆领3条装', NULL, NULL, 139.00, 3, 130, NULL, NULL, NULL, NULL, NULL, '满减优惠：满200.00元，减50.00元', 16.50, 0.00, 0.00, 139.00, 0, 0, NULL, '2022-10-11 13:58:07.075707', NULL);
INSERT INTO `oms_order_item_15` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (89015, 10100547, '10100547', 40, 'http://tuling-mall.oss-cn-shenzhen.aliyuncs.com/tulingmall/images/20200311/19e846e727dff337.jpg', '七匹狼短袖T恤男纯棉舒适春夏修身运动休闲短袖三条装 圆领3条装', NULL, NULL, 139.00, 4, 130, NULL, NULL, NULL, NULL, NULL, '满减优惠：满200.00元，减50.00元', 12.50, 0.00, 0.00, 139.00, 0, 0, NULL, '2022-10-11 15:48:32.026974', NULL);
INSERT INTO `oms_order_item_15` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (93000, 10503447, '10503447', 40, 'http://tuling-mall.oss-cn-shenzhen.aliyuncs.com/tulingmall/images/20200311/19e846e727dff337.jpg', '七匹狼短袖T恤男纯棉舒适春夏修身运动休闲短袖三条装 圆领3条装', NULL, NULL, 139.00, 6, 130, NULL, NULL, NULL, NULL, NULL, '满减优惠：满200.00元，减50.00元', 8.50, 0.00, 0.00, 139.00, 0, 0, NULL, '2022-10-11 17:36:19.776308', NULL);
INSERT INTO `oms_order_item_15` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (93001, 10503547, '10503547', 40, 'http://tuling-mall.oss-cn-shenzhen.aliyuncs.com/tulingmall/images/20200311/19e846e727dff337.jpg', '七匹狼短袖T恤男纯棉舒适春夏修身运动休闲短袖三条装 圆领3条装', NULL, NULL, 139.00, 6, 130, NULL, NULL, NULL, NULL, NULL, '满减优惠：满200.00元，减50.00元', 8.50, 0.00, 0.00, 139.00, 0, 0, NULL, '2022-10-11 17:37:48.586859', NULL);
INSERT INTO `oms_order_item_15` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (93002, 10503647, '10503647', 40, 'http://tuling-mall.oss-cn-shenzhen.aliyuncs.com/tulingmall/images/20200311/19e846e727dff337.jpg', '七匹狼短袖T恤男纯棉舒适春夏修身运动休闲短袖三条装 圆领3条装', NULL, NULL, 139.00, 6, 130, NULL, NULL, NULL, NULL, NULL, '满减优惠：满200.00元，减50.00元', 8.50, 0.00, 0.00, 139.00, 0, 0, NULL, '2022-10-11 17:38:49.862247', NULL);
INSERT INTO `oms_order_item_15` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (93007, 10504447, '10504447', 40, 'http://tuling-mall.oss-cn-shenzhen.aliyuncs.com/tulingmall/images/20200311/19e846e727dff337.jpg', '七匹狼短袖T恤男纯棉舒适春夏修身运动休闲短袖三条装 圆领3条装', NULL, NULL, 139.00, 6, 130, NULL, NULL, NULL, NULL, NULL, '满减优惠：满200.00元，减50.00元', 8.50, 0.00, 0.00, 139.00, 0, 0, NULL, '2022-10-11 17:56:33.502396', NULL);
INSERT INTO `oms_order_item_15` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (93008, 10504547, '10504547', 40, 'http://tuling-mall.oss-cn-shenzhen.aliyuncs.com/tulingmall/images/20200311/19e846e727dff337.jpg', '七匹狼短袖T恤男纯棉舒适春夏修身运动休闲短袖三条装 圆领3条装', NULL, NULL, 139.00, 6, 130, NULL, NULL, NULL, NULL, NULL, '满减优惠：满200.00元，减50.00元', 8.50, 0.00, 0.00, 139.00, 0, 0, NULL, '2022-10-11 17:56:48.795576', NULL);
INSERT INTO `oms_order_item_15` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (189000, 16901347, '16901347', 40, 'http://tuling-mall.oss-cn-shenzhen.aliyuncs.com/tulingmall/images/20200311/19e846e727dff337.jpg', '七匹狼短袖T恤男纯棉舒适春夏修身运动休闲短袖三条装 圆领3条装', NULL, NULL, 139.00, 6, 130, NULL, NULL, NULL, NULL, NULL, '满减优惠：满200.00元，减50.00元', 8.50, 0.00, 0.00, 139.00, 0, 0, NULL, '2022-11-16 13:33:02.847473', NULL);
INSERT INTO `oms_order_item_15` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (189001, 16901447, '16901447', 40, 'http://tuling-mall.oss-cn-shenzhen.aliyuncs.com/tulingmall/images/20200311/19e846e727dff337.jpg', '七匹狼短袖T恤男纯棉舒适春夏修身运动休闲短袖三条装 圆领3条装', NULL, NULL, 139.00, 6, 130, NULL, NULL, NULL, NULL, NULL, '满减优惠：满200.00元，减50.00元', 8.50, 0.00, 0.00, 139.00, 0, 0, NULL, '2022-11-16 13:33:23.834442', NULL);
INSERT INTO `oms_order_item_15` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (189002, 16901547, '16901547', 40, 'http://tuling-mall.oss-cn-shenzhen.aliyuncs.com/tulingmall/images/20200311/19e846e727dff337.jpg', '七匹狼短袖T恤男纯棉舒适春夏修身运动休闲短袖三条装 圆领3条装', NULL, NULL, 139.00, 6, 130, NULL, NULL, NULL, NULL, NULL, '满减优惠：满200.00元，减50.00元', 8.50, 0.00, 0.00, 139.00, 0, 0, NULL, '2022-11-16 13:34:14.896306', NULL);
INSERT INTO `oms_order_item_15` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (189003, 16901647, '16901647', 40, 'http://tuling-mall.oss-cn-shenzhen.aliyuncs.com/tulingmall/images/20200311/19e846e727dff337.jpg', '七匹狼短袖T恤男纯棉舒适春夏修身运动休闲短袖三条装 圆领3条装', NULL, NULL, 139.00, 6, 130, NULL, NULL, NULL, NULL, NULL, '满减优惠：满200.00元，减50.00元', 8.50, 0.00, 0.00, 139.00, 0, 0, NULL, '2022-11-16 13:34:44.703836', NULL);
INSERT INTO `oms_order_item_15` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (189004, 16901747, '16901747', 40, 'http://tuling-mall.oss-cn-shenzhen.aliyuncs.com/tulingmall/images/20200311/19e846e727dff337.jpg', '七匹狼短袖T恤男纯棉舒适春夏修身运动休闲短袖三条装 圆领3条装', NULL, NULL, 139.00, 6, 130, NULL, NULL, NULL, NULL, NULL, '满减优惠：满200.00元，减50.00元', 8.50, 0.00, 0.00, 139.00, 0, 0, NULL, '2022-11-16 13:35:36.994166', NULL);
INSERT INTO `oms_order_item_15` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (189015, 16902847, '16902847', 40, 'http://tuling-mall.oss-cn-shenzhen.aliyuncs.com/tulingmall/images/20200311/19e846e727dff337.jpg', '七匹狼短袖T恤男纯棉舒适春夏修身运动休闲短袖三条装 圆领3条装', NULL, NULL, 139.00, 6, 130, NULL, NULL, NULL, NULL, NULL, '满减优惠：满200.00元，减50.00元', 8.50, 0.00, 0.00, 139.00, 0, 0, NULL, '2022-11-16 13:40:19.994033', NULL);
INSERT INTO `oms_order_item_15` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (189016, 16902947, '16902947', 40, 'http://tuling-mall.oss-cn-shenzhen.aliyuncs.com/tulingmall/images/20200311/19e846e727dff337.jpg', '七匹狼短袖T恤男纯棉舒适春夏修身运动休闲短袖三条装 圆领3条装', NULL, NULL, 139.00, 6, 130, NULL, NULL, NULL, NULL, NULL, '满减优惠：满200.00元，减50.00元', 8.50, 0.00, 0.00, 139.00, 0, 0, NULL, '2022-11-16 13:41:22.238397', NULL);
INSERT INTO `oms_order_item_15` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (189018, 16903147, '16903147', 40, 'http://tuling-mall.oss-cn-shenzhen.aliyuncs.com/tulingmall/images/20200311/19e846e727dff337.jpg', '七匹狼短袖T恤男纯棉舒适春夏修身运动休闲短袖三条装 圆领3条装', NULL, NULL, 139.00, 6, 130, NULL, NULL, NULL, NULL, NULL, '满减优惠：满200.00元，减50.00元', 8.50, 0.00, 0.00, 139.00, 0, 0, NULL, '2022-11-16 13:41:56.742158', NULL);
COMMIT;

-- ----------------------------
-- Table structure for oms_order_item_16
-- ----------------------------
DROP TABLE IF EXISTS `oms_order_item_16`;
CREATE TABLE `oms_order_item_16` (
  `id` bigint NOT NULL DEFAULT '0',
  `order_id` bigint DEFAULT NULL COMMENT '订单id',
  `order_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '订单编号',
  `product_id` bigint DEFAULT NULL,
  `product_pic` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_name` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_brand` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_price` decimal(10,2) DEFAULT NULL COMMENT '销售价格',
  `product_quantity` int DEFAULT NULL COMMENT '购买数量',
  `product_sku_id` bigint DEFAULT NULL COMMENT '商品sku编号',
  `product_sku_code` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品sku条码',
  `product_category_id` bigint DEFAULT NULL COMMENT '商品分类id',
  `sp1` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品的销售属性',
  `sp2` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `sp3` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `promotion_name` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品促销名称',
  `promotion_amount` decimal(10,2) DEFAULT NULL COMMENT '商品促销分解金额',
  `coupon_amount` decimal(10,2) DEFAULT NULL COMMENT '优惠券优惠分解金额',
  `integration_amount` decimal(10,2) DEFAULT NULL COMMENT '积分优惠分解金额',
  `real_amount` decimal(10,2) DEFAULT NULL COMMENT '该商品经过优惠后的分解金额',
  `gift_integration` int DEFAULT '0',
  `gift_growth` int DEFAULT '0',
  `product_attr` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品销售属性:[{"key":"颜色","value":"颜色"},{"key":"容量","value":"4G"}]',
  `gmt_create` datetime(6) DEFAULT CURRENT_TIMESTAMP(6),
  `gmt_modified` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_order_id` (`order_id`),
  KEY `idx_order_sn` (`order_sn`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of oms_order_item_16
-- ----------------------------
BEGIN;
INSERT INTO `oms_order_item_16` (`id`, `order_id`, `order_sn`, `product_id`, `product_pic`, `product_name`, `product_brand`, `product_sn`, `product_price`, `product_quantity`, `product_sku_id`, `product_sku_code`, `product_category_id`, `sp1`, `sp2`, `sp3`, `promotion_name`, `promotion_amount`, `coupon_amount`, `integration_amount`, `real_amount`, `gift_integration`, `gift_growth`, `product_attr`, `gmt_create`, `gmt_modified`) VALUES (63016, 61016, '61016', 29, 'http://macro-oss.oss-cn-shenzhen.aliyuncs.com/mall/images/20180615/5acc5248N6a5f81cd.jpg', 'Apple iPhone 8 Plus 64GB 红色特别版 移动联通电信4G手机', '苹果', '7437799', 4999.00, 1, NULL, NULL, 19, NULL, NULL, NULL, '秒杀特惠活动', 0.00, 0.00, 0.00, 4999.00, 5499, 5499, NULL, '2022-09-20 16:59:54.692454', NULL);
COMMIT;

-- ----------------------------
-- Table structure for oms_order_item_17
-- ----------------------------
DROP TABLE IF EXISTS `oms_order_item_17`;
CREATE TABLE `oms_order_item_17` (
  `id` bigint NOT NULL DEFAULT '0',
  `order_id` bigint DEFAULT NULL COMMENT '订单id',
  `order_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '订单编号',
  `product_id` bigint DEFAULT NULL,
  `product_pic` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_name` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_brand` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_price` decimal(10,2) DEFAULT NULL COMMENT '销售价格',
  `product_quantity` int DEFAULT NULL COMMENT '购买数量',
  `product_sku_id` bigint DEFAULT NULL COMMENT '商品sku编号',
  `product_sku_code` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品sku条码',
  `product_category_id` bigint DEFAULT NULL COMMENT '商品分类id',
  `sp1` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品的销售属性',
  `sp2` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `sp3` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `promotion_name` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品促销名称',
  `promotion_amount` decimal(10,2) DEFAULT NULL COMMENT '商品促销分解金额',
  `coupon_amount` decimal(10,2) DEFAULT NULL COMMENT '优惠券优惠分解金额',
  `integration_amount` decimal(10,2) DEFAULT NULL COMMENT '积分优惠分解金额',
  `real_amount` decimal(10,2) DEFAULT NULL COMMENT '该商品经过优惠后的分解金额',
  `gift_integration` int DEFAULT '0',
  `gift_growth` int DEFAULT '0',
  `product_attr` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品销售属性:[{"key":"颜色","value":"颜色"},{"key":"容量","value":"4G"}]',
  `gmt_create` datetime(6) DEFAULT CURRENT_TIMESTAMP(6),
  `gmt_modified` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_order_id` (`order_id`),
  KEY `idx_order_sn` (`order_sn`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of oms_order_item_17
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for oms_order_item_18
-- ----------------------------
DROP TABLE IF EXISTS `oms_order_item_18`;
CREATE TABLE `oms_order_item_18` (
  `id` bigint NOT NULL DEFAULT '0',
  `order_id` bigint DEFAULT NULL COMMENT '订单id',
  `order_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '订单编号',
  `product_id` bigint DEFAULT NULL,
  `product_pic` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_name` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_brand` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_price` decimal(10,2) DEFAULT NULL COMMENT '销售价格',
  `product_quantity` int DEFAULT NULL COMMENT '购买数量',
  `product_sku_id` bigint DEFAULT NULL COMMENT '商品sku编号',
  `product_sku_code` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品sku条码',
  `product_category_id` bigint DEFAULT NULL COMMENT '商品分类id',
  `sp1` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品的销售属性',
  `sp2` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `sp3` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `promotion_name` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品促销名称',
  `promotion_amount` decimal(10,2) DEFAULT NULL COMMENT '商品促销分解金额',
  `coupon_amount` decimal(10,2) DEFAULT NULL COMMENT '优惠券优惠分解金额',
  `integration_amount` decimal(10,2) DEFAULT NULL COMMENT '积分优惠分解金额',
  `real_amount` decimal(10,2) DEFAULT NULL COMMENT '该商品经过优惠后的分解金额',
  `gift_integration` int DEFAULT '0',
  `gift_growth` int DEFAULT '0',
  `product_attr` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品销售属性:[{"key":"颜色","value":"颜色"},{"key":"容量","value":"4G"}]',
  `gmt_create` datetime(6) DEFAULT CURRENT_TIMESTAMP(6),
  `gmt_modified` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_order_id` (`order_id`),
  KEY `idx_order_sn` (`order_sn`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of oms_order_item_18
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for oms_order_item_19
-- ----------------------------
DROP TABLE IF EXISTS `oms_order_item_19`;
CREATE TABLE `oms_order_item_19` (
  `id` bigint NOT NULL DEFAULT '0',
  `order_id` bigint DEFAULT NULL COMMENT '订单id',
  `order_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '订单编号',
  `product_id` bigint DEFAULT NULL,
  `product_pic` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_name` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_brand` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_price` decimal(10,2) DEFAULT NULL COMMENT '销售价格',
  `product_quantity` int DEFAULT NULL COMMENT '购买数量',
  `product_sku_id` bigint DEFAULT NULL COMMENT '商品sku编号',
  `product_sku_code` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品sku条码',
  `product_category_id` bigint DEFAULT NULL COMMENT '商品分类id',
  `sp1` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品的销售属性',
  `sp2` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `sp3` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `promotion_name` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品促销名称',
  `promotion_amount` decimal(10,2) DEFAULT NULL COMMENT '商品促销分解金额',
  `coupon_amount` decimal(10,2) DEFAULT NULL COMMENT '优惠券优惠分解金额',
  `integration_amount` decimal(10,2) DEFAULT NULL COMMENT '积分优惠分解金额',
  `real_amount` decimal(10,2) DEFAULT NULL COMMENT '该商品经过优惠后的分解金额',
  `gift_integration` int DEFAULT '0',
  `gift_growth` int DEFAULT '0',
  `product_attr` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品销售属性:[{"key":"颜色","value":"颜色"},{"key":"容量","value":"4G"}]',
  `gmt_create` datetime(6) DEFAULT CURRENT_TIMESTAMP(6),
  `gmt_modified` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_order_id` (`order_id`),
  KEY `idx_order_sn` (`order_sn`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of oms_order_item_19
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for oms_order_item_2
-- ----------------------------
DROP TABLE IF EXISTS `oms_order_item_2`;
CREATE TABLE `oms_order_item_2` (
  `id` bigint NOT NULL DEFAULT '0',
  `order_id` bigint DEFAULT NULL COMMENT '订单id',
  `order_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '订单编号',
  `product_id` bigint DEFAULT NULL,
  `product_pic` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_name` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_brand` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_price` decimal(10,2) DEFAULT NULL COMMENT '销售价格',
  `product_quantity` int DEFAULT NULL COMMENT '购买数量',
  `product_sku_id` bigint DEFAULT NULL COMMENT '商品sku编号',
  `product_sku_code` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品sku条码',
  `product_category_id` bigint DEFAULT NULL COMMENT '商品分类id',
  `sp1` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品的销售属性',
  `sp2` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `sp3` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `promotion_name` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品促销名称',
  `promotion_amount` decimal(10,2) DEFAULT NULL COMMENT '商品促销分解金额',
  `coupon_amount` decimal(10,2) DEFAULT NULL COMMENT '优惠券优惠分解金额',
  `integration_amount` decimal(10,2) DEFAULT NULL COMMENT '积分优惠分解金额',
  `real_amount` decimal(10,2) DEFAULT NULL COMMENT '该商品经过优惠后的分解金额',
  `gift_integration` int DEFAULT '0',
  `gift_growth` int DEFAULT '0',
  `product_attr` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品销售属性:[{"key":"颜色","value":"颜色"},{"key":"容量","value":"4G"}]',
  `gmt_create` datetime(6) DEFAULT CURRENT_TIMESTAMP(6),
  `gmt_modified` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_order_id` (`order_id`),
  KEY `idx_order_sn` (`order_sn`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of oms_order_item_2
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for oms_order_item_20
-- ----------------------------
DROP TABLE IF EXISTS `oms_order_item_20`;
CREATE TABLE `oms_order_item_20` (
  `id` bigint NOT NULL DEFAULT '0',
  `order_id` bigint DEFAULT NULL COMMENT '订单id',
  `order_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '订单编号',
  `product_id` bigint DEFAULT NULL,
  `product_pic` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_name` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_brand` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_price` decimal(10,2) DEFAULT NULL COMMENT '销售价格',
  `product_quantity` int DEFAULT NULL COMMENT '购买数量',
  `product_sku_id` bigint DEFAULT NULL COMMENT '商品sku编号',
  `product_sku_code` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品sku条码',
  `product_category_id` bigint DEFAULT NULL COMMENT '商品分类id',
  `sp1` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品的销售属性',
  `sp2` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `sp3` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `promotion_name` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品促销名称',
  `promotion_amount` decimal(10,2) DEFAULT NULL COMMENT '商品促销分解金额',
  `coupon_amount` decimal(10,2) DEFAULT NULL COMMENT '优惠券优惠分解金额',
  `integration_amount` decimal(10,2) DEFAULT NULL COMMENT '积分优惠分解金额',
  `real_amount` decimal(10,2) DEFAULT NULL COMMENT '该商品经过优惠后的分解金额',
  `gift_integration` int DEFAULT '0',
  `gift_growth` int DEFAULT '0',
  `product_attr` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品销售属性:[{"key":"颜色","value":"颜色"},{"key":"容量","value":"4G"}]',
  `gmt_create` datetime(6) DEFAULT CURRENT_TIMESTAMP(6),
  `gmt_modified` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_order_id` (`order_id`),
  KEY `idx_order_sn` (`order_sn`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of oms_order_item_20
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for oms_order_item_21
-- ----------------------------
DROP TABLE IF EXISTS `oms_order_item_21`;
CREATE TABLE `oms_order_item_21` (
  `id` bigint NOT NULL DEFAULT '0',
  `order_id` bigint DEFAULT NULL COMMENT '订单id',
  `order_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '订单编号',
  `product_id` bigint DEFAULT NULL,
  `product_pic` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_name` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_brand` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_price` decimal(10,2) DEFAULT NULL COMMENT '销售价格',
  `product_quantity` int DEFAULT NULL COMMENT '购买数量',
  `product_sku_id` bigint DEFAULT NULL COMMENT '商品sku编号',
  `product_sku_code` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品sku条码',
  `product_category_id` bigint DEFAULT NULL COMMENT '商品分类id',
  `sp1` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品的销售属性',
  `sp2` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `sp3` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `promotion_name` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品促销名称',
  `promotion_amount` decimal(10,2) DEFAULT NULL COMMENT '商品促销分解金额',
  `coupon_amount` decimal(10,2) DEFAULT NULL COMMENT '优惠券优惠分解金额',
  `integration_amount` decimal(10,2) DEFAULT NULL COMMENT '积分优惠分解金额',
  `real_amount` decimal(10,2) DEFAULT NULL COMMENT '该商品经过优惠后的分解金额',
  `gift_integration` int DEFAULT '0',
  `gift_growth` int DEFAULT '0',
  `product_attr` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品销售属性:[{"key":"颜色","value":"颜色"},{"key":"容量","value":"4G"}]',
  `gmt_create` datetime(6) DEFAULT CURRENT_TIMESTAMP(6),
  `gmt_modified` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_order_id` (`order_id`),
  KEY `idx_order_sn` (`order_sn`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of oms_order_item_21
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for oms_order_item_22
-- ----------------------------
DROP TABLE IF EXISTS `oms_order_item_22`;
CREATE TABLE `oms_order_item_22` (
  `id` bigint NOT NULL DEFAULT '0',
  `order_id` bigint DEFAULT NULL COMMENT '订单id',
  `order_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '订单编号',
  `product_id` bigint DEFAULT NULL,
  `product_pic` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_name` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_brand` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_price` decimal(10,2) DEFAULT NULL COMMENT '销售价格',
  `product_quantity` int DEFAULT NULL COMMENT '购买数量',
  `product_sku_id` bigint DEFAULT NULL COMMENT '商品sku编号',
  `product_sku_code` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品sku条码',
  `product_category_id` bigint DEFAULT NULL COMMENT '商品分类id',
  `sp1` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品的销售属性',
  `sp2` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `sp3` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `promotion_name` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品促销名称',
  `promotion_amount` decimal(10,2) DEFAULT NULL COMMENT '商品促销分解金额',
  `coupon_amount` decimal(10,2) DEFAULT NULL COMMENT '优惠券优惠分解金额',
  `integration_amount` decimal(10,2) DEFAULT NULL COMMENT '积分优惠分解金额',
  `real_amount` decimal(10,2) DEFAULT NULL COMMENT '该商品经过优惠后的分解金额',
  `gift_integration` int DEFAULT '0',
  `gift_growth` int DEFAULT '0',
  `product_attr` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品销售属性:[{"key":"颜色","value":"颜色"},{"key":"容量","value":"4G"}]',
  `gmt_create` datetime(6) DEFAULT CURRENT_TIMESTAMP(6),
  `gmt_modified` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_order_id` (`order_id`),
  KEY `idx_order_sn` (`order_sn`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of oms_order_item_22
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for oms_order_item_23
-- ----------------------------
DROP TABLE IF EXISTS `oms_order_item_23`;
CREATE TABLE `oms_order_item_23` (
  `id` bigint NOT NULL DEFAULT '0',
  `order_id` bigint DEFAULT NULL COMMENT '订单id',
  `order_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '订单编号',
  `product_id` bigint DEFAULT NULL,
  `product_pic` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_name` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_brand` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_price` decimal(10,2) DEFAULT NULL COMMENT '销售价格',
  `product_quantity` int DEFAULT NULL COMMENT '购买数量',
  `product_sku_id` bigint DEFAULT NULL COMMENT '商品sku编号',
  `product_sku_code` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品sku条码',
  `product_category_id` bigint DEFAULT NULL COMMENT '商品分类id',
  `sp1` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品的销售属性',
  `sp2` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `sp3` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `promotion_name` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品促销名称',
  `promotion_amount` decimal(10,2) DEFAULT NULL COMMENT '商品促销分解金额',
  `coupon_amount` decimal(10,2) DEFAULT NULL COMMENT '优惠券优惠分解金额',
  `integration_amount` decimal(10,2) DEFAULT NULL COMMENT '积分优惠分解金额',
  `real_amount` decimal(10,2) DEFAULT NULL COMMENT '该商品经过优惠后的分解金额',
  `gift_integration` int DEFAULT '0',
  `gift_growth` int DEFAULT '0',
  `product_attr` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品销售属性:[{"key":"颜色","value":"颜色"},{"key":"容量","value":"4G"}]',
  `gmt_create` datetime(6) DEFAULT CURRENT_TIMESTAMP(6),
  `gmt_modified` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_order_id` (`order_id`),
  KEY `idx_order_sn` (`order_sn`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of oms_order_item_23
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for oms_order_item_24
-- ----------------------------
DROP TABLE IF EXISTS `oms_order_item_24`;
CREATE TABLE `oms_order_item_24` (
  `id` bigint NOT NULL DEFAULT '0',
  `order_id` bigint DEFAULT NULL COMMENT '订单id',
  `order_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '订单编号',
  `product_id` bigint DEFAULT NULL,
  `product_pic` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_name` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_brand` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_price` decimal(10,2) DEFAULT NULL COMMENT '销售价格',
  `product_quantity` int DEFAULT NULL COMMENT '购买数量',
  `product_sku_id` bigint DEFAULT NULL COMMENT '商品sku编号',
  `product_sku_code` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品sku条码',
  `product_category_id` bigint DEFAULT NULL COMMENT '商品分类id',
  `sp1` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品的销售属性',
  `sp2` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `sp3` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `promotion_name` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品促销名称',
  `promotion_amount` decimal(10,2) DEFAULT NULL COMMENT '商品促销分解金额',
  `coupon_amount` decimal(10,2) DEFAULT NULL COMMENT '优惠券优惠分解金额',
  `integration_amount` decimal(10,2) DEFAULT NULL COMMENT '积分优惠分解金额',
  `real_amount` decimal(10,2) DEFAULT NULL COMMENT '该商品经过优惠后的分解金额',
  `gift_integration` int DEFAULT '0',
  `gift_growth` int DEFAULT '0',
  `product_attr` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品销售属性:[{"key":"颜色","value":"颜色"},{"key":"容量","value":"4G"}]',
  `gmt_create` datetime(6) DEFAULT CURRENT_TIMESTAMP(6),
  `gmt_modified` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_order_id` (`order_id`),
  KEY `idx_order_sn` (`order_sn`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of oms_order_item_24
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for oms_order_item_25
-- ----------------------------
DROP TABLE IF EXISTS `oms_order_item_25`;
CREATE TABLE `oms_order_item_25` (
  `id` bigint NOT NULL DEFAULT '0',
  `order_id` bigint DEFAULT NULL COMMENT '订单id',
  `order_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '订单编号',
  `product_id` bigint DEFAULT NULL,
  `product_pic` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_name` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_brand` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_price` decimal(10,2) DEFAULT NULL COMMENT '销售价格',
  `product_quantity` int DEFAULT NULL COMMENT '购买数量',
  `product_sku_id` bigint DEFAULT NULL COMMENT '商品sku编号',
  `product_sku_code` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品sku条码',
  `product_category_id` bigint DEFAULT NULL COMMENT '商品分类id',
  `sp1` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品的销售属性',
  `sp2` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `sp3` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `promotion_name` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品促销名称',
  `promotion_amount` decimal(10,2) DEFAULT NULL COMMENT '商品促销分解金额',
  `coupon_amount` decimal(10,2) DEFAULT NULL COMMENT '优惠券优惠分解金额',
  `integration_amount` decimal(10,2) DEFAULT NULL COMMENT '积分优惠分解金额',
  `real_amount` decimal(10,2) DEFAULT NULL COMMENT '该商品经过优惠后的分解金额',
  `gift_integration` int DEFAULT '0',
  `gift_growth` int DEFAULT '0',
  `product_attr` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品销售属性:[{"key":"颜色","value":"颜色"},{"key":"容量","value":"4G"}]',
  `gmt_create` datetime(6) DEFAULT CURRENT_TIMESTAMP(6),
  `gmt_modified` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_order_id` (`order_id`),
  KEY `idx_order_sn` (`order_sn`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of oms_order_item_25
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for oms_order_item_26
-- ----------------------------
DROP TABLE IF EXISTS `oms_order_item_26`;
CREATE TABLE `oms_order_item_26` (
  `id` bigint NOT NULL DEFAULT '0',
  `order_id` bigint DEFAULT NULL COMMENT '订单id',
  `order_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '订单编号',
  `product_id` bigint DEFAULT NULL,
  `product_pic` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_name` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_brand` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_price` decimal(10,2) DEFAULT NULL COMMENT '销售价格',
  `product_quantity` int DEFAULT NULL COMMENT '购买数量',
  `product_sku_id` bigint DEFAULT NULL COMMENT '商品sku编号',
  `product_sku_code` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品sku条码',
  `product_category_id` bigint DEFAULT NULL COMMENT '商品分类id',
  `sp1` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品的销售属性',
  `sp2` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `sp3` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `promotion_name` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品促销名称',
  `promotion_amount` decimal(10,2) DEFAULT NULL COMMENT '商品促销分解金额',
  `coupon_amount` decimal(10,2) DEFAULT NULL COMMENT '优惠券优惠分解金额',
  `integration_amount` decimal(10,2) DEFAULT NULL COMMENT '积分优惠分解金额',
  `real_amount` decimal(10,2) DEFAULT NULL COMMENT '该商品经过优惠后的分解金额',
  `gift_integration` int DEFAULT '0',
  `gift_growth` int DEFAULT '0',
  `product_attr` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品销售属性:[{"key":"颜色","value":"颜色"},{"key":"容量","value":"4G"}]',
  `gmt_create` datetime(6) DEFAULT CURRENT_TIMESTAMP(6),
  `gmt_modified` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_order_id` (`order_id`),
  KEY `idx_order_sn` (`order_sn`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of oms_order_item_26
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for oms_order_item_27
-- ----------------------------
DROP TABLE IF EXISTS `oms_order_item_27`;
CREATE TABLE `oms_order_item_27` (
  `id` bigint NOT NULL DEFAULT '0',
  `order_id` bigint DEFAULT NULL COMMENT '订单id',
  `order_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '订单编号',
  `product_id` bigint DEFAULT NULL,
  `product_pic` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_name` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_brand` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_price` decimal(10,2) DEFAULT NULL COMMENT '销售价格',
  `product_quantity` int DEFAULT NULL COMMENT '购买数量',
  `product_sku_id` bigint DEFAULT NULL COMMENT '商品sku编号',
  `product_sku_code` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品sku条码',
  `product_category_id` bigint DEFAULT NULL COMMENT '商品分类id',
  `sp1` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品的销售属性',
  `sp2` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `sp3` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `promotion_name` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品促销名称',
  `promotion_amount` decimal(10,2) DEFAULT NULL COMMENT '商品促销分解金额',
  `coupon_amount` decimal(10,2) DEFAULT NULL COMMENT '优惠券优惠分解金额',
  `integration_amount` decimal(10,2) DEFAULT NULL COMMENT '积分优惠分解金额',
  `real_amount` decimal(10,2) DEFAULT NULL COMMENT '该商品经过优惠后的分解金额',
  `gift_integration` int DEFAULT '0',
  `gift_growth` int DEFAULT '0',
  `product_attr` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品销售属性:[{"key":"颜色","value":"颜色"},{"key":"容量","value":"4G"}]',
  `gmt_create` datetime(6) DEFAULT CURRENT_TIMESTAMP(6),
  `gmt_modified` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_order_id` (`order_id`),
  KEY `idx_order_sn` (`order_sn`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of oms_order_item_27
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for oms_order_item_28
-- ----------------------------
DROP TABLE IF EXISTS `oms_order_item_28`;
CREATE TABLE `oms_order_item_28` (
  `id` bigint NOT NULL DEFAULT '0',
  `order_id` bigint DEFAULT NULL COMMENT '订单id',
  `order_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '订单编号',
  `product_id` bigint DEFAULT NULL,
  `product_pic` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_name` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_brand` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_price` decimal(10,2) DEFAULT NULL COMMENT '销售价格',
  `product_quantity` int DEFAULT NULL COMMENT '购买数量',
  `product_sku_id` bigint DEFAULT NULL COMMENT '商品sku编号',
  `product_sku_code` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品sku条码',
  `product_category_id` bigint DEFAULT NULL COMMENT '商品分类id',
  `sp1` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品的销售属性',
  `sp2` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `sp3` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `promotion_name` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品促销名称',
  `promotion_amount` decimal(10,2) DEFAULT NULL COMMENT '商品促销分解金额',
  `coupon_amount` decimal(10,2) DEFAULT NULL COMMENT '优惠券优惠分解金额',
  `integration_amount` decimal(10,2) DEFAULT NULL COMMENT '积分优惠分解金额',
  `real_amount` decimal(10,2) DEFAULT NULL COMMENT '该商品经过优惠后的分解金额',
  `gift_integration` int DEFAULT '0',
  `gift_growth` int DEFAULT '0',
  `product_attr` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品销售属性:[{"key":"颜色","value":"颜色"},{"key":"容量","value":"4G"}]',
  `gmt_create` datetime(6) DEFAULT CURRENT_TIMESTAMP(6),
  `gmt_modified` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_order_id` (`order_id`),
  KEY `idx_order_sn` (`order_sn`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of oms_order_item_28
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for oms_order_item_29
-- ----------------------------
DROP TABLE IF EXISTS `oms_order_item_29`;
CREATE TABLE `oms_order_item_29` (
  `id` bigint NOT NULL DEFAULT '0',
  `order_id` bigint DEFAULT NULL COMMENT '订单id',
  `order_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '订单编号',
  `product_id` bigint DEFAULT NULL,
  `product_pic` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_name` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_brand` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_price` decimal(10,2) DEFAULT NULL COMMENT '销售价格',
  `product_quantity` int DEFAULT NULL COMMENT '购买数量',
  `product_sku_id` bigint DEFAULT NULL COMMENT '商品sku编号',
  `product_sku_code` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品sku条码',
  `product_category_id` bigint DEFAULT NULL COMMENT '商品分类id',
  `sp1` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品的销售属性',
  `sp2` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `sp3` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `promotion_name` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品促销名称',
  `promotion_amount` decimal(10,2) DEFAULT NULL COMMENT '商品促销分解金额',
  `coupon_amount` decimal(10,2) DEFAULT NULL COMMENT '优惠券优惠分解金额',
  `integration_amount` decimal(10,2) DEFAULT NULL COMMENT '积分优惠分解金额',
  `real_amount` decimal(10,2) DEFAULT NULL COMMENT '该商品经过优惠后的分解金额',
  `gift_integration` int DEFAULT '0',
  `gift_growth` int DEFAULT '0',
  `product_attr` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品销售属性:[{"key":"颜色","value":"颜色"},{"key":"容量","value":"4G"}]',
  `gmt_create` datetime(6) DEFAULT CURRENT_TIMESTAMP(6),
  `gmt_modified` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_order_id` (`order_id`),
  KEY `idx_order_sn` (`order_sn`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of oms_order_item_29
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for oms_order_item_3
-- ----------------------------
DROP TABLE IF EXISTS `oms_order_item_3`;
CREATE TABLE `oms_order_item_3` (
  `id` bigint NOT NULL DEFAULT '0',
  `order_id` bigint DEFAULT NULL COMMENT '订单id',
  `order_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '订单编号',
  `product_id` bigint DEFAULT NULL,
  `product_pic` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_name` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_brand` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_price` decimal(10,2) DEFAULT NULL COMMENT '销售价格',
  `product_quantity` int DEFAULT NULL COMMENT '购买数量',
  `product_sku_id` bigint DEFAULT NULL COMMENT '商品sku编号',
  `product_sku_code` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品sku条码',
  `product_category_id` bigint DEFAULT NULL COMMENT '商品分类id',
  `sp1` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品的销售属性',
  `sp2` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `sp3` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `promotion_name` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品促销名称',
  `promotion_amount` decimal(10,2) DEFAULT NULL COMMENT '商品促销分解金额',
  `coupon_amount` decimal(10,2) DEFAULT NULL COMMENT '优惠券优惠分解金额',
  `integration_amount` decimal(10,2) DEFAULT NULL COMMENT '积分优惠分解金额',
  `real_amount` decimal(10,2) DEFAULT NULL COMMENT '该商品经过优惠后的分解金额',
  `gift_integration` int DEFAULT '0',
  `gift_growth` int DEFAULT '0',
  `product_attr` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品销售属性:[{"key":"颜色","value":"颜色"},{"key":"容量","value":"4G"}]',
  `gmt_create` datetime(6) DEFAULT CURRENT_TIMESTAMP(6),
  `gmt_modified` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_order_id` (`order_id`),
  KEY `idx_order_sn` (`order_sn`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of oms_order_item_3
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for oms_order_item_30
-- ----------------------------
DROP TABLE IF EXISTS `oms_order_item_30`;
CREATE TABLE `oms_order_item_30` (
  `id` bigint NOT NULL DEFAULT '0',
  `order_id` bigint DEFAULT NULL COMMENT '订单id',
  `order_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '订单编号',
  `product_id` bigint DEFAULT NULL,
  `product_pic` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_name` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_brand` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_price` decimal(10,2) DEFAULT NULL COMMENT '销售价格',
  `product_quantity` int DEFAULT NULL COMMENT '购买数量',
  `product_sku_id` bigint DEFAULT NULL COMMENT '商品sku编号',
  `product_sku_code` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品sku条码',
  `product_category_id` bigint DEFAULT NULL COMMENT '商品分类id',
  `sp1` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品的销售属性',
  `sp2` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `sp3` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `promotion_name` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品促销名称',
  `promotion_amount` decimal(10,2) DEFAULT NULL COMMENT '商品促销分解金额',
  `coupon_amount` decimal(10,2) DEFAULT NULL COMMENT '优惠券优惠分解金额',
  `integration_amount` decimal(10,2) DEFAULT NULL COMMENT '积分优惠分解金额',
  `real_amount` decimal(10,2) DEFAULT NULL COMMENT '该商品经过优惠后的分解金额',
  `gift_integration` int DEFAULT '0',
  `gift_growth` int DEFAULT '0',
  `product_attr` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品销售属性:[{"key":"颜色","value":"颜色"},{"key":"容量","value":"4G"}]',
  `gmt_create` datetime(6) DEFAULT CURRENT_TIMESTAMP(6),
  `gmt_modified` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_order_id` (`order_id`),
  KEY `idx_order_sn` (`order_sn`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of oms_order_item_30
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for oms_order_item_31
-- ----------------------------
DROP TABLE IF EXISTS `oms_order_item_31`;
CREATE TABLE `oms_order_item_31` (
  `id` bigint NOT NULL DEFAULT '0',
  `order_id` bigint DEFAULT NULL COMMENT '订单id',
  `order_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '订单编号',
  `product_id` bigint DEFAULT NULL,
  `product_pic` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_name` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_brand` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_price` decimal(10,2) DEFAULT NULL COMMENT '销售价格',
  `product_quantity` int DEFAULT NULL COMMENT '购买数量',
  `product_sku_id` bigint DEFAULT NULL COMMENT '商品sku编号',
  `product_sku_code` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品sku条码',
  `product_category_id` bigint DEFAULT NULL COMMENT '商品分类id',
  `sp1` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品的销售属性',
  `sp2` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `sp3` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `promotion_name` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品促销名称',
  `promotion_amount` decimal(10,2) DEFAULT NULL COMMENT '商品促销分解金额',
  `coupon_amount` decimal(10,2) DEFAULT NULL COMMENT '优惠券优惠分解金额',
  `integration_amount` decimal(10,2) DEFAULT NULL COMMENT '积分优惠分解金额',
  `real_amount` decimal(10,2) DEFAULT NULL COMMENT '该商品经过优惠后的分解金额',
  `gift_integration` int DEFAULT '0',
  `gift_growth` int DEFAULT '0',
  `product_attr` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品销售属性:[{"key":"颜色","value":"颜色"},{"key":"容量","value":"4G"}]',
  `gmt_create` datetime(6) DEFAULT CURRENT_TIMESTAMP(6),
  `gmt_modified` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_order_id` (`order_id`),
  KEY `idx_order_sn` (`order_sn`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of oms_order_item_31
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for oms_order_item_4
-- ----------------------------
DROP TABLE IF EXISTS `oms_order_item_4`;
CREATE TABLE `oms_order_item_4` (
  `id` bigint NOT NULL DEFAULT '0',
  `order_id` bigint DEFAULT NULL COMMENT '订单id',
  `order_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '订单编号',
  `product_id` bigint DEFAULT NULL,
  `product_pic` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_name` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_brand` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_price` decimal(10,2) DEFAULT NULL COMMENT '销售价格',
  `product_quantity` int DEFAULT NULL COMMENT '购买数量',
  `product_sku_id` bigint DEFAULT NULL COMMENT '商品sku编号',
  `product_sku_code` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品sku条码',
  `product_category_id` bigint DEFAULT NULL COMMENT '商品分类id',
  `sp1` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品的销售属性',
  `sp2` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `sp3` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `promotion_name` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品促销名称',
  `promotion_amount` decimal(10,2) DEFAULT NULL COMMENT '商品促销分解金额',
  `coupon_amount` decimal(10,2) DEFAULT NULL COMMENT '优惠券优惠分解金额',
  `integration_amount` decimal(10,2) DEFAULT NULL COMMENT '积分优惠分解金额',
  `real_amount` decimal(10,2) DEFAULT NULL COMMENT '该商品经过优惠后的分解金额',
  `gift_integration` int DEFAULT '0',
  `gift_growth` int DEFAULT '0',
  `product_attr` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品销售属性:[{"key":"颜色","value":"颜色"},{"key":"容量","value":"4G"}]',
  `gmt_create` datetime(6) DEFAULT CURRENT_TIMESTAMP(6),
  `gmt_modified` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_order_id` (`order_id`),
  KEY `idx_order_sn` (`order_sn`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of oms_order_item_4
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for oms_order_item_5
-- ----------------------------
DROP TABLE IF EXISTS `oms_order_item_5`;
CREATE TABLE `oms_order_item_5` (
  `id` bigint NOT NULL DEFAULT '0',
  `order_id` bigint DEFAULT NULL COMMENT '订单id',
  `order_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '订单编号',
  `product_id` bigint DEFAULT NULL,
  `product_pic` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_name` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_brand` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_price` decimal(10,2) DEFAULT NULL COMMENT '销售价格',
  `product_quantity` int DEFAULT NULL COMMENT '购买数量',
  `product_sku_id` bigint DEFAULT NULL COMMENT '商品sku编号',
  `product_sku_code` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品sku条码',
  `product_category_id` bigint DEFAULT NULL COMMENT '商品分类id',
  `sp1` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品的销售属性',
  `sp2` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `sp3` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `promotion_name` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品促销名称',
  `promotion_amount` decimal(10,2) DEFAULT NULL COMMENT '商品促销分解金额',
  `coupon_amount` decimal(10,2) DEFAULT NULL COMMENT '优惠券优惠分解金额',
  `integration_amount` decimal(10,2) DEFAULT NULL COMMENT '积分优惠分解金额',
  `real_amount` decimal(10,2) DEFAULT NULL COMMENT '该商品经过优惠后的分解金额',
  `gift_integration` int DEFAULT '0',
  `gift_growth` int DEFAULT '0',
  `product_attr` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品销售属性:[{"key":"颜色","value":"颜色"},{"key":"容量","value":"4G"}]',
  `gmt_create` datetime(6) DEFAULT CURRENT_TIMESTAMP(6),
  `gmt_modified` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_order_id` (`order_id`),
  KEY `idx_order_sn` (`order_sn`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of oms_order_item_5
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for oms_order_item_6
-- ----------------------------
DROP TABLE IF EXISTS `oms_order_item_6`;
CREATE TABLE `oms_order_item_6` (
  `id` bigint NOT NULL DEFAULT '0',
  `order_id` bigint DEFAULT NULL COMMENT '订单id',
  `order_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '订单编号',
  `product_id` bigint DEFAULT NULL,
  `product_pic` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_name` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_brand` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_price` decimal(10,2) DEFAULT NULL COMMENT '销售价格',
  `product_quantity` int DEFAULT NULL COMMENT '购买数量',
  `product_sku_id` bigint DEFAULT NULL COMMENT '商品sku编号',
  `product_sku_code` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品sku条码',
  `product_category_id` bigint DEFAULT NULL COMMENT '商品分类id',
  `sp1` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品的销售属性',
  `sp2` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `sp3` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `promotion_name` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品促销名称',
  `promotion_amount` decimal(10,2) DEFAULT NULL COMMENT '商品促销分解金额',
  `coupon_amount` decimal(10,2) DEFAULT NULL COMMENT '优惠券优惠分解金额',
  `integration_amount` decimal(10,2) DEFAULT NULL COMMENT '积分优惠分解金额',
  `real_amount` decimal(10,2) DEFAULT NULL COMMENT '该商品经过优惠后的分解金额',
  `gift_integration` int DEFAULT '0',
  `gift_growth` int DEFAULT '0',
  `product_attr` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品销售属性:[{"key":"颜色","value":"颜色"},{"key":"容量","value":"4G"}]',
  `gmt_create` datetime(6) DEFAULT CURRENT_TIMESTAMP(6),
  `gmt_modified` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_order_id` (`order_id`),
  KEY `idx_order_sn` (`order_sn`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of oms_order_item_6
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for oms_order_item_7
-- ----------------------------
DROP TABLE IF EXISTS `oms_order_item_7`;
CREATE TABLE `oms_order_item_7` (
  `id` bigint NOT NULL DEFAULT '0',
  `order_id` bigint DEFAULT NULL COMMENT '订单id',
  `order_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '订单编号',
  `product_id` bigint DEFAULT NULL,
  `product_pic` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_name` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_brand` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_price` decimal(10,2) DEFAULT NULL COMMENT '销售价格',
  `product_quantity` int DEFAULT NULL COMMENT '购买数量',
  `product_sku_id` bigint DEFAULT NULL COMMENT '商品sku编号',
  `product_sku_code` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品sku条码',
  `product_category_id` bigint DEFAULT NULL COMMENT '商品分类id',
  `sp1` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品的销售属性',
  `sp2` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `sp3` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `promotion_name` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品促销名称',
  `promotion_amount` decimal(10,2) DEFAULT NULL COMMENT '商品促销分解金额',
  `coupon_amount` decimal(10,2) DEFAULT NULL COMMENT '优惠券优惠分解金额',
  `integration_amount` decimal(10,2) DEFAULT NULL COMMENT '积分优惠分解金额',
  `real_amount` decimal(10,2) DEFAULT NULL COMMENT '该商品经过优惠后的分解金额',
  `gift_integration` int DEFAULT '0',
  `gift_growth` int DEFAULT '0',
  `product_attr` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品销售属性:[{"key":"颜色","value":"颜色"},{"key":"容量","value":"4G"}]',
  `gmt_create` datetime(6) DEFAULT CURRENT_TIMESTAMP(6),
  `gmt_modified` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_order_id` (`order_id`),
  KEY `idx_order_sn` (`order_sn`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of oms_order_item_7
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for oms_order_item_8
-- ----------------------------
DROP TABLE IF EXISTS `oms_order_item_8`;
CREATE TABLE `oms_order_item_8` (
  `id` bigint NOT NULL DEFAULT '0',
  `order_id` bigint DEFAULT NULL COMMENT '订单id',
  `order_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '订单编号',
  `product_id` bigint DEFAULT NULL,
  `product_pic` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_name` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_brand` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_price` decimal(10,2) DEFAULT NULL COMMENT '销售价格',
  `product_quantity` int DEFAULT NULL COMMENT '购买数量',
  `product_sku_id` bigint DEFAULT NULL COMMENT '商品sku编号',
  `product_sku_code` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品sku条码',
  `product_category_id` bigint DEFAULT NULL COMMENT '商品分类id',
  `sp1` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品的销售属性',
  `sp2` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `sp3` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `promotion_name` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品促销名称',
  `promotion_amount` decimal(10,2) DEFAULT NULL COMMENT '商品促销分解金额',
  `coupon_amount` decimal(10,2) DEFAULT NULL COMMENT '优惠券优惠分解金额',
  `integration_amount` decimal(10,2) DEFAULT NULL COMMENT '积分优惠分解金额',
  `real_amount` decimal(10,2) DEFAULT NULL COMMENT '该商品经过优惠后的分解金额',
  `gift_integration` int DEFAULT '0',
  `gift_growth` int DEFAULT '0',
  `product_attr` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品销售属性:[{"key":"颜色","value":"颜色"},{"key":"容量","value":"4G"}]',
  `gmt_create` datetime(6) DEFAULT CURRENT_TIMESTAMP(6),
  `gmt_modified` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_order_id` (`order_id`),
  KEY `idx_order_sn` (`order_sn`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of oms_order_item_8
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for oms_order_item_9
-- ----------------------------
DROP TABLE IF EXISTS `oms_order_item_9`;
CREATE TABLE `oms_order_item_9` (
  `id` bigint NOT NULL DEFAULT '0',
  `order_id` bigint DEFAULT NULL COMMENT '订单id',
  `order_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '订单编号',
  `product_id` bigint DEFAULT NULL,
  `product_pic` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_name` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_brand` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `product_price` decimal(10,2) DEFAULT NULL COMMENT '销售价格',
  `product_quantity` int DEFAULT NULL COMMENT '购买数量',
  `product_sku_id` bigint DEFAULT NULL COMMENT '商品sku编号',
  `product_sku_code` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品sku条码',
  `product_category_id` bigint DEFAULT NULL COMMENT '商品分类id',
  `sp1` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品的销售属性',
  `sp2` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `sp3` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `promotion_name` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品促销名称',
  `promotion_amount` decimal(10,2) DEFAULT NULL COMMENT '商品促销分解金额',
  `coupon_amount` decimal(10,2) DEFAULT NULL COMMENT '优惠券优惠分解金额',
  `integration_amount` decimal(10,2) DEFAULT NULL COMMENT '积分优惠分解金额',
  `real_amount` decimal(10,2) DEFAULT NULL COMMENT '该商品经过优惠后的分解金额',
  `gift_integration` int DEFAULT '0',
  `gift_growth` int DEFAULT '0',
  `product_attr` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品销售属性:[{"key":"颜色","value":"颜色"},{"key":"容量","value":"4G"}]',
  `gmt_create` datetime(6) DEFAULT CURRENT_TIMESTAMP(6),
  `gmt_modified` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_order_id` (`order_id`),
  KEY `idx_order_sn` (`order_sn`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of oms_order_item_9
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for oms_order_operate_history
-- ----------------------------
DROP TABLE IF EXISTS `oms_order_operate_history`;
CREATE TABLE `oms_order_operate_history` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `order_id` bigint DEFAULT NULL COMMENT '订单id',
  `operate_man` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '操作人：用户；系统；后台管理员',
  `create_time` datetime DEFAULT NULL COMMENT '操作时间',
  `order_status` int DEFAULT NULL COMMENT '订单状态：0->待付款；1->待发货；2->已发货；3->已完成；4->已关闭；5->无效订单',
  `note` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '备注',
  `gmt_create` datetime(6) DEFAULT CURRENT_TIMESTAMP(6),
  `gmt_modified` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb3 ROW_FORMAT=DYNAMIC COMMENT='订单操作历史记录';

-- ----------------------------
-- Records of oms_order_operate_history
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for oms_order_return_apply
-- ----------------------------
DROP TABLE IF EXISTS `oms_order_return_apply`;
CREATE TABLE `oms_order_return_apply` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `order_id` bigint DEFAULT NULL COMMENT '订单id',
  `company_address_id` bigint DEFAULT NULL COMMENT '收货地址表id',
  `product_id` bigint DEFAULT NULL COMMENT '退货商品id',
  `order_sn` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '订单编号',
  `create_time` datetime DEFAULT NULL COMMENT '申请时间',
  `member_username` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '会员用户名',
  `return_amount` decimal(10,2) DEFAULT NULL COMMENT '退款金额',
  `return_name` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '退货人姓名',
  `return_phone` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '退货人电话',
  `status` int DEFAULT NULL COMMENT '申请状态：0->待处理；1->退货中；2->已完成；3->已拒绝',
  `handle_time` datetime DEFAULT NULL COMMENT '处理时间',
  `product_pic` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品图片',
  `product_name` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品名称',
  `product_brand` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品品牌',
  `product_attr` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品销售属性：颜色：红色；尺码：xl;',
  `product_count` int DEFAULT NULL COMMENT '退货数量',
  `product_price` decimal(10,2) DEFAULT NULL COMMENT '商品单价',
  `product_real_price` decimal(10,2) DEFAULT NULL COMMENT '商品实际支付单价',
  `reason` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '原因',
  `description` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '描述',
  `proof_pics` varchar(1000) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '凭证图片，以逗号隔开',
  `handle_note` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '处理备注',
  `handle_man` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '处理人员',
  `receive_man` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '收货人',
  `receive_time` datetime DEFAULT NULL COMMENT '收货时间',
  `receive_note` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '收货备注',
  `gmt_create` datetime(6) DEFAULT CURRENT_TIMESTAMP(6),
  `gmt_modified` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb3 ROW_FORMAT=DYNAMIC COMMENT='订单退货申请';

-- ----------------------------
-- Records of oms_order_return_apply
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for oms_order_return_reason
-- ----------------------------
DROP TABLE IF EXISTS `oms_order_return_reason`;
CREATE TABLE `oms_order_return_reason` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL COMMENT '退货类型',
  `sort` int DEFAULT NULL,
  `status` int DEFAULT NULL COMMENT '状态：0->不启用；1->启用',
  `create_time` datetime DEFAULT NULL COMMENT '添加时间',
  `gmt_create` datetime(6) DEFAULT CURRENT_TIMESTAMP(6),
  `gmt_modified` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb3 ROW_FORMAT=DYNAMIC COMMENT='退货原因表';

-- ----------------------------
-- Records of oms_order_return_reason
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for oms_order_setting
-- ----------------------------
DROP TABLE IF EXISTS `oms_order_setting`;
CREATE TABLE `oms_order_setting` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `flash_order_overtime` int DEFAULT NULL COMMENT '秒杀订单超时关闭时间(分)',
  `normal_order_overtime` int DEFAULT NULL COMMENT '正常订单超时时间(分)',
  `confirm_overtime` int DEFAULT NULL COMMENT '发货后自动确认收货时间（天）',
  `finish_overtime` int DEFAULT NULL COMMENT '自动完成交易时间，不能申请售后（天）',
  `comment_overtime` int DEFAULT NULL COMMENT '订单完成后自动好评时间（天）',
  `gmt_create` datetime(6) DEFAULT CURRENT_TIMESTAMP(6),
  `gmt_modified` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3 ROW_FORMAT=DYNAMIC COMMENT='订单设置表';

-- ----------------------------
-- Records of oms_order_setting
-- ----------------------------
BEGIN;
INSERT INTO `oms_order_setting` (`id`, `flash_order_overtime`, `normal_order_overtime`, `confirm_overtime`, `finish_overtime`, `comment_overtime`, `gmt_create`, `gmt_modified`) VALUES (1, 60, 120, 15, 7, 7, '2022-07-28 16:16:11.746438', NULL);
COMMIT;

-- ----------------------------
-- Table structure for undo_log
-- ----------------------------
DROP TABLE IF EXISTS `undo_log`;
CREATE TABLE `undo_log` (
  `branch_id` bigint NOT NULL COMMENT 'branch transaction id',
  `xid` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT 'global transaction id',
  `context` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT 'undo_log context,such as serialization',
  `rollback_info` longblob NOT NULL COMMENT 'rollback info',
  `log_status` int NOT NULL COMMENT '0:normal status,1:defense status',
  `log_created` datetime(6) NOT NULL COMMENT 'create datetime',
  `log_modified` datetime(6) NOT NULL COMMENT 'modify datetime',
  UNIQUE KEY `ux_undo_log` (`xid`,`branch_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='AT transaction mode undo table';

-- ----------------------------
-- Records of undo_log
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Procedure structure for copy_order_table
-- ----------------------------
DROP PROCEDURE IF EXISTS `copy_order_table`;
delimiter ;;
CREATE PROCEDURE `copy_order_table`()
BEGIN
	DECLARE o_loop int DEFAULT 0;  -- 循环次数控制
	set o_loop = 0;
	while (o_loop<=31) do
	   set @ddl=CONCAT('create table oms_order','_',o_loop,' select * from oms_order where 0;');
			prepare stmt from @ddl;
			execute stmt;
	   set @ddl2=CONCAT('ALTER TABLE oms_order','_',o_loop,' ADD PRIMARY KEY (id);');
			prepare stmt from @ddl2;
			execute stmt;		
		 set @ddl2=CONCAT('ALTER TABLE oms_order','_',o_loop,' ADD UNIQUE INDEX idx_ordersn(order_sn);');
			prepare stmt from @ddl2;
			execute stmt;	
	   set @ddl3=CONCAT('ALTER TABLE oms_order','_',o_loop,' ADD INDEX idx_member_id(member_id);');
			prepare stmt from @ddl3;
			execute stmt;	
	   set @ddl4=CONCAT('create table oms_order_item','_',o_loop,' select * from oms_order_item where 0;');
			prepare stmt from @ddl4;
			execute stmt;	
		 set @ddl6=CONCAT('ALTER TABLE oms_order_item','_',o_loop,' ADD PRIMARY KEY (id);');
			prepare stmt from @ddl6;
			execute stmt;				
	   set @ddl5=CONCAT('ALTER TABLE oms_order_item','_',o_loop,' ADD INDEX idx_order_id(order_id);');
			prepare stmt from @ddl5;
			execute stmt;	
	   set @ddl5=CONCAT('ALTER TABLE oms_order_item','_',o_loop,' ADD INDEX idx_order_sn(order_sn);');
			prepare stmt from @ddl5;
			execute stmt;	
		  set o_loop = o_loop+1;
	end while;	#Routine body goes here...

END
;;
delimiter ;

SET FOREIGN_KEY_CHECKS = 1;
